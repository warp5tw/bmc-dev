#!/bin/bash

# Date modified: 05/14/2019
#
# This script reports the status of devices connected to the BMC
# and checks that those interfaces are operational.
# It displays:
# - the BMC I2C devices
# - the CPLD switch configurations
# - the BMC GPIO pins and state
# - the power status
# - the temperature status
#
# This script checks FRU EEPROM and can be used on either BlueWhale or
# BlueTang and takes the following inputs:
# If eeprom contents are invalid, user is prompted for valid platform type
#
# NOTE: all failure paths should write a descriptive message to the failure
#       log file for each failure encountered. At the end of the script,
#       the failure log is inspected.  If the log is empty, the script will
#       exit with a return code of 0 to the caller, otherwise the script
#       exits with return code 1.
#

bf_power_status=$(/usr/sbin/mlnx_powerstatus_bf | cut -f 3 -d " ")
if [ "$bf_power_status" == "OFF" ]; then
    echo WARNING: The BlueField is OFF.
    echo Please power it on before running $0
    echo You may use the following command: mlnx_poweron_bf
    exit 1
fi

echo starting script
date

echo -e '\n'/*****Bluewhale BMC Platform Type*****/'\n'
# Read the FRU ID, see if it is recognizable
# Disregard the LSB on FRU ID, as there are MBE1200 and MBE1201 FRUs, for example.
FRU_ID=`hexdump -n 6 -s 68 -v -e '/1 "%s"' /bsp/fru/eeprom_fru`
if [ "$FRU_ID" == "MBE120" ]; then
    PLATFORM=2U
    echo "Detected and checking 2U BlueWhale configuration"
elif [ "$FRU_ID" == "MBE110" ]; then
    PLATFORM=1U
    echo "Detected and checking 1U BlueWhale configuration"
#FRU EEPROM not properly programmed, user must specify platform type
else
    echo -e "$FRU_ID" Unsupported FRU ID Read from eeprom'\n'
    echo "Unable to autodetect platform type" 
    echo "Please check hardware and enter one of the following options: 1U, 2U, or BT" 
    read CMD_PLATFORM

    case "$CMD_PLATFORM" in
        #else run sanity check as per user command
        "BT")
            echo "Checking BlueTang configuration"
            PLATFORM=BT
            ;;
        "1U")
            echo "Checking BlueWhale 1U configuration"
            PLATFORM=1U
            ;;
        "2U")
            echo "Checking BlueWhale 2U configuration"
            PLATFORM=2U
            ;;
        *)
            echo "Please check hardware type and retry command mlnx_bmc_sanity.sh" 
            echo "Enter one of the following options when prompted: 1U, 2U, or BT" 
            exit
            ;;
    esac
fi


# Invoke programs with absolute path in case user wants to run
# script remotely
mlnx_cpldaccess="/usr/sbin/.mlnx_cpldaccess"
mlnx_si5341prog="/usr/sbin/.mlnx_si5341prog"
i2cset="/usr/sbin/i2cset"
i2cget="/usr/sbin/i2cget"

trash="/tmp/trash.$$"

# Sanity script failure log stored in /tmp
fail_log="/tmp/sanity_failures.$$"

# Remove existing failure log (just in case)
rm -f $fail_log

#RefI2cAddr contains the reference {bus, Addr, Name}, which describe
#the I2C buses, the devices' address and the devices' name.

case "$PLATFORM" in
    "1U")
        declare -a RefI2cAddr=('4-0040-CPLD' '6-0050-AT24C128'
            '6-0055-AT24C32AN' '7-001f-TPS53915' '7-001b-TPS53915'
            '7-0040-INA219' '7-0041-INA219' '7-0044-INA219'
            '7-0045-INA219' '8-006c-EMC1444' '9-0070-Si5341'
            '9-006b-Si52142' '10-0020-ispPAC-POWR1014A'
            '10-0021-ispPAC-POWR1014A' '11-0058-TPS53679' '13-002f-ADT7470')

        PS_VERSION=0x00000001
        ;;

    "2U")
        # 0x70 PCIe Socket switch
        # 0x6d Zero Delay Buffer
        # 0x6b Clock Generator
        # For now, we do not include 3-0059-ERP2U875W because
        # it cannot be detected via i2cget tool.
        declare -a RefI2cAddr=('1-0070-PCA9545A' '4-0040-CPLD'
            '6-0050-AT24C128' '6-0055-AT24C32AN' '7-001f-TPS53915'
            '7-001b-TPS53915' '7-0040-INA219' '7-0041-INA219'
            '7-0044-INA219' '7-0045-INA219' '8-006c-EMC1444'
            '9-0070-Si5341' '9-006b-Si52142'
            '10-0020-ispPAC-POWR1014A' '10-0021-ispPAC-POWR1014A'
            '11-0058-TPS53679' '13-002f-ADT7470')

        PS_VERSION=0x00000001
        ;;

    "BT")
        declare -a RefI2cAddr=('4-0040-CPLD' '6-0050-AT24C128'
            '6-0055-AT24C32AN' '7-001f-TPS53915' '7-001b-TPS53915'
            '7-0040-INA219' '7-0041-INA219' '7-0044-INA219'
            '7-0045-INA219' '7-004b-INA219' '7-004c-INA219'
            '7-004d-INA219' '7-004f-INA219' '8-006c-EMC1444'
            '9-0070-Si5341' '10-0020-ispPAC-POWR1014A'
            '10-0021-ispPAC-POWR1014A' '11-0058-TPS53679'
            '13-002f-ADT7470')

        PS_VERSION=0x80000001
        ;;
    *)
        echo -e Internal Error: Invalid Platform value detected: $PLATFORM. 
        exit
        ;;
esac

echo -e '\n'/*****OpenBMC version*****/'\n'
cat /etc/os-release | grep VERSION= | cut -d '"' -f 2

# kernel info
echo -e '\n'/*****kernel info:*****/'\n'
echo -e kernel release:'\t'$(cat /proc/version|cut -d' ' -f 1-3)
echo -e kernel version:'\t'$(uname -v)
echo -e kernel compiler:'\t'$(cat /proc/version|cut -d' ' -f 4)
echo -e GCC compiler version:'\t'$(cat /proc/version|cut -d' ' -f 5-13)

echo -e network node hostname:'\t'$(uname -n)
echo -e machine hardware name:'\t'$(uname -m)

echo -e '\n'/*****U-Boot version*****/'\n'

# Get the MTD number for the "u-boot" partition
mtdnum=`cat /proc/mtd | grep \"u-boot\" | cut -d ":" -f1`

# Search for, and display, version string from specified MTD partition
/usr/bin/strings /dev/$mtdnum | grep U-Boot | grep Mellanox

echo -e '\n'/*****Software versions in backup flash*****/'\n'
/usr/sbin/.mlnx_strings backup-uboot > /tmp/backup-uboot-strings
if [ $? -eq 0 ]; then
    echo `grep BMC /tmp/backup-uboot-strings | grep Mellanox`
else
    echo U-Boot: version not readable
fi

/usr/sbin/.mlnx_strings backup-linux > /tmp/backup-linux-strings
if [ $? -eq 0 ]; then
    # First, check if backup Linux is using legacy format
    LEGACY_LINUX_STRING=`grep Linux /tmp/backup-linux-strings`

    if [ -n "$LEGACY_LINUX_STRING" ]; then
        echo -e kernel release:'\t'$LEGACY_LINUX_STRING
    else
        # Did not find legacy string, must be fitImage format
        FITIMAGE_LINUX_STRING=`grep fitImage /tmp/backup-linux-strings \
                           | cut -f 2 -d "/"`
        echo -e kernel release:'\t'$FITIMAGE_LINUX_STRING
    fi;
else
    echo kernel release: version not readable
fi

echo -e '\n'/*****U-Boot environment variables*****/'\n'
/sbin/fw_printenv

#list all USB devices
echo -e '\n'/*****List of USB devices:*****/'\n'
lsusb

#detect UART devices
echo -e '\n'/*****List UART devices:*****/'\n'
i=1
while read line; do
    test $i -eq 1 && ((i=i+1)) && continue
    serial_port=$(echo "$line" | cut -d " " -f1)
    uart_type=$(echo "$line" | cut -d " " -f2)
    if [ "$uart_type" == "uart:unknown" ]; then
            echo ttyS$serial_port No UART detected
    else
        mmio=$(echo "$line" | cut -d " " -f3)
        irq=$(echo "$line" | cut -d " " -f4)
        echo ttyS$serial_port $uart_type detected at $mmio and uses $irq

        if [ "$serial_port" == "0:" ]; then
            echo -e '\t'"Serial port for (BMC UART1<->Bluefield UART1) connection"
        elif [ "$serial_port" == "4:" ]; then
            echo -e '\t'"Serial port for (BMC UART5<->RJ45) connection"
        else
            echo -e '\t'Serial port for BMC UART2 not connected to anything
        fi

        signals=$(echo "$line" | cut -d " " -f7)

        # CTS = "Clear to Send" control signal
        # DSR = "Data Set Ready" Control signal
        # CD = "Carrier Detect" Control signal
        # if a UART is connected and driving the lines
        # CTS, DSR or CD, then there a signal at the end of the line.
        # When none of the sides is communicating, there are no
        # signals; that does not necessarily mean there is no cable
        # present.
        if [[ "$signals" =~ "CTS" ]] || [[ "$signals" =~ "DSR" ]] ||
            [[ "$signals" =~ "CD" ]]; then
            echo -e '\t'UART communication status: Active
        else
            echo -e '\t'UART communication status: No signal at the end of the line
        fi
    fi
done < /proc/tty/driver/serial

# Extract BMC MAC addresses from known offsets in BMC Mezz EEPROM
echo -e '\n'/*****MAC addresses programmed in system EEPROM*****/'\n'
MAC0=`hexdump -n 6 -s 121 -v -e '/1 "%02x:"' /sys/bus/i2c/devices/6-0055/eeprom`
MAC0=${MAC0::-1}
MAC1=`hexdump -n 6 -s 127 -v -e '/1 "%02x:"' /sys/bus/i2c/devices/6-0055/eeprom`
MAC1=${MAC1::-1}
echo eth0 MAC address: $MAC0
echo eth1 MAC address: $MAC1

#detect configuration of network interfaces
echo -e '\n'/*****Configuration of all network interfaces*****/'\n'
/sbin/ifconfig -a

echo -e '\n'/*****List of expected I2C devices:*****/'\n'

# This function detects and prints whether a device is present or not
# It take the following arguments:
# $1 - i2c bus
# $2 - i2c address
# $3 - device name
# $4 - register address
# It returns the following variables:
# __rv   0 if device is present
#       -1 otherwise

print_detect_msg() {
    {
        $i2cget -y -f $1 $2 $4
    } &> $trash

    if [ $? -eq 0 ]; then
        echo "Bus: $1, Address: $2, Device: $3, Status: present"
        __rv=0
    else
        # Device not found, flag as an failure only if not SSD_VPD_ROM
        if [ $3 != "SSD_VPD_ROM" ]; then
            echo "Bus: $1, Address: $2, Device: $3, Status: not found" >> $fail_log
        fi
        echo "Bus: $1, Address: $2, Device: $3, Status: not found"
        __rv=-1
    fi
}

detect_bp_dev() {
    echo -ne "--------------------------------------------"
    echo "------------------------------------"
    # Use mux to select PCIe skt 0 (bit[0]) or 1 (bit[1])
    $i2cset -y -f 1 0x70 0x0 $1 &> $trash

    if [ $? -eq 0 ]; then
        echo $1 1 | awk '{printf "Selected PCIe skt%d\n\n",$1-$2}'
    else
        echo $1 1 | awk '{printf "Unable to select PCIe skt%d\n",$1-$2}' \
            | tee -a $fail_log
        continue
    fi

    print_detect_msg 1 0x0050 AT24C128B 0x0
    echo -n "--------------------------------------------"
    echo "------------------------------------"
    print_detect_msg 1 0x0051 AT24C128B 0x0
    echo -n "--------------------------------------------"
    echo "------------------------------------"
    print_detect_msg 1 0x0042 PCA9555 0x0
    echo -n "--------------------------------------------"
    echo "------------------------------------"
    # 0x0 is the read only 16-bit Temperature Reg on AT30TS74 device
    print_detect_msg 1 0x0048 AT30MTS74 0x0
    echo -n "--------------------------------------------"
    echo "------------------------------------"
    print_detect_msg 1 0x0071 PCA9548 0x0

    # if the Backplane I2C switch is present, then we can select
    # an SSD to read. bit[0],...,bit[7] of the mux are mapped
    # to SSD0,...,7 respectively
    ssd=0
    if [ $__rv -eq 0 ]; then
        for j in 1 2 4 8 16 32 64 128
        do
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            echo -e SSD$ssd'\n'
            {
                $i2cset -y -f 1 0x71 0x0 $j
            } &> $trash
            # The VPD reg with address 0x0 provides information about
            # the device type and programming interface
            print_detect_msg 1 0x0053 SSD_VPD_ROM 0x0
            ssd=$(($ssd+1))
        done
    fi
}

clk_gen_sel_file="/sys/bus/i2c/devices/4-0040/hwmon/hw*/clk_gen_sel"

# 1-0070 -> PCIe Socket switch: Mux which selects PCIe skt0/1
# 1-0050 -> Riser EEPROM
# 1-0051 -> Backplane EEPROM
# 1-0042 -> Backplane CPLD
# 1-0048 -> Backplane Temp Sense
# 1-006d -> Zero Delay Buffer - Leave this out for now
# 1-006b -> Clock Generator - Leave this out for now
# 1-0071 -> Backplane I2C switch
# 1-001b -> SSD Management interface
# 1-0053 -> SSD VPD ROM
# 3-0058 3-0059 -> AC/DC Power Supply
# 4-0040 -> CPLD
# 6-0050 6-0055 -> FRU ROM
# 7-001f -> DDR 0.9 VRD
# 7-001b -> BF Serdes 1.2 VRD
# 7-0040 -> PCIe0 12V monitor
# 7-0041 -> PCIe0 3.3V monitor
# 7-0044 -> PCIe1 12V monitor
# 7-0045 -> PCIe1 3.3V monitor
# 7-004b 7-004c 7-004d 7-004f -> BT PCIe volt monitor
# 8-006c -> Temperature sensor
# 9-0070 9-006b -> clock generator
# 10-0020 -> MB Power sequencer
# 10-0021 -> BF Power sequence
# 11-0058 -> Core and DDR VDD VRD
# 13-002f -> Fan controller

#compares every device of RefI2cAddr to the one detected by the kernel
for slaveInfo in ${RefI2cAddr[@]}
do
    bus=$(echo $slaveInfo | cut -f1 -d "-")
    sAddr=$(echo $slaveInfo | cut -f2 -d "-")
    dev=$(echo $slaveInfo | cut -f3 -d "-")

    #There are special cases which do not have drivers in the dts
    #So we need to treat them accordingly i.e. read one of the slave
    #device registers; if it returns a value other than "Error: read failed"
    #then the device is present.

    slaveAddr=$(echo $slaveInfo | cut -d- -f1-2)

    case $slaveAddr in
        "1-0070")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            # 0x0 is the address of the switch control register
            print_detect_msg $bus 0x$sAddr $dev 0x0

            if [ $__rv -eq 0 ]; then
                detect_bp_dev 1
                detect_bp_dev 2
            fi
            continue
            ;;

        #"3-0059")
        #    echo -n "--------------------------------------------"
        #    echo "------------------------------------"
        #    # read the PMBus version
        #    print_detect_msg $bus 0x$sAddr $dev 0x98
        #    continue
        #    ;;

        "4-0040")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            #0x0 is the address of the cpld revision register
            print_detect_msg $bus 0x$sAddr $dev 0x0
            if [ $__rv -eq 0 ]; then
                echo CPLD major version: $($mlnx_cpldaccess -mb -r 0x0 | cut -d' ' -f 5)
                echo CPLD minor version: $($mlnx_cpldaccess -mb -r 0x507 | cut -d' ' -f 5)
            fi
            ;;

        "6-0050")
            ;&
        "6-0055")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            #read first byte
            print_detect_msg $bus 0x$sAddr $dev 0x0
            ;;

        "7-001f")
            ;&
        "7-001b")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            # 0xd0 is the CUSTOM_REG register. The user can program this
            # register to track versions of implementation. By default,
            # it is set to 0.
            print_detect_msg $bus 0x$sAddr $dev 0xd0
            ;;

        "7-0040")
            ;&
        "7-0041")
            ;&
        "7-0044")
            ;&
        "7-0045")
            ;&
        "7-004b")
            ;&
        "7-004c")
            ;&
        "7-004d")
            ;&
        "7-004f")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            # Read configuration register with address 0x0
            print_detect_msg $bus 0x$sAddr $dev 0x0
            ;;

        "8-006c")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            # 0xff is the address of the revision ID register.
            # The device revision id is 0x04
            {
                rev=$($i2cget -y -f 8 0x$sAddr 0xff)
            } &> $trash
            if [ "$rev" == "0x04" ]; then
                echo "Bus: $bus, Address: 0x$sAddr, Device: $dev, Status: present"
            else
                echo "Bus: $bus, Address: 0x$sAddr, Device: $dev, Status: not found" \
                    | tee -a $fail_log
            fi
            ;;

        "9-0070")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            #clock generators need special handling since they
            #do not have drivers.

            # The slave I2C address of the Si5341 device depends on board revision:
            #   Rev A3 or later: address is 0x70
            #   Earlier Rev    : address is 0x74
            #
            # There is no way to read board revision, so instead use 'i2cdetect'
            # to figure out which slave address to use.
            #
            detectOldAddr=`/usr/sbin/i2cdetect -y 9 | grep 74`
            if [ "$detectOldAddr" ]; then
                sAddr=0x0074
            else
                sAddr=0x0070
            fi
            $mlnx_si5341prog --device 9:$sAddr --getreg 0x0000 &> $trash
            if [ $? -eq 0 ]; then
                echo "Bus: $bus, Address: $sAddr, Device: $dev, Status: present"
            else
                echo "Bus: $bus, Address: $sAddr, Device: $dev, Status: not found" \
                    | tee -a $fail_log
            fi
            continue
            ;;

        "9-006b")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            #Select Clock Generator #1
            {
                echo 0 > $clk_gen_sel_file
            } &> $trash

            if [ $? -ne 0 ]; then
                echo WARNING: Unable to write clk_gen_sel in the cpld \
                    | tee -a $fail_log
            else
                if [ $(cat $clk_gen_sel_file) -ne \
                    0 ]; then
                    echo WARNING: Unable to select clk gen 1 \
                        | tee -a $fail_log
                    continue
                fi
            fi

            echo -n "clock generator 1, "
            print_detect_msg $bus 0x$sAddr $dev 0x03

            #Select Clock generator #2
            {
                echo 1 > $clk_gen_sel_file
            } &> $trash

            if [ $? -ne 0 ]; then
                echo WARNING: Unable to write clk_gen_sel in the cpld \
                    | tee -a $fail_log
            else
                if [ $(cat $clk_gen_sel_file) \
                    -ne 1 ]; then
                    echo WARNING: Unable to select clk gen 2 \
                        | tee -a $fail_log
                    continue
                fi
            fi

            echo -n "clock generator 2, "
            print_detect_msg $bus 0x$sAddr $dev 0x03

            continue
            ;;

        "10-0020")
        ;&
        "10-0021")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            {
                $i2cget -y -f 10 0x$sAddr 0x0A | cut -d"x" -f2 &> /tmp/UES_byte0
                $i2cget -y -f 10 0x$sAddr 0x0B | cut -d"x" -f2 &> /tmp/UES_byte1
                $i2cget -y -f 10 0x$sAddr 0x0C | cut -d"x" -f2 &> /tmp/UES_byte2
                $i2cget -y -f 10 0x$sAddr 0x0D | cut -d"x" -f2 &> /tmp/UES_byte3
            } &> $trash

            if [ -s /tmp/UES_byte0 ] && [ -s /tmp/UES_byte1 ] && \
                [ -s /tmp/UES_byte2 ] && [ -s /tmp/UES_byte3 ]
            then
                ps_version=$(echo -n "0x$(cat /tmp/UES_byte3)"
                echo -n "$(cat /tmp/UES_byte2)$(cat /tmp/UES_byte1)"
                echo "$(cat /tmp/UES_byte0)")

                if [ "$ps_version" == "$PS_VERSION" ]; then
                    echo Power sequencer version: $ps_version
                else
                    echo -n "Power sequencer version $ps_version" \
                        | tee -a $fail_log
                    echo " does not match expected version $PS_VERSION" \
                        | tee -a $fail_log
                fi
                echo "Bus: $bus, Address: 0x$sAddr, Device: $dev, Status: present"
            else
                echo "Bus: $bus, Address: 0x$sAddr, Device: $dev, Status: not found" \
                    | tee -a $fail_log
            fi

            rm /tmp/UES_byte0 /tmp/UES_byte1
            rm /tmp/UES_byte2 /tmp/UES_byte3
            ;;

        "11-0058")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            # 0x98 is the address of the PMBUS_REVISION reg.
            # This reg returns the version of the PMBus specs
            # to which this device complies. It is 0x33.
            {
                rev=$($i2cget -y -f 11 0x58 0x98)
            } &> $trash

            if [ "$rev" == "0x33" ]; then
                echo "Bus: $bus, Address: 0x$sAddr, Device: $dev, Status: present"
            else
                echo "Bus: $bus, Address: 0x$sAddr, Device: $dev, Status: not found" \
                    | tee -a $fail_log
            fi
            ;;

        "13-002f")
            echo -n "--------------------------------------------"
            echo "------------------------------------"
            # 0x3f is the address of the revision number register.
            # The device revision number is 0x02
            {
                rev=$($i2cget -y -f 13 0x2f 0x3f)
            } &> $trash

            if [ "$rev" == "0x02" ]; then
               echo "Bus: $bus, Address: 0x$sAddr, Device: $dev, Status: present"
            else
               echo "Bus: $bus, Address: 0x$sAddr, Device: $dev, Status: not found" \
                   | tee -a $fail_log
            fi
            ;;

        *)
            ;;
    esac

    #find device in /sys/bus/i2c/devices directory
    if [ $(find /sys/bus/i2c/devices -name "$slaveAddr") ]; then
        echo "This device's driver is present"
    else
        echo "This device's driver was not found" \
            | tee -a $fail_log
    fi
done

cpld_dir="/sys/bus/i2c/devices/4-0040/hwmon/hw*"

# List all configurations
echo -e '\n'/*****CPLD Configurations*****/

echo -e '\n'-----------------------------
echo CPLD Config Switch Reg
echo -e Offset: 0x1A
printf "cpld_cfg_sw_reg: 0x%x\n" $(cat $cpld_dir"/cpld_cfg_sw_reg")
cpld_cfg_sw_reg=$(cat $cpld_dir"/cpld_cfg_sw_reg")

if [ "$PLATFORM" != "BT" ]; then

    echo -e '\n''\t'------------------------
    echo -e '\t'CCLK_SELECT Switch Settings'\n'
    echo -e '\t'sw SW'\t'hw SW'\t'State
    echo -e '\t'SW0'\t'SW8:1'\t'$(( cpld_cfg_sw_reg & 1 ))
    echo -e '\t'SW1'\t'SW8:2'\t'$((( cpld_cfg_sw_reg >> 1 ) & 1 ))
    echo -e '\n''\t'"CCLK_SELECT0: $(( cpld_cfg_sw_reg & 1 ))"
    echo -e '\t'"CCLK_SELECT1: $((( cpld_cfg_sw_reg >> 1 ) & 1 ))"

    cpld_major_version=$($mlnx_cpldaccess -mb -r 0x0 | cut -d' ' -f 5)
    cpld_minor_version=$($mlnx_cpldaccess -mb -r 0x507 | cut -d' ' -f 5)

    (("$cpld_minor_version" < "0xe")) && (("$cpld_major_version" == 0))

    if [ $? -eq 0 ]; then
        #cpld_major_version is 0 and cpld_minor_version is less than 14

        sw2=$(( cpld_cfg_sw_reg & 4 ))

        echo -e '\n''\t'--------------------------------
        echo -e '\t'Smart NIC Mode CPLD Config Switch'\n'
        echo -e '\t'sw SW'\t'hw SW'\t'State'\t'Function
        if [ $sw2 == 0 ]; then
            echo -e '\t'SW2'\t'SW7:1'\t'0'\t'JBOF Mode
        else
            echo -e '\t'SW2'\t'SW7:1'\t'1'\t'Smart NIC Mode
        fi

        sw3_4_5=$((( cpld_cfg_sw_reg >> 3 ) & 0x7 ))

        echo -e '\n''\t'----------------------------------------
        echo -e '\t'Global Clock Configuration Switch Setting
        echo -e '\n''\t'sw SW'\t'hw SW'\t'State
        echo -e '\t'SW3'\t'SW7:2'\t'$((( cpld_cfg_sw_reg >> 3 ) & 1 ))
        echo -e '\t'SW4'\t'SW6:1'\t'$((( cpld_cfg_sw_reg >> 4 ) & 1 ))
        echo -e '\t'SW5'\t'SW6:2'\t'$((( cpld_cfg_sw_reg >> 5 ) & 1 ))'\n'

        case "$sw3_4_5" in
            0)
                echo -e '\t'"Function: Common Clock, 1 Source";;
            0x1)
                echo -e '\t'"Function: Common Clock, 2 Source";;
            0x2)
                echo -e '\t'"Function: Separate Clock, 1 Source";;
            0x3)
                echo -e '\t'"Function: Separate Clock, 2 Source";;
            0x4)
                echo -e '\t'"Function: Logic Analyzer Clock Mode";;
            0x5)
                echo -e '\t'"Function: Multi-Host Mode";;
            0x6)
                echo -e '\t'"Function: Common Clock, 1 Source";;
            0x7)
                echo -e '\t'"Function: Common Clock, 2 Source";;
            *)
                echo -e '\t'Unknown Global Clock Config Setting;;
        esac

    else    #cpld_minor_version >= 14

        sw2_3_4_5=$((( cpld_cfg_sw_reg >> 2 ) & 0xf ))

        echo -e '\n''\t'----------------------------------------
        echo -e '\t'Operating Mode Switch Settings
        echo -e '\n''\t'sw SW'\t'hw SW'\t'State
        echo -e '\t'SW2'\t'SW7:1'\t'$((( cpld_cfg_sw_reg >> 2 ) & 1 ))
        echo -e '\t'SW3'\t'SW7:2'\t'$((( cpld_cfg_sw_reg >> 3 ) & 1 ))
        echo -e '\t'SW4'\t'SW6:1'\t'$((( cpld_cfg_sw_reg >> 4 ) & 1 ))
        echo -e '\t'SW5'\t'SW6:2'\t'$((( cpld_cfg_sw_reg >> 5 ) & 1 ))'\n'

        case "$sw2_3_4_5" in
            0)
                echo -e '\t'"Mode 0: 16 x2 SSDs (JBOF)";;
            0x1)
                echo -e '\t'"Mode 1: 8 x4 SSDs (JBOF)";;
            0x2)
                echo -e '\t'"Mode 2: 2 x16 EP (GPUs or other in PCIe slots) (JBOG)";;
            0x3)
                echo -e '\t'"Mode 3: 4 x8 EP (w/ bifurcated device like coral MH NIC)";;
            0x4)
                echo -ne '\t'"Mode 4: 2 x16 Host (PCIe slots cabled to x86 or other"
                echo " host) (SmartNIC)";;
            0x5)
                echo -e '\t'"Mode 5: 1 x16 EP (GPU) + 8 x2 SSD";;
            0x6)
                echo -e '\t'"Mode 6: 1 x16 EP (GPU) + 4 x4 SSD";;
            0x7)
                echo -e '\t'"Mode 7: 1 x16 Host + 8 x2 SSDs";;
            0x8)
                echo -e '\t'"Mode 8: 1 x16 Host + 4 x4 SSDs";;
            0x9)
                echo -e '\t'"Mode 9: 1 x16 Host + 1 x16 SSDs";;
            0xa)
                echo -e '\t'"Mode 10: 1 x16 EP + 1 x16 Host - analyzer mode";;
            0xb)
                echo -e '\t'"Mode 11: 1 x2 EP (BMC) + 1 x8 EP + 8 x2 SSDs";;
            0xc)
                echo -e '\t'"Mode 12: ADVG PCIe test hooks";;
            *)
                echo -e '\t'Unknown Global Clock Config Setting;;
        esac

    fi #cpld_minor_version
fi # !BT

sw6=$(( cpld_cfg_sw_reg & 64 ))

echo -e '\n''\t'-------------------------------
echo -e '\t'MAINT_MUX_SELECT Switch Setting'\n'
echo -e '\t'sw SW'\t'hw SW'\t'State'\t'Function
if [ $sw6 == 0 ]; then
        echo -e '\t'SW6'\t'SW5:1'\t'0'\t'"S_I2C_BF_MAINT_MUX_SEL=0 (NIC I2C3)"
else
        echo -e '\t'SW6'\t'SW5:1'\t'1'\t'"S_I2C_BF_MAINT_MUX_SEL=1 (ARM I2C2)"
fi

sw7=$(( cpld_cfg_sw_reg & 128 ))

echo -e '\n''\t'-------------------
echo -e '\t'SW7 Reset Assignment
echo -e '\n''\t'sw SW'\t'hw SW'\t'State'\t'Function
if [ $sw7 == 0 ]; then
        echo -e '\t'SW7'\t'SW5:2'\t'0'\t'"Auto-Reset release of BF & Peripherals"
else
        echo -ne '\t'SW7'\t'SW5:2'\t'1'\t'"BMC in charge of clearing the BF and "
        echo "Peripheral resets"
fi

echo -e '\n'----------------------------------
echo Reset Ctrl Reg
echo Offset: 0x01
rst_ctl_reg=$($mlnx_cpldaccess -mb -r 0x01 | cut -d' ' -f 5)
echo -e '\n'Bits '\t' Name '\t''\t''\t'Value
echo -e 0 '\t' SOC_HARD_RST_L'\t''\t'$(cat $cpld_dir"/bf_hard_reset")
echo -e 1 '\t' RS232_RST_L'\t''\t'$(cat $cpld_dir"/bf_rs232_reset")
echo -e 2 '\t' USBPHY_RST_L'\t''\t'$(cat $cpld_dir"/usb_phy_reset")
echo -e 3 '\t' S_BUF1_SI5341_RST_L'\t'$((( rst_ctl_reg >> 3 ) & 1 ))
echo -e 4 '\t' JTAG_CSIGHT_SRST_L'\t'$(cat $cpld_dir"/jtag_cs_reset")
echo -e 5 '\t' S_SOC_FUNCMODE'\t''\t'$(cat $cpld_dir"/bf_funcmode")
echo -e 6 '\t' BF Power Good Force'\t'$(cat $cpld_dir"/bf_pwr_good_force")
echo -e 7 '\t' S_CPLD_SKT_I2C_SW_RST'\t'$(cat $cpld_dir"/pcie_i2c_sw_reset")

echo -e '\n'-----------------------------------
print_i2c_bus_control() {
    if [ "$1" == "0" ]; then
        echo BF controls the I2C bus
    else
        echo BMC controls the I2C bus
    fi
}
echo CPLD Configuration Control Register
echo Offset: 0x04
echo -e '\n'Bits '\t' Name '\t''\t''\t'Value'\t'Function
echo -ne 0 '\t' Power Bus Ctrl Sel'\t'$(cat $cpld_dir"/pwr_ctl_sel")
echo -e '\t'$(print_i2c_bus_control $(cat $cpld_dir"/pwr_ctl_sel"))
echo -ne 1 '\t' Fan Bus Ctrl Sel'\t'$(cat $cpld_dir"/fan_ctl_sel")
echo -e '\t'$(print_i2c_bus_control $(cat $cpld_dir"/fan_ctl_sel"))
echo -ne 2 '\t' PCIe Sckt Bus Ctrl Sel'\t'$(cat $cpld_dir"/pcie_skt_sel")
echo -e '\t'$(print_i2c_bus_control $(cat $cpld_dir"/pcie_skt_sel"))

val=$(cat $clk_gen_sel_file)
if [ $val == 0 ]; then
    func=$(echo "Select clock generator #1")
else
    func=$(echo "Select clock generator #2")
fi
echo -e 3 '\t' Clk Gen Mux Sel'\t'$val'\t'$func

val=$(cat $cpld_dir"/pwr_good_mask")
if [ $val == 0 ]; then
    func=$(echo Mask set)
else
    func=$(echo Mask clear)
fi
echo -e 4 '\t' BF Power Good Mask'\t'$val'\t'$func

val=$(cat $cpld_dir"/pcie_bmc_sel")
if [ $val == 0 ]; then
    func=$(echo BF SOC Lane 14 to PCIe Socket 1)
else
    func=$(echo BF SOC Lane 14 to BMC PCIe)
fi
echo -e 5 '\t' BMC PCIe Conn Mux Sel'\t'$val'\t'$func

echo -e '\n'------------------------------------
echo Thermal Status Reg
thml_stat_reg=$($mlnx_cpldaccess -mb -r 0x05 | cut -d' ' -f 5)
echo Offset: 0x05
echo -e '\n'Bits '\t' Name '\t''\t''\t'Value
echo -e 0 '\t' GP_THERMAL_CRIT_L '\t' $(( thml_stat_reg & 1 ))
echo -e 1 '\t' GP_MOBO_THERMAL_ALERT_L $((( thml_stat_reg >> 1 ) & 1 ))
echo -e 2 '\t' GP_SOC_THERMAL_ALERT_L'\t' $((( thml_stat_reg >> 2 ) & 1 ))
echo -e 3 '\t' S_FAN_ALERT_L '\t''\t' $((( thml_stat_reg >> 3 ) & 1 ))
echo -e 4 '\t' S_FAN_MAX_SPEED_L '\t' $((( thml_stat_reg >> 4 ) & 1 ))

echo -e '\n'------------------------------------
echo Thermal Mask Reg
echo Offset: 0x07
echo Value: $($mlnx_cpldaccess -mb -r 0x07 | cut -d' ' -f 5)

echo -e '\n'------------------------------------
echo Clk Status Reg
echo Offset 0x11
echo Value: $($mlnx_cpldaccess -mb -r 0x11 | cut -d' ' -f 5)

echo -e '\n'------------------------------------
echo Clk Config Reg 0
echo Offset: 0x14
printf "clk_cfg_reg0: 0x%x\n" $(cat $cpld_dir"/clk_cfg_reg0")

echo -e '\n'----------------
echo Clk Config Reg 1
echo Offset: 0x15
printf "clk_cfg_reg1: 0x%x\n" $(cat $cpld_dir"/clk_cfg_reg1")

echo -e '\n'----------------
echo Clk Config Reg 2
echo Offset: 0x16
printf "clk_cfg_reg2: 0x%x\n" $(cat $cpld_dir"/clk_cfg_reg2")

echo -e '\n'----------------
echo Clk Config Reg 3
echo Offset: 0x17
printf "clk_cfg_reg3: 0x%x\n" $(cat $cpld_dir"/clk_cfg_reg3")

echo -e '\n'----------------------
echo PCIe Skt 0 Status Reg
echo Offset: 0x18
printf "pcie_skt0: 0x%x\n" $(cat $cpld_dir"/pcie_skt0")

echo -e '\n'----------------------
echo PCIe Skt 1 Status Reg
echo Offset: 0x19
printf "pcie_skt1: 0x%x\n" $(cat $cpld_dir"/pcie_skt1")

echo -e '\n'-------------------
echo Port Status Reg
echo Offset: 0x1B
printf "port_status: 0x%x\n" $(cat $cpld_dir"/port_status")

echo -e '\n'------------------------
echo ARM GPIO Test Reg 0
echo Offset: 0x1C
printf "arm_gpio_test0: 0x%x\n" $(cat $cpld_dir"/arm_gpio_test0")

echo -e '\n'------------------------
echo NIC GPIO Test Reg 0
echo Offset:0x1D
printf "nic_gpio_test0: 0x%x\n" $(cat $cpld_dir"/nic_gpio_test0")

echo -e '\n'------------------------
echo NIC GPIO Test Reg 1
echo Offset:0x1E
printf "nic_gpio_test1: 0x%x\n" $(cat $cpld_dir"/nic_gpio_test1")

echo -e '\n'------------------------
echo NIC GPIO Test Reg 2
echo Offset:0x1F
printf "nic_gpio_test2: 0x%x\n" $(cat $cpld_dir"/nic_gpio_test2")

# BMC GPIO pins and state

declare -a gpio_tbl=(
    '213-11-S_ATX_POWER_OK...........'
    '214-13-S_12V_ATXIN_FAULT_L......'
    '215-15-S_BMC_POWER_CYC_REQ_INT_L'
    '218-17-S_BMC_POWER_CYC_ACK_L....'
    '219-19-S_BMC_POWER_CYCLE_L......'
    '145-21-S_FP_PBUTTON_UID_OD_L....'
    '146-23-S_BMC_ENET_INT_L.........'
    '147-25-S_USB_BMC_OVRC_L.........'
    '209-16-L_FP_LAN1_FET............'
    '210-18-L_FP_LAN2_FET............'
    '211-20-L_FP_ATTN_FET............'
    '212-22-L_FP_STATUS_FET..........'
    '9-24-SE_BMC_CPLD_RESET_L_ISO..'
    '10-26-SE_CPLD_BMC_INTERRUPT_L..'
    '11-30-S_BMC_SKT_I2C_SW_RST_L...'
    '12-32-SE_BF_SPI_SELECT.........'
    '15-34-ATXPS_ALERT_L............'
    '24-36-GP_BMC_SOC_CONFIG_ROM0...'
    '25-38-GP_BMC_SOC_CONFIG_ROM1...'
    '31-237-S_BMC_SYSTEM_RST_L.......'
)

echo -e '\n'/*****State of GPIO Pins*****/
echo -e '\n'GPIO#'\t'BMC_Pin'\t''\t'Name'\t''\t''\t''\t'Value'\n'

# From Aspeed GPIO driver sysfs, get base number for GPIO access
GPIO_BASE=$(cat /sys/devices/platform/ahb/ahb:apb/1e780000.gpio/gpio/*/base)

dir="/sys/class/gpio"

for gpioInfo in ${gpio_tbl[@]}; do
    gpioNum=$(echo $gpioInfo | cut -f1 -d "-")
    gpioNum=$(($gpioNum + $GPIO_BASE))
    bmcPin=$(echo $gpioInfo | cut -f2 -d "-")
    Name=$(echo $gpioInfo | cut -f3 -d "-")

    echo $gpioNum > "$dir/export"
    echo in > "$dir/gpio$gpioNum/direction"
    val=$(cat "$dir/gpio$gpioNum/value")
    echo -e $(($gpioNum - $GPIO_BASE))'\t'$bmcPin'\t''\t'$Name'\t'$val
    echo $gpioNum > "$dir/unexport"
done

# This function takes 2 arguments:
# $1 is the value of the power status register
# $2 is the bit shift in the pstatus register
# Depending on the value of a bit, we determine
# whether the output power status from a buck
# converter to a certain device is good or not.

print_pgood_status () {
    bit=$((( $1 >> $2 ) & 1 ))
    if [ $bit == 1 ]; then
        echo GOOD
    else
        echo BAD
    fi
}

get_vmon() {
    in=$(cat $2"/in$1_input")
    echo $in"mV"
}

# Since ispPAC-POWR1014A allows a max Vmon of 5.867V,
# A volatge divider is used to adjust to that range for a
# 12V Voltage Rail. The resistance ratio is 12.7kOhm
# for R1 connected to 12V power supply and 10kOhm for R2
# connected to ground.
# So Vin = Vout*(R1+R2)/R2 = Vout*2.27

get_vmon_12V() {
    RRATIO=2.27
    in=$(cat $2"/in$1_input")
    in=$(echo $RRATIO $in | awk '{printf "%4.1f\n",$1*$2}')
    echo $in"mV"
}

echo -e '\n'/*****Power Status*****/

# Information extracted from cpld Power Status Reg 0 and 1
# Standby Voltages and 3.3V MB extracted from driver
pstatus0=$($mlnx_cpldaccess -mb -r 0x08 | cut -d' ' -f 5)
pstatus1=$($mlnx_cpldaccess -mb -r 0x0b | cut -d' ' -f 5)

# 3P3V_BF_IO Voltage rail was removed from HW so we
# are not implementing it in SW.
#
# The Power sequencer is no longer connected to the
# 0P3V_BF_DDR0/1_VSSH pins on the BF. Instead, we have an internal BF Voltage
# regulator. So we are not recording 0.3V DDR from the power sequencer.

dir="/sys/bus/i2c/devices/10-0020/hwmon/hw*"

echo -e '\n'MOBO Voltages monitored on ispPAC-POWR1014A at I2C address 0x20:'\n'
echo -e Voltage Rail'\t'Voltage'\t''\t'status'\t'ispPAC-POWR1014A pin'\n'
echo -e 5V_STANDBY'\t'$(get_vmon 0 $dir)'\t''\t'N/A'\t'VMON1
echo -e ATX_12V'\t''\t'$(get_vmon_12V 1 $dir)'\t'N/A'\t'VMON2
echo -e 3P3V_AUX'\t'$(get_vmon 2 $dir)'\t''\t'$(print_pgood_status $pstatus0 0)'\t'VMON3
echo -e 5V_AUX'\t''\t'$(get_vmon 3 $dir)'\t''\t'$(print_pgood_status $pstatus0 1)'\t'VMON4
echo -e 3P3V_MOBO'\t'$(get_vmon 4 $dir)'\t''\t'$(print_pgood_status $pstatus0 2)'\t'VMON5
echo -e 3P3V_STANDBY'\t'$(get_vmon 5 $dir)'\t''\t'N/A'\t'VMON6

echo -e '\n'Socket Voltage monitored on ispPAC-POWR1014A at I2C address 0x20:'\n'
echo -e Voltage Rail'\t'Voltage'\t''\t'status'\t'ispPAC-POWR1014A pin'\n'
echo -e SKT0_12V'\t'$(get_vmon_12V 6 $dir)'\t'N/A'\t'VMON7
echo -e SKT0_3P3V'\t'$(get_vmon 7 $dir)'\t''\t'N/A'\t'VMON8
echo -e SKT1_12V'\t'$(get_vmon_12V 8 $dir)'\t'N/A'\t'VMON9
echo -e SKT1_3P3'\t'$(get_vmon 9 $dir)'\t''\t'N/A'\t'VMON10

dir="/sys/bus/i2c/devices/10-0021/hwmon/hw*"

echo -e '\n'BF Voltages monitored on ispPAC-POWR1014A at I2C address 0x21:'\n'
echo -e Voltage Rail'\t''\t'Voltage'\t'status'\t'ispPAC-POWR1014A pin'\n'
echo -e VCORE_VRD'\t''\t'$(get_vmon 0 $dir)'\t'$(print_pgood_status $pstatus1 6)'\t'VMON1
echo -e 1P2V_BF_DDR'\t''\t'$(get_vmon 1 $dir)'\t'$(print_pgood_status $pstatus1 7)'\t'VMON2
echo -e 0P9_BF_DDR'\t''\t'$(get_vmon 4 $dir)'\t'$(print_pgood_status $pstatus1 5)'\t'VMON5
echo -e 2P5V_DDR0'\t''\t'$(get_vmon 5 $dir)'\t'$(print_pgood_status $pstatus1 0)'\t'VMON6
echo -e 2P5V_DDR1'\t''\t'$(get_vmon 6 $dir)'\t'$(print_pgood_status $pstatus1 1)'\t'VMON7
echo -e 1P2V_BF_SERDES'\t''\t'$(get_vmon 7 $dir)'\t'$(print_pgood_status $pstatus0 5)'\t'VMON8
echo -e 1P8_BF_VDDO'\t''\t'$(get_vmon 8 $dir)'\t'$(print_pgood_status $pstatus0 6)'\t'VMON9
echo -e 0P6V_BF_DDR0_VREF'\t'N/A'\t'$(print_pgood_status $pstatus1 3)'\t'N/A
echo -e 0P6V_BF_DDR1_VREF'\t'N/A'\t'$(print_pgood_status $pstatus1 4)'\t'N/A

# Information extracted from cpld Power Status Reg 2
pstatus=$($mlnx_cpldaccess -mb -r 0x0e | cut -d' ' -f 5)

if [ $(( $pstatus & 0x7 )) != 7 ]; then
    if [ "$(print_pgood_status $pstatus 0)" == "BAD" ]; then
        echo -n "VRD fault condition detected in TPS53679 " \
            | tee -a $fail_log
        echo "VCORE & DDR 1.2V Controller VR" \
            | tee -a $fail_log
    fi
    if  [ "$(print_pgood_status $pstatus 1)" == "BAD" ]; then
        echo -n "Fault condition detected in " \
            | tee -a $fail_log
        echo "TPS53915 1.2V Serdes Supply." \
            | tee -a $fail_log
    fi
    if [ "$(print_pgood_status $pstatus 2)" == "BAD" ]; then
        echo -n "Fault condition detected in TPS53915 " \
            | tee -a $fail_log
        echo "0.9V DDR Supply." \
            | tee -a $fail_log
    fi
else
    echo -e '\n'No fault condition detected in CPLD Power Status Reg 2
fi

# Check that the temperature is within limits
# There is an EMC 1444 temperature sensor monitoring temp for the
# following diodes:
#
# MB Remote Thermal sensors (I2C addr: 0x6c)
# EMC pin DP1/DN1 -> QSPF Inlet air diode
# EMC pin DP2/DN3 -> PCIe Slot inlet air diode
# EMC pin DP3/DN2 -> BF inlet air diode

# $1 is the directory path
# $2 is the diode number
get_temp_status () {
    temp_crit_alarm=$(cat "$1/temp$2_crit_alarm")
    temp_min_alarm=$(cat "$1/temp$2_min_alarm")
    temp_max_alarm=$(cat "$1/temp$2_max_alarm")

    if [ $temp_crit_alarm == 0 ] && [ $temp_min_alarm == 0 ] && [ $temp_max_alarm == 0 ]; then
        echo GOOD. Temperature within bounds.
    else
        if [ $temp_crit_alarm == 1 ]; then
            echo BAD. diode channel exceeds its THERM limit. \
                | tee -a $fail_log
        fi
        if [ $temp_min_alarm == 1 ]; then
            echo BAD. diode channel dropped below limit. \
                | tee -a $fail_log
        fi
        if [ $temp_max_alarm == 1 ]; then
            echo BAD. diode channel exceeds its high limit. \
                | tee -a $fail_log
        fi
    fi
}

echo -e '\n'/*****Temperature Status*****/
echo -e '\n'------------------------------------------------------------
dir="/sys/bus/i2c/devices/8-006c/hwmon/hw*"
echo -e Temperature status of diodes in EMC1444 at I2C address 0x6c'\n'
echo Internal diode
echo -e '\t'Current temp: $(cat $dir"/temp1_input") mC
echo -e '\t'Status: $(get_temp_status $dir 1)
echo "External diode 1 (DP1/DN1):"
echo -e '\t'Name: QSPF inlet air diode
echo -e '\t''\t'Pin connections:
echo -e '\t''\t'"TEMP_MOBO_SENSOR0_P <-> DP1"
echo -e '\t''\t'"TEMP_MOBO_SENSOR0_N <-> DN1"
echo -e '\t'Current temp: $(cat $dir"/temp2_input") mC
echo -e '\t'Status: $(get_temp_status $dir 2)
echo "External diode 2 (DP2/DN2):"
echo -e '\t'Name: BF inlet air diode
echo -e '\t''\t'Pin connections:
echo -e '\t''\t'"TEMP_MOBO_SENSOR1_P <-> DN3/DP2"
echo -e '\t''\t'"TEMP_MOBO_SENSOR1_N <-> DP3/DN2"
echo -e '\t'Current temp: $(cat $dir"/temp3_input") mC
echo -e '\t'Status: $(get_temp_status $dir 3)
echo "External diode 3 (DP3/DN3):"
echo -e '\t'Name: PCIe slot inlet air diode
echo -e '\t''\t'Pin connections:
echo -e '\t''\t'"TEMP_MOBO_SENSOR1_P <-> DN3/DP2"
echo -e '\t''\t'"TEMP_MOBO_SENSOR1_N <-> DP3/DN2"
echo -e '\t'Current temp: $(cat $dir"/temp4_input") mC
echo -e '\t'Status: $(get_temp_status $dir 4)

echo -e '\n'/*****Fan Speeds*****/'\n'

# Config Reg 2 bits[3:0] enable/disable fan measurement
# Make sure all fan measurements are enabled (logic low)
{
    cfg_reg2=$($i2cget -y -f 13 0x2f 0x74)
} &> $trash
fan_en=$(echo $(( $cfg_reg2 & 0xf )))

if [ "$fan_en" != 0 ]; then
    $i2cset -y -f 13 0x2f 0x74 0x0
fi

tach_2_speed() {
    # fan_speed=(90000*60)/(fan tach reading)
    speed=$(echo 90000 60 | awk '{print $1*$2}')
    if [ "$1" == 0x00 ]; then
        # where division by 0 case
        echo 0 RPM
    else
        speed=$(echo $speed $1 | awk '{print $1/$2}')
        echo $speed RPM
    fi
}

concat_bytes() {
    echo "0x$2$1"
}

{
    tach1_l=$($i2cget -y -f 13 0x2f 0x2a | cut -d"x" -f2)
    tach1_h=$($i2cget -y -f 13 0x2f 0x2b | cut -d"x" -f2)
    tach2_l=$($i2cget -y -f 13 0x2f 0x2c | cut -d"x" -f2)
    tach2_h=$($i2cget -y -f 13 0x2f 0x2d | cut -d"x" -f2)
    tach3_l=$($i2cget -y -f 13 0x2f 0x2e | cut -d"x" -f2)
    tach3_h=$($i2cget -y -f 13 0x2f 0x2f | cut -d"x" -f2)
} &> $trash

tach1=$(concat_bytes $tach1_l $tach1_h)
tach2=$(concat_bytes $tach2_l $tach2_h)
tach3=$(concat_bytes $tach3_l $tach3_h)

echo "Fan 1 speed: $(tach_2_speed $tach1)"
echo "Fan 2 speed: $(tach_2_speed $tach2)"
echo "Fan 3 speed: $(tach_2_speed $tach3)"

rm $trash

if [ -f $fail_log ]; then
    sanity_fails=`wc -l < $fail_log`
else
    sanity_fails=0
fi

if [ $sanity_fails -ne 0 ]; then
   echo -e '\n'WARNING: sanity script encountered $sanity_fails failures!
   retval=1
else
   retval=0
fi

echo -e '\n'end of script
date

exit $retval
