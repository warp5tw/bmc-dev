/*
 * Send a Mellanox OEM command from the BMC over NC-SI
 */

#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/ether.h>
#include <unistd.h>
#include <errno.h>

#define MY_DEST_MAC0	0xff
#define MY_DEST_MAC1	0xff
#define MY_DEST_MAC2	0xff
#define MY_DEST_MAC3	0xff
#define MY_DEST_MAC4	0xff
#define MY_DEST_MAC5	0xff

#define DEFAULT_IF	"eth0"
#define BUF_SIZ		1024

void usage()
{
	printf("Usage: send_oem_cmd <command> <parameter> [<optional_parameter>]\n");
	exit(0);
}

void out_of_range()
{
	printf("One/more arguments passed are out of range\n \
Command 		: 0x0 to 0x20\n \
Parameter		: 0x0 to 0xff\n \
Optional Parameter	: 0x0 to 0xff\n");
	exit(0);
}

int main(int argc, char *argv[])
{
	int sockfd;
	struct ifreq if_idx;
	struct ifreq if_mac;
	int tx_len = 0;
	int cmd, parameter, opt = 0;
	char sendbuf[BUF_SIZ];
	struct sockaddr_ll socket_address;
	char ifName[IFNAMSIZ];

	strcpy(ifName, DEFAULT_IF);

	/* Get cmd id and parameter */
	if (argc > 2) {
		cmd = strtol(argv[1], NULL, 16);
		parameter = strtol(argv[2], NULL, 16);
		if (argc > 3)
			opt = strtol(argv[3], NULL, 16);
	}
	else
		usage();

	/* Check for cmd and parameter range */
	if ((cmd > 0x20) || (parameter > 0xff) || (opt > 0xff))
		out_of_range();

	/* Open RAW socket to send on */
	if ((sockfd = socket(AF_PACKET, SOCK_RAW, IPPROTO_RAW)) == -1) {
		perror("socket");
		return -1;
	}

	/* Get the index of the interface to send on */
	memset(&if_idx, 0, sizeof(struct ifreq));
	strncpy(if_idx.ifr_name, ifName, IFNAMSIZ);
	if (ioctl(sockfd, SIOCGIFINDEX, &if_idx) < 0) {
		perror("SIOCGIFINDEX");
		close(sockfd);
		exit(EXIT_FAILURE);
	}

	/* Get the MAC address of the interface to send on */
	memset(&if_mac, 0, sizeof(struct ifreq));
	strncpy(if_mac.ifr_name, ifName, IFNAMSIZ);
	if (ioctl(sockfd, SIOCGIFHWADDR, &if_mac) < 0) {
		perror("SIOCGIFHWADDR");
		close(sockfd);
		exit(EXIT_FAILURE);
	}

	/* Construct the Ethernet header */
	memset(sendbuf, 0, BUF_SIZ);

	/* Packet data */
	sendbuf[tx_len++] = 0xff; // dest
	sendbuf[tx_len++] = 0xff;
	sendbuf[tx_len++] = 0xff;
	sendbuf[tx_len++] = 0xff;
	sendbuf[tx_len++] = 0xff;
	sendbuf[tx_len++] = 0xff;
	sendbuf[tx_len++] = ((char *)&if_mac.ifr_hwaddr.sa_data)[5];
	sendbuf[tx_len++] = ((char *)&if_mac.ifr_hwaddr.sa_data)[4];
	sendbuf[tx_len++] = ((char *)&if_mac.ifr_hwaddr.sa_data)[3];
	sendbuf[tx_len++] = ((char *)&if_mac.ifr_hwaddr.sa_data)[2];
	sendbuf[tx_len++] = ((char *)&if_mac.ifr_hwaddr.sa_data)[1];
	sendbuf[tx_len++] = ((char *)&if_mac.ifr_hwaddr.sa_data)[0];
	sendbuf[tx_len++] = 0x88; // type
	sendbuf[tx_len++] = 0xf8;
	sendbuf[tx_len++] = 0x00; // mcid
	sendbuf[tx_len++] = 0x01; // header rev
	sendbuf[tx_len++] = 0x00; // res
	sendbuf[tx_len++] = 0xb6; // iid
	sendbuf[tx_len++] = 0x50; // type
	sendbuf[tx_len++] = 0x00; // channel
	sendbuf[tx_len++] = 0x00; // res
	sendbuf[tx_len++] = 0x08; // length
	sendbuf[tx_len++] = 0xde; // res
	sendbuf[tx_len++] = 0xad;
	sendbuf[tx_len++] = 0xbe;
	sendbuf[tx_len++] = 0xef;
	sendbuf[tx_len++] = 0xde;
	sendbuf[tx_len++] = 0xad;
	sendbuf[tx_len++] = 0xbe;
	sendbuf[tx_len++] = 0xef;
	sendbuf[tx_len++] = 0x00; // mfid
	sendbuf[tx_len++] = 0x00;
	sendbuf[tx_len++] = 0x81;
	sendbuf[tx_len++] = 0x19;
	sendbuf[tx_len++] = 0x00; // cmd_rev
	sendbuf[tx_len++] = cmd; // cmd_id
	sendbuf[tx_len++] = parameter; // parameter
	sendbuf[tx_len++] = opt; // extra parameter
	sendbuf[tx_len++] = 0x00; // pad
	sendbuf[tx_len++] = 0x00;
	sendbuf[tx_len++] = 0x00;
	sendbuf[tx_len++] = 0x00;
	sendbuf[tx_len++] = 0x00; // chksum
	sendbuf[tx_len++] = 0x00;
	sendbuf[tx_len++] = 0x00;
	sendbuf[tx_len++] = 0x00;

	/* Index of the network device */
	socket_address.sll_ifindex = if_idx.ifr_ifindex;
	/* Address length*/
	socket_address.sll_halen = ETH_ALEN;
	/* Destination MAC */
	socket_address.sll_addr[0] = MY_DEST_MAC0;
	socket_address.sll_addr[1] = MY_DEST_MAC1;
	socket_address.sll_addr[2] = MY_DEST_MAC2;
	socket_address.sll_addr[3] = MY_DEST_MAC3;
	socket_address.sll_addr[4] = MY_DEST_MAC4;
	socket_address.sll_addr[5] = MY_DEST_MAC5;

	/* Send packet */
	if (sendto(sockfd, sendbuf, tx_len, 0, 
			(struct sockaddr*)&socket_address,
			sizeof(struct sockaddr_ll)) < 0) {
		printf("Send failed: %s", strerror(errno));
		close(sockfd);
		exit(EXIT_FAILURE);
	}

	close(sockfd);
	return 0;
}
