#!/bin/bash

# Date modified: 04/11/2018

# This script executes voltage margining tests for
# TPS53915 on Bluewhale 1U and 2U
#
# Type 'mlnx_tps53915_voltage_margin help' to seek help on how to use
# this script

#
#Macros
#

DC2DC_PWR_SUPPLY_BUS=7
#PMBus commands
OPERATION=0x1
ON_OFF_CONFIG=0x2
VOUT_MARGIN=0xd5

PWR_SEQUENCER_BUS=10
BF_PWR_SEQUENCER_ADDR=0x21
#PMBus commands
OUTPUT_STATUS1=0x4

progname=$0
addr_or_powercycle=$1

trash="/tmp/trash.$$"

#
# Helper functions
#

# Usage msg format:
# "< >" is for positional arguments
# "[ ]" is for optional
# "|" is for mutually exclusive
# "( )" is for required
print_usage_msg() {

cat<<USAGE_EOF
Invalid input arguments
Usage: $progname <addr_or_powercycle> <fault> <margin>
(<low_margin_percentage> | <high_margin_percentage> | default |
<low_margin_percentage> <high_margin_percentage>)

<addr_or_powercycle> options:
    '0x1b' for 1.2 V BF SERDES
    '0x1f' for 0.9 V BF DDR
    'powercycle' to powercycle the system. This command can be
    used in the case where the user ran a margin test that
    triggered an overvoltage or undervoltage response; which
    caused the power off of some device(s)

<fault> options: 'ignore' 'act'
<margin> options: 'none' 'low' 'high' 'all'
if <margin> = 'low',
    <low_margin_percentage> is the desired low margin percentage
if <margin> = 'high',
    <high_margin_percentage> is the desired high margin percentage
if <margin> = 'all':
    'default' option sets low margin to -5.2% and high margin to +4.7%
    <low_margin_percentage> <high_margin_percentage>
    are set to the desired low margin and high margin respectively

Pick a low margin percentage:
-0
-1.1
-2.1
-3.2
-4.2
-5.2
-6.2
-7.1
-8.1
-9.0
-9.9
-10.7
-11.6

Pick a high margin percentage:
12.0
10.9
9.9
8.8
7.7
6.7
5.7
4.7
3.7
2.8
1.8
0.9
0
USAGE_EOF

exit 2

#close print_usage_msg
}

# Function which converts the margin percentage
# to a voltage value.
# $1 is the nominal voltage value: 1.2 V or 0.9 V
# $2 is the desired margin percentage
# high margin vout = nominal + (nominal * pct)/100
# low margin vout = nominal - (nominal * pct)/100
pct2volt () {
    __sign="$2"
    __sign=${__sign:0:1}

    if [ "$__sign" == "-" ]; then
        __val=$(echo "$2" | cut -d "-" -f2)
        __vout=$(echo $1 $__val 100 | awk '{print $1*$2/$3}')
        __vout=$(echo $1 $__vout | awk '{print $1-$2}')
    else
        __vout=$(echo $1 $2 100 | awk '{print $1*$2/$3}')
        __vout=$(echo $1 $__vout | awk '{print $1+$2}')
    fi

    echo $__vout
}

# Function used to convert a margin percentage
# to its corresponding hex value
# Input argument:
# $1 is the margin percentage
pct2hex () {
    case "$1" in
        "-0")
            ;&
        "0")
            echo 0x0;;
        "-1.1")
            ;&
        "0.9")
            echo 0x1;;
        "-2.1")
            ;&
        "1.8")
            echo 0x2;;
        "-3.2")
            ;&
        "2.8")
            echo 0x3;;
        "-4.2")
            ;&
        "3.7")
            echo 0x4;;
        "-5.2")
            ;&
        "4.7")
            echo 0x5;;
        "-6.2")
            ;&
        "5.7")
            echo 0x6;;
        "-7.1")
            ;&
        "6.7")
            echo 0x7;;
        "-8.1")
            ;&
        "7.7")
            echo 0x8;;
        "-9.0")
            ;&
        "8.8")
            echo 0x9;;
        "-9.9")
            ;&
        "9.9")
            echo 0xa;;
        "-10.7")
            ;&
        "10.9")
            echo 0xb;;
        "-11.6")
            ;&
        "12.0")
            echo 0xc;;
        *)
            echo invalid;;
    esac
}

# Function which reads the current output voltage
# Input argument:
# $1 is the ispPAC-PWR1014A VMON id
get_vmon() {
    __in=$(cat /sys/bus/i2c/devices/10-0021/hwmon/hwmon9/in$1_input)
    __vmon=$(echo $__in 1000 | awk '{print $1/$2}')

    echo $__vmon V
}

# Function that checks whether an I2C device is present or not.
# If the device is not found, an informative message is printed
# and the script is exited immediately with error=1
# Input arguments:
# $1 is the I2C bus of the device
# $2 is the device's I2C address
# $3 is a PMBus command
is_device_present () {
    i2cget -y -f $1 $2 $3 &> $trash

    if [ $? -ne 0 ]; then
        echo "Unable to read bus $1, device $2, register $3"
        echo "Exiting the script without completion"
        exit 1
    fi
}

#
# Script starts here
#

if [ "$addr_or_powercycle" == "0x1b" ] ||
    [ "$addr_or_powercycle" == "0x1f" ]; then

    # $1 is the device's I2C address:
    #   - 0x1b for 1.2 V BF SERDES
    #   - 0x1f for 0.9 V BF DDR
    # $2 is the fault handling option: ignore, act
    # $3 is the margin option: none, low, high, all
    #   If "none" is selected, no more arguments are needed.
    #   The voltage will adjust to its default value
    #   (1.2V or 0.9V). Note that the ignore/act bits
    #   are "don't cares" for margin 'none'.
    # $4, $5 are the margin voltage percentages:
    #   - if $3="low", $4 is the low margin percentage
    #   - if $3="high", $4 is the high margin percentage
    #   - if $3="all":
    #       - if $4 = "default", we use default margin
    #         percentages -5.2% and +4.7%
    #       - if user wants to set his own values, then
    #         $4 is low margin percentage
    #         $5 is high margin percentage
    # command example: mlnx_tps53915_voltage_margin 0x1b ignore low -3.2
    #                  mlnx_tps53915_voltage_margin 0x1b ignore none
    #                  mlnx_tps53915_voltage_margin 0x1f ignore all default
    #                  mlnx_tps53915_voltage_margin 0x1f act all -3.2 7.7

    addr=$1
    fault=$2
    margin=$3

    # Before doing any i2cget or i2cset, check whether the devices that we
    # are reading are present
    is_device_present $PWR_SEQUENCER_BUS $BF_PWR_SEQUENCER_ADDR $OUTPUT_STATUS1
    is_device_present $DC2DC_PWR_SUPPLY_BUS $addr $VOUT_MARGIN

    if [ "$fault" != "ignore" ] && [ "$fault" != "act" ]; then
        print_usage_msg
    fi

    case $margin in
        "none")
            if [ $# -gt 3 ]; then
                print_usage_msg
            fi
            ;;
        "low")
            ;&
        "high")
            if [ $# -ne 4 ]; then
                print_usage_msg
            fi
            ;;
        "all")
            if [ $# -ne 5 ]; then
                if [ "$4" != "default" ]; then
                    print_usage_msg
                elif [ "$4" == "default" ] && [ $# -gt 4 ]; then
                    print_usage_msg
                fi
            fi
            ;;
        *)
            print_usage_msg
            ;;
    esac #margin

    echo -e '\n'starting script @ `date`

    # Initialize OPERATION register to its
    # default value. Voltage initially set
    # to nominal value.
    i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0x80

    # ON_OFF_CONFIG (offset: 0x2)
    # Bit   Description
    # 7:5   -
    # 4     Always 1
    # 3     0: ignore ON_OFF bit (OPERATION)
    #       1: act on ON_OFF bit (OPERATION)
    # 2     0: ignore EN pin
    #       1: act on EN pin
    # 1:0   -
    #
    # We could also make it 0x1f
    i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $ON_OFF_CONFIG 0x1b

    if [ "$addr" == "0x1b" ]; then
        nominal=1.2
        vmon=7
    else
        nominal=0.9
        vmon=4
    fi

    # OPERATION (offset: 0x1)
    # Bit   Description
    # 7     ON_OFF
    #       0: turn off switching converter
    #       1: turn on switching converter
    # 6     -
    # 5:2   OPMARGIN
    #       00xx: margin none
    #       0101: margin low/ignore fault
    #       0110: margin low/act
    #       1001: margin high/ignore
    #       1010: margin high/act
    # 1:0   -

    case $margin in
        "none")
            echo "**********************************"
            echo "Test running: Voltage margin none"
            echo "Target Vout: $nominal V"
            echo -e '\n'"Vout is currently set to $(get_vmon $vmon)"
            echo "**********************************"
            ;;

        "low")
            echo "**********************************"
            echo "Test running: Voltage margin low"
            vout_dec=$(pct2volt $nominal $4)
            vout_hex=$(pct2hex $4)

            if [ "$vout_hex" == "invalid" ]; then
                echo Invalid margin percentage
                echo exit script without completing test
                echo "Type '$progname help' for the list of percentages"
                exit 2
            fi

            echo "Low margin percentage: $4 %"
            echo "Target Vout: $vout_dec V"

            # Set [3:0] bits in VOUT_MARGIN cmd
            # aka MFR_SPECIFIC_05 (offset: 0xd5)
            i2cset -y -f 7 $addr $VOUT_MARGIN $vout_hex

            if [ "$fault" == "ignore" ]; then
                echo ignore faults
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0x94
            else
                echo act on faults
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0x98
            fi
            echo -e '\n'"Vout is currently set to $(get_vmon $vmon)"
            echo "**********************************"
            ;;

        "high")
            echo "**********************************"
            echo "Test running: Voltage margin high"
            vout_dec=$(pct2volt $nominal $4)
            vout_hex=$(pct2hex $4)

            if [ "$vout_hex" == "invalid" ]; then
                echo Invalid margin percentage
                echo exit script without completing test
                echo "Type '$progname help' for the list of percentages"
                exit 2
            fi

            echo "High margin percentage: $4 %"
            echo "Target Vout: $vout_dec V"

            # VOMH is the upper 4 bits of 0xd5 register
            # For simplicity, pct2hex returns only 4 bits
            # so we need to left shift vout_hex by 4 to
            # take into account the 4 lower bits (all zero)
            # dedicated to VOML
            vout_hex=$(echo $vout_hex"0")

            # Set [3:0] bits in VOUT_MARGIN cmd
            i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $VOUT_MARGIN $vout_hex

            if [ "$fault" == "ignore" ]; then
                echo ignore faults
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0xa4
            else
                echo act on faults
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0xa8
            fi
            echo -e '\n'"Vout is currently set to $(get_vmon $vmon)"
            echo "**********************************"
            ;;

        "all")
            echo "**********************************"
            echo "Test running: Voltage margin none"
            echo "Target Vout: $nominal V"
            echo -e '\n'"Vout is currently set to $(get_vmon $vmon)"
            echo "**********************************"

            if [ "$4" == "default" ]; then
                # Low margin voltage = (nominal - 5.2%)
                # High margin voltage = (nominal + 4.7%)
                voml=-5.2
                vomh=4.7
                low_vout_dec=$(pct2volt $nominal $voml)
                high_vout_dec=$(pct2volt $nominal $vomh)

                # set VOUT_MARGIN[7:0]=0x55
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $VOUT_MARGIN 0x55
            else
                voml=$4
                vomh=$5
                low_vout_dec=$(pct2volt $nominal $voml)
                high_vout_dec=$(pct2volt $nominal $vomh)

                high_vout_hex=$(pct2hex $vomh)
                low_vout_hex=$(pct2hex $voml)
                low_vout_hex=$(echo "$low_vout_hex" | cut -d "x" -f2)
                # Concatenating low and high nibbles
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $VOUT_MARGIN $high_vout_hex$low_vout_hex

                if [ "$low_vout_hex" == "invalid" ] ||
                   [ "$high_vout_hex" == "invalid" ]; then
                    echo Invalid margin percentage
                    echo exit script without completing test
                    echo "Type '$progname help' for the list of percentages"
                    exit 2
                fi
            fi

            if [ "$fault" == "ignore" ]; then
                echo "Test running: Voltage margin low, ignore faults"
                echo "Low margin percentage: $voml %"
                echo "Target Vout: $low_vout_dec V"
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0x94
                # need some delay to allow the output voltage to adjust
                # before reading it
                sleep 1
                echo -e '\n'"Vout is currently set to $(get_vmon $vmon)"
                echo "************************************************"
                echo "Test running: Voltage margin high, ignore faults"
                echo "High margin percentage: $vomh %"
                echo "Target Vout: $high_vout_dec V"
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0xa4
                sleep 1
                echo -e '\n'"Vout is currently set to $(get_vmon $vmon)"
                echo "************************************************"
            else
                echo "Test running: Voltage margin low, act on faults"
                echo "Low margin percentage: $voml %"
                echo "Target Vout: $low_vout_dec V"
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0x98
                sleep 1
                echo -e '\n'"Vout is currently set to $(get_vmon $vmon)"
                echo "************************************************"
                echo "Test running: Voltage margin high, act on faults"
                echo "High margin percentage: $vomh %"
                echo "Target Vout: $high_vout_dec V"
                i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $OPERATION 0xa8
                sleep 1
                echo -e '\n'"Vout is currently set to $(get_vmon $vmon)"
                echo "************************************************"
            fi
            ;;
        *)
            # We should never get here
            ;;
    esac #margin

    # reset ON_OFF_CONFIG to the default value
    i2cset -y -f $DC2DC_PWR_SUPPLY_BUS $addr $ON_OFF_CONFIG 0x17

    output_status1=$(i2cget -y -f $PWR_SEQUENCER_BUS $BF_PWR_SEQUENCER_ADDR $OUTPUT_STATUS1)
    if [ "$output_status1" != "0xd4" ]; then
        echo "An overvoltage or undervoltage response occured,"
        echo "which turned off the power of some device(s)."
        echo "Run '$progname powercycle' to turn the power"
        echo "back on"
    fi

    echo -e '\n'end of script @ `date`

elif [ "$addr_or_powercycle" == "powercycle" ] && [ $# -eq 1 ]; then

    # If the voltage exceeded the overvoltage limit or undervoltage limit,
    # then the VOUT_OV_FAULT_RESPONSE or the VOUT_UV_FAULT_RESPONSE
    # registers (if they are set to 0x80) will
    # cause the device to latch off and not restart. To clear the shutdown
    # event due to fault event, we need to toggle the AVR_EN/BEN pin.
    # In order to do that, we need to power cycle from the BMC.
    # On the BF power sequencer ispPAC-POWR1014A, OUTPUT_STATUS1
    # gives the status of the digital output:
    # OUT9 -> 0P9_BF_DDR_EN -> EN pin of TPS53915
    # OUT12 -> 1P2_BF_SERDES -> EN pin of TPS53915
    # CONTROL pins are active low
    is_device_present $PWR_SEQUENCER_BUS $BF_PWR_SEQUENCER_ADDR $OUTPUT_STATUS1
    output_status1=$(i2cget -y -f $PWR_SEQUENCER_BUS $BF_PWR_SEQUENCER_ADDR $OUTPUT_STATUS1)
    if [ "$output_status1" != "0xd4" ]; then
        /usr/sbin/mlnx_powercycle_bf
    else
        echo No need to power cycle, all device are on
    fi

else
    print_usage_msg
fi

rm $trash
