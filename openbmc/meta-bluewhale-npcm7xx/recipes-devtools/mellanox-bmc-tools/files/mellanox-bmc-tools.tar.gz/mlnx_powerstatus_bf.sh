#!/bin/bash

# Date modified: 04/19/2019

# Report the power status of the BlueField.
# If up, return 1,
# If down, return 0
# If unable to read the status at this time, return 2

# From Aspeed GPIO driver sysfs, get base number for GPIO access
GPIO_BASE=$(cat /sys/devices/platform/ahb/ahb:apb/1e780000.gpio/gpio/*/base)

# Use base number to calculate GPIO number for pin 218
GPIO_NUM_218=$(($GPIO_BASE + 218))

# If any other script is using GPIO pin 218, exit this script,
# and try again later.
if [ -d /sys/class/gpio/gpio${GPIO_NUM_218} ]; then
	echo Unable to report power status at this time. Try again.
	exit 2
fi

echo ${GPIO_NUM_218} > /sys/class/gpio/export

# read current gpio pin value
currval218=$(cat /sys/class/gpio/gpio${GPIO_NUM_218}/value)

echo ${GPIO_NUM_218} > /sys/class/gpio/unexport

if [ $currval218 -eq 1 ]; then
	echo BlueField is ON
	exit 1
fi

echo BlueField is OFF
exit 0
