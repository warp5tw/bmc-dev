#!/bin/bash

# Date modified: 01/30/2019

# This script powers up the BF via the BMC GPIO pins 218 and 219.
# S_BMC_POWER_CYC_ACK_L corresponds to pin 218;
# it is connected to the KILL_L pin of LTC2954.
# The BMC can turn off power by setting KILL_L to low.
#
# S_BMC_POWER_CYCLE_L corresponds to pin 219;
# it is connected to the PB_L pin of LTC2954.
# A high to low transition on PB_L initiates the power
# on sequence. The KILL_L must be pulled high
# for the system to restart

echo Powering Up BlueField

# From Aspeed GPIO driver sysfs, get base number for GPIO access
GPIO_BASE=$(cat /sys/devices/platform/ahb/ahb:apb/1e780000.gpio/gpio/*/base)

# Use base number to calculate GPIO numbers for pins 218,219
GPIO_NUM_218=$(($GPIO_BASE + 218))
GPIO_NUM_219=$(($GPIO_BASE + 219))

echo ${GPIO_NUM_218} > /sys/class/gpio/export
echo ${GPIO_NUM_219} > /sys/class/gpio/export

# read current gpio pin values
currval218=$(cat /sys/class/gpio/gpio${GPIO_NUM_218}/value)
if [ $currval218 -eq 1 ]; then
	init218=high
else
	init218=low
fi
currval219=$(cat /sys/class/gpio/gpio${GPIO_NUM_219}/value)
if [ $currval219 -eq 1 ]; then
	init219=high
else
	init219=low
fi

# change direction to 'out' retaining the initial state
echo $init218 > /sys/class/gpio/gpio${GPIO_NUM_218}/direction
echo $init219 > /sys/class/gpio/gpio${GPIO_NUM_219}/direction

# check if the chassis is already on
status=$(cat /sys/class/gpio/gpio${GPIO_NUM_218}/value)
if [ $status -eq 1 ]; then
	echo BlueField is already ON
else
	# deassert KILL_L
	echo 1 > /sys/class/gpio/gpio${GPIO_NUM_218}/value
	sleep 1
	# turn on the system
	echo 1 > /sys/class/gpio/gpio${GPIO_NUM_219}/value
	sleep 1
	echo 0 > /sys/class/gpio/gpio${GPIO_NUM_219}/value
	sleep 1
	echo BlueField is ON
fi

echo ${GPIO_NUM_218} > /sys/class/gpio/unexport
echo ${GPIO_NUM_219} > /sys/class/gpio/unexport

# Finally bring the NC-SI port up
ifconfig eth0 up
