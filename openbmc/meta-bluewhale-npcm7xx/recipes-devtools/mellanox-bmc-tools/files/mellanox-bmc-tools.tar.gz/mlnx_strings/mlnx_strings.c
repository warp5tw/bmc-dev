/*
 * mlnx_strings [backup-uboot | backup-linux]
 *
 * This program opens a read-only memory window over the specified image
 * region and then displays all printable strings found there.  The typical
 * use case is to pipe the output of this program into 'grep' since there
 * is a target string pattern to be found for each image region.
 *
 * For example, "mlnx_strings backup-linux | grep Linux" will display the
 * Linux version string found in the backup Linux image region.
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <ctype.h>
#include <string.h>

#define BACKUP_FLASH_BASE      0x22000000 /* physical addr of backup flash */
#define BACKUP_UBOOT_OFFSET    0x00000000
#define BACKUP_LINUX_OFFSET    0x00070000

#define BACKUP_UBOOT_MMAP_LEN  0x60000
#define BACKUP_LINUX_MMAP_LEN  256

void usage()
{
    printf("Usage: mlnx_strings [backup-uboot | backup-linux]\n");
    printf("\n");
    printf("       backup-uboot: display strings found in backup U-Boot image storage\n");
    printf("       backup-linux: display strings found in backup Linux image storage\n");
    printf("\n");
}

int main(int argc, char **argv)
{
    int            fd;
    int            print_mode = 0;
    size_t         page_size;
    off_t          phys_addr;
    size_t         len;
    off_t          page_base;
    off_t          page_offset;
    unsigned char *mem;
    size_t         i;
    int            rc;

    if (argc != 2)
    {
        usage();
        return 0;
    }

    /* Based on specified region, set phys_addr and len appropriately */
    if (strcmp(argv[1],"backup-uboot") == 0)
    {
        /* Looking for value of U-Boot's "version_string", which may be */
        /* anywhere in the U-Boot backup image.  To provide adequate    */
        /* coverage, open a memory window over the entire backup U-Boot */
        phys_addr = (BACKUP_FLASH_BASE + BACKUP_UBOOT_OFFSET);
        len = BACKUP_UBOOT_MMAP_LEN;
    }
    else if (strcmp(argv[1],"backup-linux") == 0)
    {
        /* Create a memory window large enough to work for both "legacy"  */
        /* Linux format (i.e. separate MTD partitions for DTB, uImage,    */
        /* and initramfs) as well as fitImage format (single partition    */
        /* containing all three components)                               */
        /*                                                                */
        /* Legacy Linux format:                                           */
        /* Looking for value of "ih_name" (32 byte string) from the image */
        /* header data structure (image_header_t) at offset 0 in uImage.  */
        /* The "ih_name" field is at offset 0x20 in the image header.     */
        /*                                                                */
        /* fitImage format:                                               */
        /* Looking for string with "fitImage" keyword in first 256 bytes  */
        /* The Linux version is embedded in this "fitImage" string.       */
        phys_addr = (BACKUP_FLASH_BASE + BACKUP_LINUX_OFFSET);
        len = BACKUP_LINUX_MMAP_LEN;
    }
    else
    {
        printf("%s: invalid input\n",argv[0]);
        usage();
        return 0;
    }

    /* Get page size parameter from system configuration */
    page_size = sysconf(_SC_PAGE_SIZE);

    /* Round phys_addr to a multiple of the page size, or mmap will fail */
    page_base = (phys_addr / page_size) * page_size;
    page_offset = phys_addr - page_base;

    /* Open /dev/mem with read-only privilege */
    fd = open("/dev/mem", O_RDONLY, 0);
    if (fd == -1)
    {
        perror("Can't open /dev/mem");
        return -1;
    }

    /* Open a readonly window to the specified address range */
    mem = mmap(NULL, page_offset + len, PROT_READ, MAP_PRIVATE, fd, page_base);
    if (mem == MAP_FAILED)
    {
        perror("Can't map memory");
        return -1;
    }

    for (i = 0; i < len; ++i)
    {
        /* Print character only if it is printable */
        if (isprint(mem[page_offset + i]))
        {
            printf("%c",mem[page_offset + i]);

            /* Declare that we are in print mode */
            print_mode = 1;
        }
        else
        {
            if (print_mode)
            {
                /* Print a single newline when switching out of print mode */
                printf("\n");
                print_mode = 0;
            }
        }
    }

    rc = munmap(mem, page_offset + len);
    if (rc == -1)
    {
        perror("Can't unmap memory");
        return -1;
    }

    close(fd);

    return 0;
}
