/*
 * CPLD I2C register access
 */

#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <libgen.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>

static int open_i2c_dev(int i2cbus)
{
  char filename[20] = { 0 };
  int file;

  snprintf(filename, sizeof(filename), "/dev/i2c/%d", i2cbus);
  file = open(filename, O_RDWR);
  if (file < 0 && (errno == ENOENT || errno == ENOTDIR)) {
    snprintf(filename, sizeof(filename), "/dev/i2c-%d", i2cbus);
    file = open(filename, O_RDWR);
  }

  if (file < 0) {
    if (errno == ENOENT) {
      fprintf(stderr, "Error: Could not open file `/dev/i2c-%d' or "
              "`/dev/i2c/%d': %s\n", i2cbus, i2cbus, strerror(ENOENT));
    } else {
      fprintf(stderr, "Error: Could not open file `%s': %s\n",
              filename, strerror(errno));
      if (errno == EACCES)
        fprintf(stderr, "Run as root?\n");
    }
  }

  return file;
}

static int set_slave_addr(int file, int address, int force)
{
  /* With force, let the user read from/write to the registers
     even when a driver is also running */
  if (ioctl(file, force ? I2C_SLAVE_FORCE : I2C_SLAVE, address) < 0) {
    fprintf(stderr, "Error: Could not set address to 0x%02x: %s\n",
            address, strerror(errno));
    return -errno;
  }

  return 0;
}

static int i2c_smbus_access(int file, char read_write, uint8_t command,
                            int size, union i2c_smbus_data *data)
{
  struct i2c_smbus_ioctl_data args;
  int err;

  args.read_write = read_write;
  args.command = command;
  args.size = size;
  args.data = data;

  err = ioctl(file, I2C_SMBUS, &args);
  if (err == -1)
    err = -errno;
  return err;
}

static int i2c_smbus_write_byte_data(int file, uint8_t cmd, uint8_t value)
{
  union i2c_smbus_data data;
  data.byte = value;
  return i2c_smbus_access(file, I2C_SMBUS_WRITE, cmd,
                          I2C_SMBUS_BYTE_DATA, &data);
}

static int i2c_smbus_write_word_data(int file, uint8_t command, uint16_t value)
{
  union i2c_smbus_data data;
  data.word = value;
  return i2c_smbus_access(file, I2C_SMBUS_WRITE, command,
                          I2C_SMBUS_WORD_DATA, &data);
}

static int i2c_smbus_read_byte(int file)
{
  union i2c_smbus_data data;
  int err;

  err = i2c_smbus_access(file, I2C_SMBUS_READ, 0, I2C_SMBUS_BYTE, &data);
  if (err < 0)
    return err;

  return 0x0FF & data.byte;
}

static int cpld_write_byte(int i2cbus, int slave, uint16_t addr, uint8_t val)
{
  int force = 1;
  uint16_t data;
  int file;
  int rc;

  file = open_i2c_dev(i2cbus);
  if (file < 0 || set_slave_addr(file, slave, force))
    return -1;

  data = (val << 8) | (addr & 0xFF);
  rc = i2c_smbus_write_word_data(file, addr >> 8, data);

  close(file);
  return rc;
}

static int cpld_read_byte(int i2cbus, int slave, uint16_t addr)
{
  int force = 1;
  int file;
  int rc;

  file = open_i2c_dev(i2cbus);
  if (file < 0 || set_slave_addr(file, slave, force))
    return -1;

  rc = i2c_smbus_write_byte_data(file, addr >> 8, addr & 0xFF);
  if (rc < 0)
    fprintf(stderr, "Warning - write failed\n");

  rc = i2c_smbus_read_byte(file);
  close(file);
  return rc;
}

void usage()
{
  printf("Usage: mlnx_cpldaccess [-mb | -bp] [-r <addr> | -w <addr> <data> | -d]\n");
  printf("-mb              : access motherboard cpld\n");
  printf("-bp              : access backplane cpld\n");
  printf("-r <addr>        : read from <addr>\n");
  printf("-w <addr> <data> : write <data> to <addr>\n");
  printf("-d               : dump contents of all registers\n");

  exit(1);
}

int main(int argc, char *argv[])
{
  uint8_t i2cbus, slave, reg_num, data, i;
  uint16_t addr;
  unsigned char val;
  char *end;

  if (argc < 3)
    usage();

  if (!strcmp(argv[1], "-mb")) {
    i2cbus = 4;
    slave = 0x40;
    reg_num = 32;
  }
  else if (!strcmp(argv[1], "-bp")) {
    i2cbus = 1;
    slave = 0x42;
    reg_num = 32;
  }
  else
    usage();

  if (!strcmp(argv[2], "-r")) {
    if (argc != 4)
      usage();
    addr = strtoul(argv[3], &end, 16);
    val = cpld_read_byte(i2cbus, slave, addr);
    printf("Addr: 0x%x --> Data: 0x%x\n", addr, val);
    return 0;
  }
  else if (!strcmp(argv[2], "-w")) {
    if (argc != 5)
      usage();
    addr = strtoul(argv[3], &end, 16);
    data = strtoul(argv[4], &end, 16);
    val = cpld_write_byte(i2cbus, slave, addr, data);
    if (val == 0)
      printf("Write successful!\n");
    return 0;
  }
  else if (!strcmp(argv[2], "-d")) {
    printf("Addr --> Data\n");
    for (i = 0; i < reg_num; i++) {
      val = cpld_read_byte(i2cbus, slave, i);
      printf("0x%04x --> 0x%02x\n", i, val);
    }
    return 0;
  }
  else
    usage();
}
