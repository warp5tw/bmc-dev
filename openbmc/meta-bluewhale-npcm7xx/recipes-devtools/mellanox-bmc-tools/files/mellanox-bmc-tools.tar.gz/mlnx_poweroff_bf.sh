#!/bin/bash

# Date modified: 01/30/2019

# This script powers off the BF via the BMC GPIO pin 218.
# S_BMC_POWER_CYC_ACK_L corresponds to pin 218;
# it is connected to the KILL_L pin of LTC2954.
# The BMC can turn off power by setting KILL_L to low.

echo Powering Down BlueField

# Before powering off the BlueField, it is safer to take down
# the NC-SI port. Else, if the driver is in the middle of a transaction,
# it is unaware of the link going down and dumps a stack trace.
# Bring it back up when powering up BlueField.
ifconfig eth0 down

# From Aspeed GPIO driver sysfs, get base number for GPIO access
GPIO_BASE=$(cat /sys/devices/platform/ahb/ahb:apb/1e780000.gpio/gpio/*/base)

# Use base number to calculate GPIO numbers for pin 218
GPIO_NUM_218=$(($GPIO_BASE + 218))

echo ${GPIO_NUM_218} > /sys/class/gpio/export

# read current gpio pin value
currval218=$(cat /sys/class/gpio/gpio${GPIO_NUM_218}/value)
if [ $currval218 -eq 1 ]; then
	init218=high
else
	init218=low
fi

# change direction to 'out' retaining the initial state
echo $init218 > /sys/class/gpio/gpio${GPIO_NUM_218}/direction

# check if the chassis is already off
status=$(cat /sys/class/gpio/gpio${GPIO_NUM_218}/value)
if [ $status -eq 0 ]; then
	echo BlueField is already OFF
else
	#turn off system
	echo 0 > /sys/class/gpio/gpio${GPIO_NUM_218}/value
	# wait
	sleep 1
	echo BlueField is OFF
fi

echo ${GPIO_NUM_218} > /sys/class/gpio/unexport
