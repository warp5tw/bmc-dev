#!/bin/sh

# Last modified: 06/18/2018
#
# Script to program the MOBO and BF power sequencers.
# These 2 devices were linked to form a JTAG chain. The TDO of the
# MOBO power sequencer becomes the TDI of the BF power sequencer.
# TMS and TCK signals are common to both devices in the chain.
# So we need only one SVF file to program both as shown below:
#
#    <isp-firmware-file.svf> is a SVF firmware file
#
# TODO:
# This script calls mlnx_cpldprog which is built by /mlnx_cpldprog/Makefile
# and used in the obmc-update_cpld.sh as well.
# In the future, we will need to move obmc-update_seq.sh under /mlnx_cpldprog
# and rename that directory /mlnx_jtagprog. We will also need to change the
# name of the executable file from mlnx_cpldprog to mlnx_jtagprog.
# For now, we have decided to not modify the name of existing files or
# directories since we don't want unnecessary complications when merging
# our code with Baidu's (merge scheduled for the upcoming months).

SEQ_FIRMWARE_BKP=0
SEQ_FIRMWARE_BKP_PATH=/usr/share

# To enable the power sequencers' JTAG programming, gpio 32 and 33
# should be set as follows:
# GP_BMC_CPLD_FU_EN_L - gpio32 set to high
# GP_BMC_SEQ_FU_EN_L - gpio33 set to low

# From Aspeed GPIO driver sysfs, get base number for GPIO access
GPIO_BASE=$(cat /sys/devices/platform/ahb/ahb:apb/1e780000.gpio/gpio/*/base)

# Use base number to calculate GPIO numbers for pins 32,33
GPIO_NUM_32=$(($GPIO_BASE + 32))
GPIO_NUM_33=$(($GPIO_BASE + 33))

GPIO_PATH=/sys/class/gpio
CPLD_GPIO=gpio${GPIO_NUM_32}
SEQ_GPIO=gpio${GPIO_NUM_33}

if [ ! -e /dev/aspeed-jtag ]; then
    echo "/dev/aspeed-jtag interface not found"
    exit
fi

if [ ! -f $1 ]; then
    echo "SVF firmware file not found"
    exit
fi

echo "Configure JTAG mux control pins"
if [ ! -d $GPIO_PATH/$CPLD_GPIO ]; then
    echo ${GPIO_NUM_32} > /sys/class/gpio/export
fi
if [ ! -d $GPIO_PATH/$SEQ_GPIO ]; then
    echo ${GPIO_NUM_33} > /sys/class/gpio/export
fi

echo out > $GPIO_PATH/$CPLD_GPIO/direction
echo out > $GPIO_PATH/$SEQ_GPIO/direction
echo 1 > $GPIO_PATH/$CPLD_GPIO/value
echo 0 > $GPIO_PATH/$SEQ_GPIO/value
/usr/sbin/.mlnx_cpldprog -infile $1 -prog /dev/aspeed-jtag
rv=$?

if [ SEQ_FIRMWARE_BKP = 1 ]; then
    #create backup file
    SVF_FILE=$(basename $1)
    tar cvzf $SEQ_FIRMWARE_BKP_PATH/$SVF_FILE.tar.gz $1 &2>null
fi

echo "Disable JTAG mux control pins"
echo in > $GPIO_PATH/$CPLD_GPIO/direction
echo in > $GPIO_PATH/$SEQ_GPIO/direction

if [ $rv -lt 0 ]; then
    echo "Failed to program the power sequencers"
else
    echo "MOBO and BF Power sequencers programmed successfully"
fi

sleep 1
