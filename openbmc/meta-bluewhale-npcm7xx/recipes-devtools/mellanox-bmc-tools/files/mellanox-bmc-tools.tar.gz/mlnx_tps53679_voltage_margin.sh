#!/bin/bash

# Date modified: 04/11/2018

# This script executes voltage margining tests for
# TPS53679 on Bluewhale 1U and 2U
# This script can return the following errors:
# '1' for I2C access error
# '2' for command line error
#
# Type 'mlnx_tps53679_voltage_margin help' to seek help on how to use
# this script

# Macros

PWR_SEQUENCER_BUS=10
BF_PWR_SEQUENCER_ADDR=0x21
#PMBus commands
OUTPUT_STATUS0=0x3

VRD_BUS=11
TPS53679_ADDR=0x58
#PMBus commands
PAGE=0x0
OPERATION=0x1
ON_OFF_CONFIG=0x2
VOUT_MODE=0x20
VOUT_COMMAND=0x21
VOUT_MARGIN_HIGH=0x25
VOUT_MARGIN_LOW=0x26
READ_VOUT=0x8b
MFR_SPECIFIC_02=0xd2

progname=$0
channel_or_powercycle=$1

trash="/tmp/trash.$$"

#
# Helper functions
#

# Usage msg format:
# "< >" is for positional arguments
# "[ ]" is for optional
# "|" is for mutually exclusive
# "( )" is for required
print_usage_msg() {

cat<<USAGE_EOF
Invalid input arguments
Usage: $progname <channel_or_powercycle> <fault>
<margin> (<nominal_vout> | <low_margin_vout> | <high_margin_vout> |
default | <nominal_vout> <low_margin_vout> <high_margin_vout>)

<channel_or_powercycle> options:
    'a' for VCORE
    'b' for BF DDR 1.2 V
    'powercycle' to powercycle the system. This command can be
    used in the case where the user ran a margin test that
    triggered an overvoltage or undervoltage response; which
    caused the power off of some device(s)
<fault> options: 'ignore' 'act'
<margin> options: 'none' 'low' 'high' 'all'

if <margin> = 'none',
    <nominal_vout> is the desired nominal vout in volts
if <margin> = 'low',
    <low_margin_vout> is the desired low margin vout in volts
if <margin> = 'high',
    <high_margin_vout> is the desired high margin vout in volts
if <margin> = 'all',
    'default' sets low margin vout and high margin vout to -/+5% of the nominal voltage
    <nominal_vout> <low_margin_vout> <high_margin_vout> are set to the desired nominal
    vout, low margin and high margin respectively

    For channel a, pick a voltage between 0.25 and 1.52 V with 0.005 V increment
    For channel b, pick a voltage between 0.50 and 2.50 V with 0.01 V increment
USAGE_EOF

exit 2

# close print_usage_msg
}

# Function that maps target voltage entered in the command line
# to a VID hex value. Refer to the TPS53679 spec sheet for more details.
# Channel a is  associated with VR13 5mV and Channel b is
# associated with VR13 10mV.
# Input argument:
# $1 is the value in Volts that we want to convert to a VID format
volt2vid () {
    __vout_mode=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $VOUT_MODE)

    if [ "$__vout_mode" == "0x24" ]; then
        # VR13 mode, 10mV DAC - 0x24
        # vid = ((Voltage - 0.50) / 0.01) + 1
        __vid=$(echo $1 0.50 | awk '{print $1-$2}')
        __vid=$(echo $__vid 0.01 | awk '{print $1/$2}')
    else
        # VR13 mode, 5mV DAC - 0x21
        # vid = ((Voltage - 0.25) / 0.005) + 1
        __vid=$(echo $1 0.25 | awk '{print $1-$2}')
        __vid=$(echo $__vid 0.005 | awk '{print $1/$2}')
    fi

    __vid=$(echo $__vid 1 | awk '{print $1+$2}')

    printf "0x%x\n" $__vid
}

# Function that maps VID code to a voltage in volts
# Input argument:
# $1 is the VID code that we want to convert to a voltage value
vid2volt() {
    __vout_mode=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $VOUT_MODE)

    # Voltage = ((vid - 1) * 0.01) + 0.50
    __vout=$(echo $1 1 | awk '{print $1-$2}')

    if [ "$__vout_mode" == "0x24" ]; then
        __vout=$(echo $__vout 0.01 | awk '{print $1*$2}')
        __vout=$(echo $__vout 0.50 | awk '{print $1+$2}')
    else
        __vout=$(echo $__vout 0.005 | awk '{print $1*$2}')
        __vout=$(echo $__vout 0.25 | awk '{print $1+$2}')
    fi

    echo $__vout V
}

# Function that checks whether an I2C device is present or not.
# If the device is not found, an informative message is printed
# and the script is exited immediately with error=1
# Input arguments:
# $1 is the I2C bus of the device
# $2 is the device's I2C address
# $3 is a PMBus command
is_device_present () {
    i2cget -y -f $1 $2 $3 &> $trash

    if [ $? -ne 0 ]; then
        echo "Unable to read bus $1, device $2, register $3"
        echo "Exiting the script without completion"
        exit 1
    fi
}

#
# Script starts here
#

if [ "$channel_or_powercycle" == "a" ] ||
    [ "$channel_or_powercycle" == "b" ]; then

    # Before executing any i2cget or i2cset, check whether the devices that we
    # are reading are present
    is_device_present $PWR_SEQUENCER_BUS $BF_PWR_SEQUENCER_ADDR $OUTPUT_STATUS0
    is_device_present $VRD_BUS $TPS53679_ADDR $READ_VOUT

    # $1 is the channel option: a, b
    # $2 is the fault handling option: ignore, act
    # $3 is the margin type: none, low, high, all
    # $4, $5, $6 are the values of the margin voltages in Volts:
    #   - if $3="none", $4 is the output target voltage
    #   - if $3="low", $4 is the low margin output voltage
    #   - if $3="high", $4 is the high margin output voltage
    #   - if $3="all":
    #       - if $4="default", we use default margining
    #         values hardcoded in this script (+/-5%)
    #       - if user wants to set his own values, then
    #         $4 is the nominal Vout, $5 is low margin Vout,
    #         $6 is high margin Vout
    #
    # command example: mlnx_tps53679_voltage_margin a ignore low 0.6
    #                  mlnx_tps53679_voltage_margin b ignore all default
    #                  mlnx_tps53679_voltage_margin b act all 2.5 0.6 3.3

    channel=$1
    fault=$2
    margin=$3

    if [ "$fault" != "ignore" ] && [ "$fault" != "act" ]; then
        print_usage_msg
    fi

    case $margin in
        "none")
            ;&
        "low")
            ;&
        "high")
            if [ $# -ne 4 ]; then
                print_usage_msg
            fi
            ;;
        "all")
            if [ $# -ne 6 ]; then
                if [ "$4" != "default" ]; then
                    print_usage_msg
                elif [ "$4" == "default" ] && [ $# -gt 4 ]; then
                    print_usage_msg
                fi
            fi
            ;;
        *)
            print_usage_msg
            ;;
    esac #margin

    echo -e '\n'starting script @ `date`

    case $channel in
        "a")
            # select channel A
            echo Selected channel A associated with VCORE
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $PAGE 0x0;;
        "b")
            # select channel B
            echo Selected channel B associated with 1.2V DDR4
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $PAGE 0x1;;
        *)
            echo Invalid channel;;
    esac #channel

    # ON_OFF_CONFIG cmd (offset: 0x2) needs to be set
    # to 0x1b for both channel A and B to allow the OPERATION
    # cmd to control the state of the device. We could make it
    # 0x1f.
    # This register is set per channel.
    #
    # Bit    Description
    # [7:5]  Reserved
    # 4      Sets the default to either operate any time power is present or
    #        for the on/off to be controlled by CONTROL pin and serial bus cmd
    #        0: Unit powers up any time power is present regardless of state
    #           of CONTROL pin
    #        1: Unit does not power up until commanded by the CONTROL pin and
    #           OPERATION cmd (as programmed in bits [3:0])
    # 3      Controls how the unit responds to cmds received via the serial bus
    #        0: Unit ignores the on/off portion of the OPERATION cmd from serial bus
    #        1: To start, the unit requires that the ON bit of OPERATION cmd
    #           is instructing the unit to run. Depending on bit 2, the unit may
    #           also require CONTROL pin to be asserted for the unit to start
    #           and energize the output
    # 2      Controls how the unit responds to CONTROL pin
    #        0: Unit ignores CONTROL pin(on/off controlled only by OPERATION)
    #        1: Unit requires CONTROL pin to be asserted to start the unit.
    #           Depending on bit 3, OPERATION may also be required to instruct the
    #           device to start before the output is energized.
    # 1      Polarity of CONTROL pin
    #        0: Active low (pull pin low to start the unit)
    #        1: Active high (pull pin high to start the unit)
    #        AVR_EN and BEN are active high
    # 0      CONTROL pin action when commanding the unit to turn off
    #        CONTROL pin is AVR_EN/BEN pins depending on the selected channel
    #        0: Use the programmed turn off delay and fall time
    #        1: turn off the output and stop transferring energy to the out.
    i2cset -y -f $VRD_BUS $TPS53679_ADDR $ON_OFF_CONFIG 0x1b

    # MFR_SPECIFIC_02 cmd (offset: 0xd2)
    # PMBus interface has control of the output voltage
    i2cset -y -f $VRD_BUS $TPS53679_ADDR $MFR_SPECIFIC_02 0x1

    # OPERATION cmd (offset: 0x1)
    #
    # Bit   Description
    # 7     ON
    #       (1b)Enable/(0b)Disable power conversion
    #       for the currently selected channel(s),
    #       when the ON_OFF_CONFIG cmd is configured
    #       to require input from the ON bit for
    #       the output control.
    #       0: Unit immediate off
    #       1: Unit On
    #
    # 5:2   MARGIN
    #       0000b -> margin none. Vout=VOUT_COMMAND
    #       01xxb -> Margin Low. Vout=VOUT_MARGIN_LOW
    #       10xxb -> Margin High. Vout=VOUT_MARGIN_HIGH
    #
    #       Lower 2 MARGIN bits in OPERATION select overvolt and
    #       undervolt fault handling during margin test:
    #       xx01b -> Ignore faults
    #       xx10b -> Act on Faults
    #
    # 1:0   Always set to 0
    #
    # Set the "ON" bit in OPERATION to 1 to ensure the device is
    # configured to respect the ON_OFF_CONFIG command.
    # This command is set per channel.

    case $margin in
        "none")
            echo "**********************************"
            echo "Test running: Voltage margin none"
            echo "Target Vout: $4 V"

            # Map desired voltage to VID hex value
            desired_vout=$(volt2vid $4)
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $VOUT_COMMAND $desired_vout w
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0x80 b
            read_vout=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $READ_VOUT)
            echo -e '\n'"Vout is currently set to $(vid2volt $read_vout)"
            echo "**********************************"
            ;;

        "low")
            echo "**********************************"
            echo "Test running: Voltage margin low"
            echo "Target Vout: $4 V"

            # Map desired voltage to vid hex value
            desired_vout=$(volt2vid $4)
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $VOUT_MARGIN_LOW $desired_vout w

            if [ "$fault" == "ignore" ]; then
                echo ignore faults
                i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0x94 b
            else
                echo act on faults
                i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0x98 b
            fi

            read_vout=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $READ_VOUT)
            echo -e '\n'"Vout is currently set to $(vid2volt $read_vout)"
            echo "**********************************"
            ;;

        "high")
            echo "**********************************"
            echo "Test running: Voltage margin high"
            echo "Target Vout: $4 V"

            # Map desired voltage to vid hex value
            desired_vout=$(volt2vid $4)
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $VOUT_MARGIN_HIGH $desired_vout w

            if [ "$fault" == "ignore" ]; then
                echo ignore faults
                i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0xa4 b
            else
                echo act on faults
                i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0xa8 b
            fi

            read_vout=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $READ_VOUT)
            echo -e '\n'"Vout is currently set to $(vid2volt $read_vout)"
            echo "**********************************"
            ;;

        "all")
            # For Channel A, VCORE depends on efuse setting. So it could be
            # 0.9 V, 0.95 V or 1 V. By default, we are setting it to 0.9 V.
            # User may change it using the command line.
            # By default:
            # Low margin voltage = (nominal - 5%)
            # High margin voltage = (nominal + 5%)

            if [ "$4" == "default" ]; then
                if [ "$channel" == "a" ]; then
                    nominal=$(volt2vid 0.9)
                    margin_low=$(volt2vid 0.855)
                    margin_high=$(volt2vid 0.945)
                else
                    #channel b
                    nominal=$(volt2vid 1.2)
                    margin_low=$(volt2vid 1.14)
                    margin_high=$(volt2vid 1.26)
                fi
            else
                nominal=$(volt2vid $4)
                margin_low=$(volt2vid $5)
                margin_high=$(volt2vid $6)
            fi

            # set the parameters for 3 test conditions:

            echo "**********************************"
            echo "Test running: Voltage margin none"
            echo "Target Vout: $(vid2volt $nominal)"
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $VOUT_COMMAND $nominal w
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0x80 b
            read_vout=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $READ_VOUT)
            echo -e '\n'"Vout is currently set to $(vid2volt $read_vout)"'\n'
            echo "**********************************"

            i2cset -y -f $VRD_BUS $TPS53679_ADDR $VOUT_MARGIN_LOW $margin_low w
            i2cset -y -f $VRD_BUS $TPS53679_ADDR $VOUT_MARGIN_HIGH $margin_high w

            if [ "$fault" == "ignore" ]; then
                echo "Test running: Voltage margin low, ignore faults"
                echo "Target Vout: $(vid2volt $margin_low)"
                i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0x94 b
                # Give it time to adjust from voltage margin none test
                sleep 1
                read_vout=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $READ_VOUT)
                echo -e '\n'"Vout is currently set to $(vid2volt $read_vout)"'\n'
                echo "************************************************"
                echo "Test running: Voltage margin high, ignore faults"
                echo "Target Vout: $(vid2volt $margin_high)"
                i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0xa4 b
                # Give it time to adjust from voltage margin low
                sleep 1
                read_vout=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $READ_VOUT)
                echo -e '\n'"Vout is currently set to $(vid2volt $read_vout)"'\n'
                echo "************************************************"
            else
                echo "Test running: Voltage margin low, act on faults"
                echo "Target Vout: $(vid2volt $margin_low)"
                i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0x98 b
                sleep 1
                read_vout=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $READ_VOUT)
                echo -e '\n'"Vout is currently set to $(vid2volt $read_vout)"'\n'
                echo "************************************************"
                echo "Test running: Voltage margin high, act on faults"
                echo "Target Vout: $(vid2volt $margin_high)"
                i2cset -y -f $VRD_BUS $TPS53679_ADDR $OPERATION 0xa8 b
                sleep 1
                read_vout=$(i2cget -y -f $VRD_BUS $TPS53679_ADDR $READ_VOUT)
                echo -e '\n'"Vout is currently set to $(vid2volt $read_vout)"'\n'
                echo "************************************************"
            fi
            ;;
        *)
            # we should never get here
            ;;
    esac #margin

    output_status0=$(i2cget -y -f $PWR_SEQUENCER_BUS $BF_PWR_SEQUENCER_ADDR $OUTPUT_STATUS0)
    if [ "$output_status0" != "0x8f" ]; then
        echo "An overvoltage or undervoltage response occured,"
        echo "which turned off the power of some device(s)."
        echo "Run '$progname powercycle' to turn the power"
        echo "back on"
    fi

    # reset ON_OFF_CONFIG to the default value
    i2cset -y -f $VRD_BUS $TPS53679_ADDR $ON_OFF_CONFIG 0x17

    echo -e '\n'end of script @ `date`

elif [ "$channel_or_powercycle" == "powercycle" ] && [ $# -eq 1 ]; then

    # If the voltage exceeded the overvoltage limit or undervoltage limit,
    # then the VOUT_OV_FAULT_RESPONSE or the VOUT_UV_FAULT_RESPONSE
    # registers (if they are set to 0x80) will
    # cause the device to latch off and not restart. To clear the shutdown
    # event due to fault event, we need to toggle the AVR_EN/BEN pin.
    # In order to do that, we need to power cycle from the BMC.
    # On the BF power sequencer ispPAC-POWR1014A, OUTPUT_STATUS0
    # gives the status of the digital output:
    # OUT5 -> VCORE_VRD_EN -> AVR_EN pin of TPS53679
    # OUT6 -> 1.2 DDR_VRD_EN -> BEN pin of TPS53679
    # CONTROL pins are active low
    is_device_present $PWR_SEQUENCER_BUS $BF_PWR_SEQUENCER_ADDR $OUTPUT_STATUS0
    output_status0=$(i2cget -y -f $PWR_SEQUENCER_BUS $BF_PWR_SEQUENCER_ADDR $OUTPUT_STATUS0)
    if [ "$output_status0" != "0x8f" ]; then
        /usr/sbin/mlnx_powercycle_bf
    else
        echo No need to power cycle, all device are on
    fi

else
    print_usage_msg
fi

rm $trash
