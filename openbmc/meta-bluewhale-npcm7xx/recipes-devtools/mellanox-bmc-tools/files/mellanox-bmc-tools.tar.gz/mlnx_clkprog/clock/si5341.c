#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <libgen.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "i2c.h"
#include "si5341.h"

// According to Si5341 Reference Manual the I2C address range: 116d to 119d,
// 0x74 to 0x77 (selected via A0/A1 pins). On the other hand, hardware guys
// are using the range: 112d to 115d / 0x70 to 0x73. For now, we are going to
// allow device addresses in both ranges: 112d to 119d / 0x70 to 0x77. This
// will be updated as soon as we get further information.
#define BMC_SI5341_ADDR_MIN         0x70
#define BMC_SI5341_ADDR_MAX         0x77

// The Si5341 clock generator is attached to I2C bus 9
#define BMC_DEFAULT_SI5341_BUS      9

// Get rid of path in filename - only for unix-type paths using '/'
#define NO_PATH(file_name) (strrchr((file_name), '/') ? \
                strrchr((file_name), '/') + 1 : (file_name))

#define SI5341_SET_PAGE 1

// NVM Programming registers
#define SI5341_ACTIVE_NVM_BANK_REG  0x00E2 // Identifies the active NVM bank.
#define SI5341_NVM_WRITE_REG        0x00E3 // Initiates an NVM write when written with 0xC7.
#define SI5341_NVM_READ_BANK_REG    0x00E4 // Download register values with content stored in NVM.
#define SI5341_DEVICE_READY_REG     0x00FE // Indicates that the device serial interface is ready
                                           // to accept commands.

#define SI5341_NVM_WRITE_BYTE       0xC7
#define SI5341_DEVICE_READY_BYTE    0x0F

typedef enum
{
    SI5341_DEV_READY = 0x10,
} si5341_dev_status_t;

typedef struct
{
    int     file;
    uint8_t bus;
    uint8_t addr;
    uint8_t currpage;
    uint8_t status;
} si5341_dev_t;

#define SI5341_F_WRITE_NVM      0x10
#define SI5341_F_WRITE_VERIFY   0x08
#define SI5341_F_FORCE_ACCESS   0x04
#define SI5341_F_DEV_CONFIG     0x02
#define SI5341_F_VALID_DEVICE   0x01

typedef enum
{
    SI5341_NO_ERROR,
    SI5341_SET_PAGE_FAILURE  = 0x080,
    SI5341_READ_FAILURE      = 0x040,
    SI5341_WRITE_FAILURE     = 0x020,
    SI5341_CHECK_FAILURE     = 0x010,
    SI5341_CONFIG_FAILURE    = 0x008,
    SI5341_W_SETTING_FAILURE = 0x004,
    SI5341_R_SETTING_FAILURE = 0x002,
    SI5341_BAD_SETTING_REG   = 0x001,
    SI5341_BAD_DEV_STATUS    = 0x100,
    SI5341_INVALID_DEV       = 0x200,
    SI5341_NVM_WRITE_FAILURE = 0x400,
} si5341_error_t;

// Timeout in seconds
#define DEVICE_READY_TIMEOUT    100
#define POLL_FREQ_IN_SEC        1

// Helper functions
static void help(char *progname);
static void parse_params(char *arg, int *first, int *second,
                            const char delim, int base);

#define SI5341_ERR(x) ((x) != SI5341_NO_ERROR)

static int si5341_set_page(si5341_dev_t *dev, uint8_t page)
{
    int newpage;

    if (page != dev->currpage)
    {
        i2c_smbus_write_byte_data(dev->file, SI5341_SET_PAGE, page);
        newpage = i2c_smbus_read_byte_data(dev->file, SI5341_SET_PAGE);
        if (newpage != page)
            return SI5341_SET_PAGE_FAILURE;
        else
            dev->currpage = page;
    }

    return SI5341_NO_ERROR;
}

static int si5341_write(si5341_dev_t *dev,
                        uint8_t  data,
                        uint16_t addr,
                        bool     verify)
{
    uint8_t page = addr >> 8;
    int ret, rc = SI5341_NO_ERROR;

    if (!dev)
        return SI5341_INVALID_DEV;

    if (dev->status != SI5341_DEV_READY)
        return SI5341_BAD_DEV_STATUS;

    ret = si5341_set_page(dev, page);
    if (SI5341_ERR(ret))
        return ret;

    ret = i2c_smbus_write_byte_data(dev->file, addr & 0xff, data);
    if ((ret >= 0) && verify)
    {
        ret  = i2c_smbus_read_byte_data(dev->file, addr & 0xff);
        if (ret != data)
            rc |= SI5341_CHECK_FAILURE;
    }

    if (ret < 0)
        rc |= SI5341_WRITE_FAILURE;

    return rc;
}

static int si5341_read(si5341_dev_t *dev, uint8_t *data, uint16_t addr)
{
    uint8_t page = addr >> 8;
    int     ret;

    *data = 0;

    if (!dev)
        return SI5341_INVALID_DEV;

    if (dev->status != SI5341_DEV_READY)
        return SI5341_BAD_DEV_STATUS;

    ret = si5341_set_page(dev, page);
    if (SI5341_ERR(ret))
        return ret;

    ret = i2c_smbus_read_byte_data(dev->file, addr & 0xff);
    if (ret < 0)
        return SI5341_READ_FAILURE;

    *data = ret;

    return SI5341_NO_ERROR;
}

static bool si5341_device_ready(si5341_dev_t *dev)
{
    uint32_t timeout;
    uint8_t  data;
    int      ret;

    if (!dev)
        return SI5341_INVALID_DEV;

    timeout = DEVICE_READY_TIMEOUT / POLL_FREQ_IN_SEC;

    do
    {
        // Read DEVICE_READY register
        ret = si5341_read(dev, &data, SI5341_DEVICE_READY_REG);
        if (SI5341_ERR(ret))
        {
            fprintf(stderr,
                    "Failed to read DEVICE_READY byte: %d\n", ret);
            return false;
        }
        // Check whether the device is ready
        if (data == SI5341_DEVICE_READY_BYTE)
        {
            fprintf(stderr,
                    "Serial interface is now ready to accept commands.\n");
            return true;
        }
        sleep(POLL_FREQ_IN_SEC);
    } while (timeout-- != 0);

    return false;
}

static int si5341_save_config(si5341_dev_t *dev)
{
    int ret;

    if (!dev)
        return SI5341_INVALID_DEV;

    fprintf(stderr,
                "**WARNING: writing register configuration to NVM\n");

    // Initiate the NVM write
    fprintf(stdout, "Initiate the NVM write; set NVM_WRITE_REG to 0xc7\n");
    ret = si5341_write(dev, SI5341_NVM_WRITE_BYTE,
                        SI5341_NVM_WRITE_REG, false);
    if (SI5341_ERR(ret))
    {
        fprintf(stderr,
                "Failed to initiate the NVM write: %d\n", ret);
        return SI5341_NVM_WRITE_FAILURE;
    }

    // Wait until device is ready
    fprintf(stdout, "Wait until device is ready\n");
    if (!si5341_device_ready(dev))
    {
        fprintf(stderr, "Error while writing to NVM\n");
        return SI5341_NVM_WRITE_FAILURE;
    }

    // Download register values with content stored in NVM. This is done by
    // setting bit 0 to 1. Note that this might be replaced by simply powering
    // down and then powering up the device. Thus this might be omitted.
    fprintf(stdout, "Download registers value from NVM\n");
    ret = si5341_write(dev, 1, SI5341_NVM_READ_BANK_REG, false);
    if (SI5341_ERR(ret))
    {
        fprintf(stderr,
                "Failed to set bit 0 in NVM_READ_BANK register: %d\n",
                    ret);
        return SI5341_NVM_WRITE_FAILURE;
    }

    // Wait until device is ready
    fprintf(stdout, "Wait until device is ready\n");
    if (!si5341_device_ready(dev))
    {
        fprintf(stderr, "Error while downloading register values\n");
        return SI5341_NVM_WRITE_FAILURE;
    }

    return SI5341_NO_ERROR;
}

static int si5341_set_config(si5341_dev_t *dev,
                             const char   *filename,
                             uint8_t       flags)
{
    ssize_t read;
    size_t  len  = 0;
    char   *line = NULL;
    FILE   *fp;
    int     reg = 0, data = 0;
    int     ret, errors, cnt;

    errors = cnt = 0;

    if (!dev)
        return SI5341_INVALID_DEV;

    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        fprintf(stderr,
                "Cannot open config file %s!\n", filename);
        exit(EXIT_FAILURE);
    }

    while ((read = getline(&line, &len, fp)) != -1) {
        if (!strstr(line, "#") &&
                !(strstr(line, "Address,Data")))
        {
            parse_params(line, &reg, &data, ',', 16);
            ret = si5341_write(dev, data, reg,
                                flags & SI5341_F_WRITE_VERIFY);
            errors += (SI5341_ERR(ret)) ? 1 : 0;
            cnt++;
        }
    }

    fprintf(stderr,
        "Configuration completed with %d errors while writing %d bytes\n",
                errors, cnt);

    fclose(fp);
    if (line)
        free(line);

    return (errors) ? SI5341_CONFIG_FAILURE : SI5341_NO_ERROR;
}

static int si5341_check_config(si5341_dev_t *dev,
                               const char   *filename)
{
    ssize_t read;
    size_t  len  = 0;
    char   *line = NULL;
    FILE   *fp;
    int     reg = 0, exp_data = 0, cur_data = 0;
    int     ret, errors, cnt;

    errors = cnt = 0;

    if (!dev)
        return SI5341_INVALID_DEV;

    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        fprintf(stderr,
                "Cannot open config file %s!\n", filename);
        exit(EXIT_FAILURE);
    }

    while ((read = getline(&line, &len, fp)) != -1) {
        if (!strstr(line, "#") &&
                !(strstr(line, "Address,Data")))
        {
            parse_params(line, &reg, &exp_data, ',', 16);
            ret = si5341_read(dev, (uint8_t *) &cur_data, reg);
            if (SI5341_ERR(ret))
            {
                fprintf(stderr,
                    "Error while reading register 0x%04x error:%d\n",
                        reg, ret);
            }

            if (exp_data != cur_data)
            {
                errors += 1;
                fprintf(stderr,
                    "WARNING: Register 0x%04x has value 0x%x, should be 0x%x\n",
                        reg, cur_data, exp_data);
            }
            cnt++;
        }
    }

    fprintf(stderr,
        "%d errors detected while checking %d registers\n",
                errors, cnt);

    fclose(fp);
    if (line)
        free(line);

    return (errors) ? SI5341_CONFIG_FAILURE : SI5341_NO_ERROR;
}

static int si5341_export_config(si5341_dev_t *dev, const char* filename)
{
    si5341_revd_regmap_t *regmap;
    uint64_t data64;
    uint16_t reg;
    uint8_t  data, mask;
    int setting, reg_idx;
    int ret = 0, errors = 0;
    FILE *fp;

    if (!dev)
        return SI5341_INVALID_DEV;

    fp = fopen(filename, "w");
    if (fp == NULL)
    {
        fprintf(stderr,
                "Cannot create config file %s!\n", filename);
        exit(EXIT_FAILURE);
    }

    // Write file header
    fprintf(fp, "# Si5341 Settings Export\n"
                "Location,SettingName,DecimalValue,HexValue\n");

    for (setting = 0; setting < SI5341_REVD_NUM_SETTINGS; setting++)
    {
        regmap = &si5341_revd_settings[setting];
        if (regmap->nvm_type != SLAB_NVMT_NONE)
        {
            fprintf(fp, "0x%04X[", regmap->addr[0]);
            if (regmap->bit_length > 1)
                fprintf(fp, "%d:",
                        regmap->start_bit + regmap->bit_length - 1);
            fprintf(fp, "%d],%s,", regmap->start_bit, regmap->name);

            data64 = 0;
            for (reg_idx = 0; reg_idx < regmap->reg_length; reg_idx++)
            {
                reg  = regmap->addr[reg_idx];
                mask = regmap->mask[reg_idx];

                ret = si5341_read(dev, &data, reg);
                if (SI5341_ERR(ret))
                {
                    errors++;
                    data64 = 0;
                    break;
                }

                data64 |= ((uint64_t)(data & mask) << (reg_idx << 3));
            }
            data64 >>= regmap->start_bit;

            fprintf(fp, "%llu,0x%llX %s\n", data64, data64,
                    SI5341_ERR(ret) ? "-> invalid" : "");
        }
    }

    fprintf(stderr,
        "Configuration exported with %d errors while reading %d settings\n",
                errors, SI5341_REVD_NUM_SETTINGS);

    fclose(fp);

    return (errors) ? SI5341_CONFIG_FAILURE : SI5341_NO_ERROR;
}

static bool si5341_has_setting(const char *name, int *setting)
{
    si5341_revd_regmap_t *regmap;
    int idx;
    int ret;

    for (idx = 0; idx < SI5341_REVD_NUM_SETTINGS; idx++)
    {
        regmap = &si5341_revd_settings[idx];
        ret = strcmp(regmap->name, name);
        if (ret == 0)
        {
            if (setting != NULL)
                *setting = idx;
            return true;
        }
    }

    return false;
}

static int si5341_setting(si5341_dev_t *dev,
                          uint16_t setting,
                          uint8_t  data,
                          uint8_t  index,
                          uint8_t  flags)
{
    si5341_revd_regmap_t *regmap;
    uint16_t reg;
    uint8_t  val = 0, mask;
    int ret;

    if (!dev)
        return SI5341_INVALID_DEV;

    regmap = &si5341_revd_settings[setting];

    if (index >= regmap->reg_length)
        return SI5341_BAD_SETTING_REG;

    reg  = regmap->addr[index];
    mask = regmap->mask[index];

    // Read the current value
    ret = si5341_read(dev, &val, reg);
    if (SI5341_ERR(ret))
        return ret;

    val &= ~mask; // Reset bits
    val |= (data << regmap->start_bit);

    ret = si5341_write(dev, val, reg,
                              flags & SI5341_F_WRITE_VERIFY);
    if (SI5341_ERR(ret))
        return ret;

    return SI5341_NO_ERROR;
}

static int si5341_show_setting(si5341_dev_t *dev, uint16_t setting)
{
    si5341_revd_regmap_t *regmap;
    uint64_t data64 = 0;
    uint16_t reg, reg_idx;
    uint8_t  mask, val;
    int ret;

    if (!dev)
        return SI5341_INVALID_DEV;

    regmap = &si5341_revd_settings[setting];

    for (reg_idx = 0; reg_idx < regmap->reg_length; reg_idx++)
    {
        reg  = regmap->addr[reg_idx];
        mask = regmap->mask[reg_idx];
        ret = si5341_read(dev, &val, reg);
        if (SI5341_ERR(ret))
            return ret;

        data64 |= ((val & mask) << (reg_idx << 3));
    }

    data64 >>= regmap->start_bit;

    fprintf(stderr,
            "Setting name %s has value 0x%llx\n", regmap->name, data64);

    return SI5341_NO_ERROR;
}

int main(int argc, char *argv[])
{
    si5341_dev_t dev;
    int    opt, long_index;
    int    bus, addr, reg, val, stg = -1;
    char  *token, *name = NULL;
    size_t len   = 0;
    int    flags = 0;
    char  *fout  = NULL;
    char  *fin   = NULL;
    int    i, ret;

    static struct option longopts[] =
    {
        {"device",    required_argument, NULL, 'd'},
        {"force",     no_argument,       NULL, 'f'},
        {"setconf",   required_argument, NULL, 'c'},
        {"checkconf", required_argument, NULL, 'k'},
        {"saveconf",  no_argument,       NULL, 'a'},
        {"verify",    no_argument,       NULL, 'v'},
        {"setreg",    required_argument, NULL, 'r'},
        {"getreg",    required_argument, NULL, 'g'},
        {"stg",       required_argument, NULL, 't'},
        {"show",      required_argument, NULL, 's'},
        {"export",    required_argument, NULL, 'e'},
        {"help",      no_argument,       NULL, 'h'},
        {NULL, 0, NULL, 0}
    };

    while (1)
    {
        opt = getopt_long(argc, argv, "d:fveh",
                            longopts, &long_index);

        if (opt == -1)
            break; // No more options

        switch (opt) {
        case 'h':
            help(argv[0]);
            exit(EXIT_SUCCESS);
            break;

        case 'd':
            parse_params(optarg, &bus, &addr, ':', 0);
            if ((bus > BMC_I2C_BUS_CNT) || (addr < BMC_SI5341_ADDR_MIN) ||
                        (addr > BMC_SI5341_ADDR_MAX))
            {
                fprintf(stderr,
                    "Invalid Device parameters: bus %d, addr 0x%x\n",
                            bus, addr);
                exit(EXIT_FAILURE);
            }
            // Set device information
            memset(&dev, 0, sizeof(si5341_dev_t));
            dev.addr = addr;
            dev.bus  = bus;
            flags   |= SI5341_F_VALID_DEVICE;
            break;

        case 'f':
            flags   |= SI5341_F_FORCE_ACCESS;
            break;

        case 'v':
            flags   |= SI5341_F_WRITE_VERIFY;
            break;

        case 'a':
            flags   |= SI5341_F_WRITE_NVM;
            break;

        case 'e':
            len = strlen(optarg);
            if (len == 0)
            {
                fprintf(stderr,
                        "No output file for '-e, --export' option!\n");
                exit(EXIT_FAILURE);
            }
            len += 1; // add room for '\0'
            fout = malloc(len);
            if (fout == NULL)
            {
                fprintf(stderr, "Unexpected error! Try again.\n");
                exit(EXIT_FAILURE);
            }
            strcpy(fout, optarg);
            break;

        case 'k':
            len = strlen(optarg);
            if (len == 0)
            {
                fprintf(stderr,
                        "No output file for '-k, --checkconf' option!\n");
                exit(EXIT_FAILURE);
            }
            len += 1; // add room for '\0'
            fin = malloc(len);
            if (fin == NULL)
            {
                fprintf(stderr, "Unexpected error! Try again.\n");
                exit(EXIT_FAILURE);
            }
            strcpy(fin, optarg);
            break;

        default:
            break;
        }
    }

    // Check whther the device options are specified. Otherwise exit
    // the program.
    if (!(flags & SI5341_F_VALID_DEVICE))
    {
        fprintf(stderr,
                "Missing parameters! Run with '-h, --help' option.\n");
        exit(EXIT_FAILURE);
    }

    // Open the I2C adapter and set the slave address.
    dev.file = i2c_smbus_init(dev.bus, dev.addr,
                                flags & SI5341_F_FORCE_ACCESS);
    if (dev.file < 0)
        exit(EXIT_FAILURE);

    // Updtate device status
    dev.status = SI5341_DEV_READY;

    // Set the device page register to 0x0 (default).
    dev.currpage = 0xf;
    ret = si5341_set_page(&dev, 0x0);
    if (SI5341_ERR(ret))
    {
        fprintf(stderr,
                "Failed to set PAGE to default value: %d\n", ret);
        exit(EXIT_FAILURE);
    }

    // Read configuration options
    optind = 0;
    while (1)
    {
        opt = getopt_long(argc, argv, "c:r:s:g:t:",
                            longopts, &long_index);

        if (opt == -1)
            break; // No more options

        switch (opt) {
        case 'c':
            len = strlen(optarg);
            if (len == 0)
            {
                fprintf(stderr,
                        "No input file for '-c, --setconfig' option!\n");
                goto exit_err;
            }
            // Configure the device from the input file.
            ret = si5341_set_config(&dev, optarg, flags);
            if (SI5341_ERR(ret))
            {
                fprintf(stderr,
                        "Device configuration failed: %d\n", ret);
                goto exit_err;
            }
            break;

        case 'r':
            // Read the register address and value.
            parse_params(optarg, &reg, &val, ',', 0);
            if (reg < 0 || reg > 65535 ||
                    val > 255 || val < 0) // 0 to 2^16 - 1
            {
                fprintf(stderr,
                    "Register address 0x%04x or data 0x%x invalid\n",
                        reg, val);
                goto exit_err;
            }
            // Write the given register
            ret = si5341_write(&dev, val, reg,
                                flags & SI5341_F_WRITE_VERIFY);
            if (SI5341_ERR(ret))
            {
                fprintf(stderr,
                        "Register configuration failed: %d\n", ret);
                goto exit_err;
            }
            break;

        case 'g':
            // Read the register address
            reg = strtoul(optarg, 0, 0);
            if (reg < 0 || reg > 65535)
            {
                fprintf(stderr,
                    "Invalid register address 0x%04x\n", reg);
                goto exit_err;
            }
            // Retrieve the register value and print it out.
            ret = si5341_read(&dev, (uint8_t *) &val, reg);
            if (SI5341_ERR(ret))
            {
                fprintf(stderr,
                        "Failed to get register value: %d\n", ret);
                goto exit_err;
            }
            fprintf(stderr,
                    "Register 0x%04x: 0x%x\n", reg, (uint8_t) val);
            break;

        case 't':
            for (token = strtok(optarg, ","), i = 0;
                 token != NULL; token = strtok(NULL, ","), i++)
            {
                // First of all, read the setting name and check whether
                // the settig is valid.
                if (i == 0)
                {
                    name = token;
                    if (!si5341_has_setting(token, &stg))
                    {
                        fprintf(stderr,
                            "Invalid setting %s\n", name);
                        goto exit_err;
                    }
                }
                else
                {
                    // Then, configure the setting with its associated
                    // byte values.
                    val = strtoul(token, 0, 0);
                    ret = si5341_setting(&dev, stg, val, i - 1, flags);
                    if (SI5341_ERR(ret))
                    {
                        fprintf(stderr,
                                "Failed to configure setting %s: %d\n",
                                    name, ret);
                        goto exit_err;
                    }
                }
            }
            break;

        case 's':
            // Check whether the setting is valid and exists.
            if (!si5341_has_setting(optarg, &stg))
            {
                fprintf(stderr,
                    "Invalid setting %s\n", optarg);
                goto exit_err;
            }
            // Print out the setting value.
            ret = si5341_show_setting(&dev, stg);
            if (SI5341_ERR(ret))
            {
                fprintf(stderr,
                        "Failed to print setting %s: %d\n",
                            optarg, ret);
                goto exit_err;
            }
            break;

        case '?':
        default:
            break;
        }
    }

    if (fout)
        ret = si5341_export_config(&dev, fout); // Export device config to
                                                // an output file.

    if (fin)
        ret = si5341_check_config(&dev, fin); // Check device config and
                                              // compare it to the input file.

    if (flags & SI5341_F_WRITE_NVM)
        ret = si5341_save_config(&dev);

    if (dev.status == SI5341_DEV_READY)
        close(dev.file); // Close the device file.

    exit(EXIT_SUCCESS);

exit_err:
    if (dev.status == SI5341_DEV_READY)
        close(dev.file);
    exit(EXIT_FAILURE);
}

static void parse_params(char *arg, int *first, int *second,
                        const char delim, int base)
{
    char *end;

    *first = strtoul(arg, &end, base);
    if(*end == delim)
        *second = strtoul(++end, 0, base);
}

static void help(char *progname)
{
    fprintf(stderr,
        "Usage: ./%s OPTIONS\n"
        "   E.g. ./%s --device 9:0x74 -f --setconf config.txt --verify\n"
        "\n"
        "  Device OPTIONS:\n"
        "   -d, --device <bus:addr>  Open device address 'addr' in i2c bus\n"
        "                            'bus'.\n"
        "   -f, --force              Force configuration even when a driver\n"
        "                            is also running.\n"
        "  Configuration OPTIONS:\n"
        "   -c, --setconf <file>     Program from Si5341 configuration 'file'.\n"
        "                            The file must be created using v2.12.1 of\n"
        "                            ClockBuilder Pro.\n"
        "   -k, --checkconf <file>   Check the current Si5341 configuration\n"
        "                            against the configuration file 'file'.\n"
        "   -a, --saveconf           Save the current configuration and\n"
        "                            reprogram the NVM. NVM can be written two\n"
        "                            times only."
        "   -v, --verify             Enable write byte verification.\n"
        "   -r, --setreg <addr,val>  Set SI5341 register 'addr' to 'val'.\n"
        "   -g, --getreg <addr>      Get SI5341 register 'addr' value.\n"
        "   -t, --stg <name,val1,val2,...> Configure settings 'name' with\n"
        "                            val1, val2,...; Note that val1 is the\n"
        "                            LSB and valN (N > 1) is the MSB.\n"
        "   -s, --show <name>        Print settings 'name'.\n"
        "   -e, --export <file>      Export SI5341 configuration to 'file'.\n"
        "  Optional OPTIONS:\n"
        "   -h, --help               Print this help\n"
        "\n", NO_PATH(progname), NO_PATH(progname));
}
