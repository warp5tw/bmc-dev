#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <libgen.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "i2c.h"

#define BMC_SI52142_ADDR                0x6B
#define BMC_SI52142_BUS                 9

#define SI52142_AMP_CNTL_MIN            300     //  300 mV
#define SI52142_AMP_CNTL_MAX            1000    // 1000 mV
#define SI52142_AMP_CNTL_LEVEL          100     //  100 mV

// Convert DIFF Differential Outputs Amplitude from register value to mV
#define SI52142_AMP_CNTL_GET(val) \
    ((val) * SI52142_AMP_CNTL_LEVEL + SI52142_AMP_CNTL_MIN)

// Control Register 0. Byte 0
typedef union {
    struct {
        uint8_t reserved0 : 2; // Reserved
        uint8_t ref_oe    : 1; // Output Enable for REF
        uint8_t reserved1 : 5; // Reserved
    };
    uint8_t reg;
} si52142_ctrl_0_t;

// Control Register 1. Byte 1
typedef union {
    struct {
        uint8_t reserved; // Reserved
    };
    uint8_t reg;
} si52142_ctrl_1_t;

// Control Register 2. Byte 2
typedef union {
    struct {
        uint8_t reserved : 6; // Reserved
        uint8_t diff1_oe : 1; // Output Enable for DIFF1
        uint8_t diff0_oe : 1; // Output Enable for DIFF0
    };
    uint8_t reg;
} si52142_ctrl_2_t;

// Control Register 3. Byte 3
typedef union {
    struct {
        uint8_t vendor_id : 4; // Program Revision Code
        uint8_t rev_code  : 4; // Vendor Identification Code
    };
    uint8_t reg;
} si52142_ctrl_3_t;

// Control Register 4. Byte 4
typedef union {
    struct {
        uint8_t bc; // Byte Count Register
    };
    uint8_t reg;
} si52142_ctrl_4_t;

// Control Register 5. Byte 5
typedef union {
    struct {
        uint8_t reserved      : 4; // Reserved
        uint8_t diff_amp_cntl : 3; // DIFF Differnetial Outputs Amplitude Adjustment
        uint8_t diff_amp_sel  : 1; // Amplitude Control for DIFF Differential Outputs
    };
    uint8_t reg;
} si52142_ctrl_5_t;

#define SI52142_REGS_NUM    6

// SI52142 registers map
typedef struct {
    si52142_ctrl_0_t ctrl0;
    si52142_ctrl_1_t ctrl1;
    si52142_ctrl_2_t ctrl2;
    si52142_ctrl_3_t ctrl3;
    si52142_ctrl_4_t ctrl4;
    si52142_ctrl_5_t ctrl5;
} si52142_regmap_t;

typedef enum
{
    SI52142_DEV_READY = 0x10,
} si52142_dev_status_t;

typedef struct
{
    int              file;
    si52142_regmap_t regmap;
    uint8_t          clk_num;
    uint8_t          bus;
    uint8_t          addr;
    uint8_t          status;
} si52142_dev_t;

#define SI52142_F_DUMP     0x10
#define SI52142_F_FORCE    0x08
#define SI52142_F_CONFIG   0x04
#define SI52142_F_RESET    0x02
#define SI52142_F_DEVICE   0x01

typedef enum
{
    SI52142_NO_ERROR,
    SI52142_READ_FAILURE       = 0x020,
    SI52142_WRITE_FAILURE      = 0x040,
    SI52142_INVALID_DEV        = 0x100,
    SI52142_BAD_DEV_STATUS     = 0x200,
    SI52142_CPLD_SETUP_FAILURE = 0x400,
} si52142_error_t;

// Get rid of path in filename
#define NO_PATH(file_name) (strrchr((file_name), '/') ? \
                strrchr((file_name), '/') + 1 : (file_name))

// Helper functions
static void help(char *progname);
static void parse_arg(char *arg, int *first, int *second);

static int si52142_write(si52142_dev_t *dev, uint8_t *data, uint8_t addr)
{
    int ret;

    if (!dev)
    {
        fprintf(stderr, "Error: invalid device data\n");
        return SI52142_INVALID_DEV;
    }

    if (dev->status != SI52142_DEV_READY)
    {
        fprintf(stderr, "Error: bad device status\n");
        return SI52142_BAD_DEV_STATUS;
    }

    if (addr > SI52142_REGS_NUM)
    {
        fprintf(stderr, "Error: invalid register address: %u\n",
                    addr);
        return SI52142_WRITE_FAILURE;
    }

    // The device supports byte write, byte read, block write, and
    // block read operations. We observed that byte r/w doesn't work
    // properly, thus we use the smbus block cycle to write to the
    // device register.
    ret = i2c_smbus_write_block_data(dev->file, addr, 1, data);
    return (ret < 0) ? SI52142_WRITE_FAILURE : SI52142_NO_ERROR;
}

static int si52142_read(si52142_dev_t *dev, uint8_t *data, uint8_t addr)
{
    int ret;

    if (!dev)
    {
        fprintf(stderr, "Error: invalid device data\n");
        return SI52142_INVALID_DEV;
    }

    if (dev->status != SI52142_DEV_READY)
    {
        fprintf(stderr, "Error: bad device status\n");
        return SI52142_BAD_DEV_STATUS;
    }

    if (addr > SI52142_REGS_NUM)
    {
        fprintf(stderr, "Error: invalid register address: %u\n",
                    addr);
        return SI52142_READ_FAILURE;
    }

    // The device supports byte write, byte read, block write, and
    // block read operations.
    ret = i2c_smbus_write_byte(dev->file, addr);
    if (ret < 0)
        fprintf(stderr, "Warning - write failed\n");
    ret = i2c_smbus_read_byte(dev->file);
    *data = (ret < 0) ? 0 : ret;

    return (ret < 0) ? SI52142_READ_FAILURE : SI52142_NO_ERROR;
}

static void si52142_set_default_config(si52142_dev_t *dev)
{
    si52142_regmap_t regmap;
    uint8_t *reg;
    uint8_t  addr;

    if (!dev)
    {
        fprintf(stderr, "Error: invalid device data\n");
        return;
    }

    // Reset control registers settings as described in Silicon Labs
    // Si52142 datasheet
    regmap.ctrl0.reg = 0x04; // Output enabled for REF
    regmap.ctrl1.reg = 0x00;
    regmap.ctrl2.reg = 0xc0; // Output enabled fro DIFF0 and DIFF1
    regmap.ctrl3.reg = 0x08; // Set Vendor ID to 8
    regmap.ctrl4.reg = 0x06; // Set byte count register to 6
    regmap.ctrl5.reg = 0xd8; // Set the Amplitude Control for DIFF
                             // Differential Outputs to 800 mV

    reg = (uint8_t *) &regmap;

    // Copy default config
    for (addr = 0; addr < SI52142_REGS_NUM; addr++)
        si52142_write(dev, reg + addr, addr);
}

static void si52142_set_config(si52142_dev_t *dev)
{
    uint8_t *reg;
    uint8_t  addr;

    if (!dev)
    {
        fprintf(stderr, "Error: invalid device data\n");
        return;
    }

    reg = (uint8_t *) &dev->regmap;

    // Copy default config
    for (addr = 0; addr < SI52142_REGS_NUM; addr++)
        si52142_write(dev, reg + addr, addr);

}

static void si52142_get_config(si52142_dev_t *dev)
{
    uint8_t *reg;
    uint8_t  addr;

    if (!dev)
    {
        fprintf(stderr, "Error: invalid device data\n");
        return;
    }

    reg = (uint8_t *) &dev->regmap;

    for (addr = 0; addr < SI52142_REGS_NUM; addr++)
        si52142_read(dev, reg + addr, addr);
}

static void si52142_dump_config(si52142_dev_t *dev)
{
    si52142_regmap_t *regmap;

    if (!dev)
    {
        fprintf(stderr, "Error: invalid device data\n");
        return;
    }

    regmap = &dev->regmap;
    // Get the actual configuration
    si52142_get_config(dev);

    fprintf(stderr,
        "Si52142 Clock Generator Configuration\n"
        "  Program Revision Code      : %u\n"
        "  Vendor Identification Code : %u\n"
        "  Output Enable\n"
        "    Output Enable for REF    : %s\n"
        "    Output Enable for DIFF0  : %s\n"
        "    Output Enable for DIFF1  : %s\n"
        "  DIFF Differential Outputs\n"
        "    Amplitude Select         : %s\n"
        "    Amplitude Control        : %u mV\n"
        "  Byte Count Register        : %u\n",
        regmap->ctrl3.rev_code,
        regmap->ctrl3.vendor_id,
        regmap->ctrl0.ref_oe   ? "enabled" : "disabled",
        regmap->ctrl2.diff0_oe ? "enabled" : "disabled",
        regmap->ctrl2.diff1_oe ? "enabled" : "disabled",
        regmap->ctrl5.diff_amp_sel ? "control" : "default",
        SI52142_AMP_CNTL_GET(regmap->ctrl5.diff_amp_cntl),
        regmap->ctrl4.bc);
}

int main(int argc, char *argv[])
{
    int opt;
    si52142_regmap_t *regmap;
    si52142_dev_t dev;
    int bus = 0, addr = 0, val;
    int flags = 0;
    uint8_t amp;

    static struct option longopts[] =
    {
        {"dump",     no_argument,       NULL, 'p'},
        {"device",   required_argument, NULL, 'd'},
        {"force",    no_argument,       NULL, 'f'},
        {"revision", required_argument, NULL, 'r'},
        {"vendor",   required_argument, NULL, 'v'},
        {"ref",      required_argument, NULL, 'x'},
        {"diff0",    required_argument, NULL, 'y'},
        {"diff1",    required_argument, NULL, 'z'},
        {"bc",       required_argument, NULL, 'b'},
        {"select",   required_argument, NULL, 's'},
        {"control",  required_argument, NULL, 'c'},
        {"help",     no_argument,       NULL, 'h'},
        {"reset",    no_argument,       NULL, 'e'},
        {NULL, 0, NULL, 0}
    };

    memset(&dev, 0, sizeof(si52142_dev_t));

    while (1)
    {
        opt = getopt_long(argc, argv, "phed:f",
                            longopts, NULL);

        if (opt == -1)
            break; // No more options

        switch (opt) {
        case 'p':
            flags |= SI52142_F_DUMP;
            break;
        case 'h':
            help(argv[0]);
            exit(EXIT_SUCCESS);
            break;
        case 'e':
            flags |= SI52142_F_RESET;
            break;
        case 'd':
            parse_arg(optarg, &bus, &addr);
            if ((bus > BMC_I2C_BUS_CNT) ||
                    (addr > 255) || (addr < 0))
            {
                fprintf(stderr,
                    "Invalid Device parameters: bus %d, addr 0x%x\n",
                            bus, addr);
                exit(EXIT_FAILURE);
            }
            dev.addr = addr;
            dev.bus  = bus;
            flags   |= SI52142_F_DEVICE;
            break;
        case 'f':
            flags |= SI52142_F_FORCE;
            break;
        default:
            break;
        }
    }

    if (!(flags & SI52142_F_DEVICE))
    {
        help(argv[0]);
        exit(EXIT_FAILURE);
    }

    dev.file = i2c_smbus_init(dev.bus, dev.addr,
                                flags & SI52142_F_FORCE);
    if (dev.file < 0)
        exit(EXIT_FAILURE);

    dev.status = SI52142_DEV_READY;

    regmap = &dev.regmap;

    // Read current configuration
    si52142_get_config(&dev);

    // Read configuration options
    optind = 0;
    while (1)
    {
        opt = getopt_long(argc, argv, "r:v:x:y:z:b:s:c:",
                            longopts, NULL);

        if (opt == -1)
            break; // No more options

        switch (opt) {
        case 'r':
            val = atoi(optarg);
            if (val < 0 || val > 15)
            {
                fprintf(stderr,
                    "Invalid Program Revision Code %d\n",
                            val);
                goto exit_err;
            }
            flags |= SI52142_F_CONFIG;
            regmap->ctrl3.rev_code = val;
            break;
        case 'v':
            val = atoi(optarg);
            if (val < 0 || val > 15)
            {
                fprintf(stderr,
                    "Invalid Vendor Identification Code %d\n",
                            val);
                goto exit_err;
            }
            flags |= SI52142_F_CONFIG;
            regmap->ctrl3.vendor_id = val;
            break;
        case 'x':
            val = atoi(optarg);
            if (val != 0 && val != 1)
            {
                fprintf(stderr, "Invalid REF option\n");
                goto exit_err;
            }
            flags |= SI52142_F_CONFIG;
            regmap->ctrl0.ref_oe = val;
            break;
        case 'y':
            val = atoi(optarg);
            if (val != 0 && val != 1)
            {
                fprintf(stderr, "Invalid DIFF0 option\n");
                goto exit_err;
            }
            flags |= SI52142_F_CONFIG;
            regmap->ctrl2.diff0_oe = val;
            break;
        case 'z':
            val = atoi(optarg);
            if (val != 0 && val != 1)
            {
                fprintf(stderr, "Invalid DIFF1 option\n");
                goto exit_err;
            }
            flags |= SI52142_F_CONFIG;
            regmap->ctrl2.diff1_oe = atoi(optarg);
            break;
        case 'b':
            val = atoi(optarg);
            if (val < 0 || val > 255) // 255 or 6?
            {
                fprintf(stderr,
                        "Invalid Byte Count %d\n", val);
                goto exit_err;
            }
            flags |= SI52142_F_CONFIG;
            regmap->ctrl4.bc = val;
            break;
        case 's':
            val = atoi(optarg);
            if (val != 0 && val != 1)
            {
                fprintf(stderr,
                        "Invalid Amplitude Control option\n");
                goto exit_err;
            }
            flags |= SI52142_F_CONFIG;
            regmap->ctrl5.diff_amp_sel = val;
            break;
        case 'c':
            amp = atoi(optarg);
            if ((SI52142_AMP_CNTL_GET(amp) < SI52142_AMP_CNTL_MIN) ||
                    (SI52142_AMP_CNTL_GET(amp) > SI52142_AMP_CNTL_MAX))
            {
                fprintf(stderr,
                    "Invalid DIFF Outputs Amplitude %d mV\n",
                            SI52142_AMP_CNTL_GET(amp));
                goto exit_err;
            }
            flags |= SI52142_F_CONFIG;
            regmap->ctrl5.diff_amp_cntl = amp;
            break;
        case '?':
        default:
            break;
        }
    }

    if (!(flags & (SI52142_F_RESET  |
                    SI52142_F_CONFIG |
                        SI52142_F_DUMP)))
    {
        fprintf(stderr,
            "Warning: Nothing to do\n");
        goto exit_ok;
    }

    if (flags & SI52142_F_RESET &&
                    flags & SI52142_F_CONFIG)
    {
        fprintf(stderr,
            "Error: Both '--reset' and configuration options\n");
        goto exit_err;
    }

    // Handle options according to priorities:
    if (flags & SI52142_F_RESET)
        si52142_set_default_config(&dev);
    else if (flags & SI52142_F_CONFIG)
        si52142_set_config(&dev);

    if (flags & SI52142_F_DUMP)
        si52142_dump_config(&dev);

exit_ok:
    close(dev.file);
    exit(EXIT_SUCCESS);

exit_err:
    close(dev.file);
    exit(EXIT_FAILURE);
}

void parse_arg(char *arg, int *first, int *second)
{
    char *end;
    *first = strtoul(arg, &end, 0);
    if(*end == ':')
        *second = strtoul(++end, 0, 0);
}

static void help(char *progname)
{
    fprintf(stderr,
        "Usage: %s OPTIONS\n"
        "   E.g. %s -f -d 9:0x6b --reset --dump\n"
        "\n"
        "  Device OPTIONS:\n"
        "   -d, --device <bus:addr> Open device address 'addr' in i2c bus\n"
        "                           'bus'\n"
        "   -f, --force             Force configuration even when a driver\n"
        "                           is also running\n"
        "  Configuration OPTIONS:\n"
        "   -e, --reset             Restore default settings. Cannot be used"
        "                           with other configuration options\n"
        "   -r, --revision <4bits>  Set SI52142 Program Revision Code\n"
        "   -v, --vendor <4bits>    Set SI52142 Vendor Identification Code\n"
        "   -x, --ref <bit>         Output Enable for REF\n"
        "                               0: Output disabled\n"
        "                               1: Output enabled\n"
        "   -y, --diff0 <bit>       Output Enable for DIFF0\n"
        "                               0: Output disabled\n"
        "                               1: Output enabled\n"
        "   -z, --diff1 <bit>       Output Enable for DIFF1\n"
        "                               0: Output disabled\n"
        "                               1: Output enabled\n"
        "   -b, --bc <8bits>        Set Byte Count register\n"
        "   -c, --control <3bits>   Set DIFF Differential Outputs Amplitude\n"
        "                           Adjustment\n"
        "                               0:300mV  1:400mV  2:500mv  3:600mV\n"
        "                               4:700mV  5:800mV  6:900mv  7:1000mV\n"
        "   -s, --select <bit>      Set Amplitude Control for DIFF\n"
        "                           Differential Outputs\n"
        "                               0: Differential outputs with Default\n"
        "                                  amplitude.\n"
        "                               1: Differential outputs amplitude is\n"
        "                                  set by --control\n"
        "  Optional OPTIONS:\n"
        "	-h, --help              Print this help\n"
        "	-p, --dump              Print SI52142 configuration\n"
        "\n", NO_PATH(progname), NO_PATH(progname));
}
