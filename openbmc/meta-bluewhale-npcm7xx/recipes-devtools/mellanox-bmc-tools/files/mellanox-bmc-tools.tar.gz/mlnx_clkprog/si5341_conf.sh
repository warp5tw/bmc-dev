#! /bin/bash

# This script is used for Si5341 device programming in BlueWhale.
# The clock device is attached to I2C bus 9 at 0x74. This helper
# script provides wrapper functions for 'mlnx_si5341prog' and
# allows users to verify the registers configuration, configure
# the registers, and NVM programming. Registers read/write are
# done through I2C interface. 
#
# It expects few arguments to be set:
#   -c, --config    FILE       Configure the device using the registers
#                              configuration file FILE.
#   -v, --verify    FILE       Verify the device configuration and
#                              compare it to the registers configuration
#                              file FILE.
#   -s, --save                 Save the device configuration.
#
# Advanced argument:
#   -a, --auto [-y] FILE       Auto configure the clock device. This
#                              run a configuration sequence to setup
#                              clock registers and re-program the NVM
#                              if needed.
#
# WARNING: '-a|--auto' assumes that there is a single and unique valid
# configuration for BlueWhale. This is a serious burden for such helper
# script. Thus, the option MUST be revised whenever the configuration
# changes. This feature has been requested by SPE team.
# In the future, it is highly recommended to wrap-up this helper script
# when users wish to use it in specific contexts.
set -e

PROGNAME=$(basename $0)

# To debug set "run=echo"
run=

# Set the i2c bus number.
bus=9
# Set the device I2C address.
addr=0x74

# Expected output parameters.
#
# WARNING: This MUST be consistant with the configuration
# provided by Signal Integrity guys:
#
#    Part: Si5341
#    Project File: A:\bluewhale\WORKSPACE\Clock_Files\Si5341-RevD-BLUWHLV1-Project.slabtimeproj
#    Design ID: BLUWHLV1
#    Includes Pre/Post Download Control Register Writes: Yes
#    Die Revision: B1
#    Creator: ClockBuilder Pro v2.15 [2017-05-15]
#    Created On: 2017-05-24 10:31:09 GMT-04:00
#
# Please either update those parameters whenever the
# aformentionned project/configuration changes, or ask the
# user to provide them as input files to be passed to the
# script.
CONFIG_EXP="Configuration completed with 0 errors while writing 369 bytes"
VERIFY_EXP=\
"WARNING: Register 0x0017 has value 0x10, should be 0xd0
WARNING: Register 0x0b57 has value 0x0, should be 0xe
WARNING: Register 0x0b58 has value 0x0, should be 0x1
3 errors detected while checking 369 registers"

si5341_configure () {
    # Step 1: Configuration preamble
    $run i2cset -y $bus $addr 0x01 0x0B
    $run i2cset -y $bus $addr 0x24 0xC0
    $run i2cset -y $bus $addr 0x25 0x00
    $run i2cset -y $bus $addr 0x01 0x00

    # Delay to complete any calibration that is running due
    # to device state change previous to this script being
    # processed. The worst case time is 300ms, but let's
    # wait 1s, instead (no rush!)
    sleep 1

    # Step 2: Configuration registers
    CONFIG_GEN="$(mlnx_si5341prog --device $bus:$addr --setconf $1 2>&1)"

    # Step 3: SW reset and configuration postamble
    $run i2cset -y $bus $addr 0x01 0x00
    $run i2cset -y $bus $addr 0x1C 0x01
    $run i2cset -y $bus $addr 0x01 0x0B
    $run i2cset -y $bus $addr 0x24 0xC3
    $run i2cset -y $bus $addr 0x25 0x02
    $run i2cset -y $bus $addr 0x01 0x00
}

si5341_verify () {
    VERIFY_GEN="$(mlnx_si5341prog --device $bus:$addr --checkconf $1 2>&1)"
}

while :; do
    # Work out what we should be doing
    case $1 in
        -c|--config)
            # Get the configuration file
            if [ $# -eq 2 ]; then
                regconf=$2
            else
                echo "$PROGNAME: bad usage"
                echo "Try: $PROGNAME [-c|--config] FILE"
                exit 1
            fi

            #
            # Configure the device registers
            #
            echo "Configure device registers"
            $run si5341_configure $regconf
            echo "$CONFIG_GEN"
            exit 0
            ;;

        -v|--verify)
            # Get the configuration file, i.e. expected configuration
            if [ $# -eq 2 ]; then
                regconf=$2
            else
                echo "$PROGNAME: bad usage"
                echo "Try: $PROGNAME [-v|--verify] FILE"
                exit 1
            fi

            #
            # Verify device register configuration
            #

            echo "Verify device registers"
            $run si5341_verify $regconf
            echo "$VERIFY_GEN"
            exit 0
            ;;

        -s|--save)
            # Get the configuration file
            if [ $# -ge 2 ]; then
                echo "$PROGNAME: bad usage"
                echo "Try: $PROGNAME [-s|--save]"
                exit 1
            fi

            #
            # NVM programming
            #

            # WARNING: NVM can be written two times only. It is
            # important to configure the registers correctly before
            # beginning the NVM programming process.
            echo "WARNING: NVM can be written two times."
            echo "Continue [y/n]:"
            read -n 1 KEY; echo
            if [ "${KEY}" = "y" ]; then
                echo "Re-programming NVM..."
                $run mlnx_si5341prog --device $bus:$addr --saveconf
                exit $?
            else
                echo "Nothing to do!"
                exit 0
            fi
            ;;

        -a|--auto)
            # WARNING: '-a|--auto' assumes that there is a single and unique
            # valid configuration for BlueWhale. This is a serious burden for
            # such helper script. Thus, the option MUST be revised whenever
            # the configuration changes. This feature has been requested by
            # SPE team.

            # Get the configuration file, i.e. expected configuration
            if [ $# -eq 3 ]; then
                if [ "$2" != "-y" ]; then
                    echo "$PROGNAME: bad argument '$2'"
                    echo "Try: $PROGNAME [-a|--auto] [-y] FILE"
                    exit 1
                fi
                nvm=1
                regconf=$3
            elif [ $# -eq 2 ]; then
                nvm=0
                regconf=$2
            else
                echo "$PROGNAME: bad usage"
                echo "Try: $PROGNAME [-a|--auto] [-y] FILE"
                exit 1
            fi

            #
            # Check whether the registers are already set with
            # the given config. If so, skip the configuration
            # step.
            #
            echo "Verify current device registers"
            $run si5341_verify $regconf
            # Check whether registers configuration is needed.
            if diff <(echo "$VERIFY_GEN") <(echo "$VERIFY_EXP") &>/dev/null; then
                echo "Device already configured."
                exit 0
            fi

            #
            # Configure the device registers
            #
            echo "Configure device registers"
            $run si5341_configure $regconf
            # Check whether the configuration is successful.
            if ! diff <(echo "$CONFIG_GEN") <(echo "$CONFIG_EXP") &>/dev/null; then
                echo "$CONFIG_GEN"
                echo "ERROR: Either configuration failed or input file is invalid"
                exit 1
            fi

            #
            # Check whether the registers are set properly.
            #
            echo "Verify device registers"
            $run si5341_verify $regconf
            if ! diff <(echo "$VERIFY_GEN") <(echo "$VERIFY_EXP") &>/dev/null; then
                echo "$VERIFY_GEN"
                echo "ERROR: Configuration is invalid"
                exit 1
            fi

            #
            # Save the configuration, if needed
            #
            if [ $nvm -eq 1 ]; then
                echo "NVM programming"
                $run mlnx_si5341prog --device $bus:$addr --saveconf
                exit $?
            fi

            echo "Device configuration completed"
            exit 0
            ;;

        *)
            # Die if the optional argument isn't supported.
            echo "Try: "
            echo " -c,--config FILE    Configure the device using the registers"
            echo "                     configuration file FILE."
            echo " -v,--verify FILE    Verify the device configuration and"
            echo "                     compare it to registers configuration"
            echo "                     file FILE."
            echo " -s,--save           Save the device configuration."
            echo " "
            echo " -a,--auto [-y] FILE Auto configure the clock device. This"
            echo "                     run a configuration sequence to setup"
            echo "                     clock registers. Add '-f' to enable NVM"
            echo "                     programming."
            exit 1
            ;;
    esac
done
