#ifndef BMC_I2C_SMBUS_H
#define BMC_I2C_SMBUS_H

#include <stdbool.h>
#include <stdint.h>
#include <linux/i2c.h>

#define BMC_I2C_BUS_CNT             14

#define CHECK_I2C_FUNC(var, label) \
    ({  if (((var) & (label)) == 0) \
        { \
            fprintf(stderr, "\nError: " \
                #label " function is required. Program halted.\n\n"); \
            exit(1); \
        } \
    })

int i2c_smbus_init(int bus, int addr, bool force);

int i2c_smbus_access(int     file,
                     char    read_write,
                     uint8_t command,
                     int     size,
                     union i2c_smbus_data *data);

// This executes the SMBus "receive byte" protocol, returning negative errno
// else the byte received from the device.
int i2c_smbus_read_byte(int file);

// This executes the SMBus "send byte" protocol, returning negative errno
// else zero on success.
int i2c_smbus_write_byte(int file, uint8_t value);

// This executes the SMBus "read byte" protocol, returning negative errno
// else a data byte received from the device.
int i2c_smbus_read_byte_data(int file, uint8_t command);

// This executes the SMBus "write byte" protocol, returning negative errno
// else zero on success.
int i2c_smbus_write_byte_data(int file, uint8_t command, uint8_t value);

// This executes the SMBus "block read" protocol, returning negative errno
// else the number of data bytes in the slave's response.
int i2c_smbus_read_block_data(int file, uint8_t command, uint8_t *values);

// This executes the SMBus "block write" protocol, returning negative errno
// else zero on success.
int i2c_smbus_write_block_data(int     file,
                               uint8_t command,
                               uint8_t length,
                               const uint8_t *values);
#endif
