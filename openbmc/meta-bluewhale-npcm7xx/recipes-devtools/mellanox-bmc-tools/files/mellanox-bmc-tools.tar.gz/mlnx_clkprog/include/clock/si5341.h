/*
 * Si5341 Rev D Regmap Header File
 *
 * This file describes the register map for a Silicon Labs
 * Si5341 Rev D. It defines the meta-data for each device setting, 
 * such as number of bits and location with the device address
 * space. It was created by a Silicon Labs ClockBuilder Pro
 * export tool.
 * 
 * Part:	   Si5341 Rev D
 * Created By: ClockBuilder Pro v2.12.1 [2016-12-15]
 * Timestamp:  2017-02-09 12:41:41 GMT-05:00
 *
 * A textual, report oriented version of the register map is 
 * included at the end of this header file.
 *
 */

#ifndef SI5341_REVD_REGMAP_HEADER
#define SI5341_REVD_REGMAP_HEADER

#define SI5341_REVD_NUM_SETTINGS				351
#define SI5341_REVD_MAX_NUM_REGS				10

#define SLAB_NVMT_NONE 0
#define SLAB_NVMT_SLAB 1
#define SLAB_NVMT_CUST 2

#define CHAR	char
#define UINT8	unsigned char
#define UINT16	unsigned int

typedef struct
{
	CHAR*  name;								/* Setting/bitfield name                                           */ 
	UINT8  read_only;							/* 1 for read only setting/regs or 0 for read/write                */
	UINT8  self_clearing;						/* 1 for self-clearing setting/registers or 0 otherwise            */
	UINT8  nvm_type;							/* See above                                                       */
	UINT8  bit_length;							/* Number of bits in setting                                       */
	UINT8  start_bit;							/* Least significant bit of the setting                            */
	UINT8  reg_length;							/* Number of registers that the setting is stored in               */
	UINT16 addr[SI5341_REVD_MAX_NUM_REGS];	/* Addresses the setting is contained in						   */
	UINT8  mask[SI5341_REVD_MAX_NUM_REGS];	/* Bitmask for each register containing the setting				   */
} si5341_revd_regmap_t;

/* 
 * Array of setting meta-data; use macros such as SI5341_REVD_DIE_REV defined after
 * this block to index into the array. 
 *
 * E.g. si5341_revd_settings[SI5341_REVD_DIE_REV].bit_length
 *
 * You may need to change "const" keyword to "xdata" or "code" depending 
 * on CPU/compiler/memory constraints.
 */
static si5341_revd_regmap_t si5341_revd_settings[SI5341_REVD_NUM_SETTINGS] =
{

	/* DIE_REV */
	{
		"DIE_REV",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0000, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* PAGE */
	{
		"PAGE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0001, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* PN_BASE */
	{
		"PN_BASE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0002, /* Register address 0 b7:0 */
			0x0003, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* GRADE */
	{
		"GRADE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0004, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* DEVICE_REV */
	{
		"DEVICE_REV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0005, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* TOOL_VERSION */
	{
		"TOOL_VERSION",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x0006, /* Register address 0 b7:0 */
			0x0007, /* Register address 1 b7:0 */
			0x0008, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* TEMP_GRADE */
	{
		"TEMP_GRADE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0009, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* PKG_ID */
	{
		"PKG_ID",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x000A, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* I2C_ADDR */
	{
		"I2C_ADDR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		7, /* 7 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x000B, /* Register address 0 b7:0 */

		},
		{
			0x7F, /* Register mask 0 */

		}
	},

	/* SYSINCAL */
	{
		"SYSINCAL",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x000C, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* LOSXAXB */
	{
		"LOSXAXB",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x000C, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* LOSREF */
	{
		"LOSREF",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x000C, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* SMBUS_TIMEOUT */
	{
		"SMBUS_TIMEOUT",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		5, /* setting starts at b5 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x000C, /* Register address 0 b7:0 */

		},
		{
			0x20, /* Register mask 0 */

		}
	},

	/* LOL */
	{
		"LOL",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x000C, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* LOSIN */
	{
		"LOSIN",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x000D, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* SYSINCAL_FLG */
	{
		"SYSINCAL_FLG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0011, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* LOSXAXB_FLG */
	{
		"LOSXAXB_FLG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0011, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* LOSREF_FLG */
	{
		"LOSREF_FLG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0011, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* LOL_FLG */
	{
		"LOL_FLG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0011, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* SMBUS_TIMEOUT_FLG */
	{
		"SMBUS_TIMEOUT_FLG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		5, /* setting starts at b5 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0011, /* Register address 0 b7:0 */

		},
		{
			0x20, /* Register mask 0 */

		}
	},

	/* LOSIN_FLG */
	{
		"LOSIN_FLG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0012, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* SYSINCAL_INTR_MSK */
	{
		"SYSINCAL_INTR_MSK",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0017, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* LOSXAXB_INTR_MSK */
	{
		"LOSXAXB_INTR_MSK",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0017, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* LOSREF_INTR_MSK */
	{
		"LOSREF_INTR_MSK",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0017, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* LOL_INTR_MSK */
	{
		"LOL_INTR_MSK",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0017, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* SMB_TMOUT_INTR_MSK */
	{
		"SMB_TMOUT_INTR_MSK",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		5, /* setting starts at b5 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0017, /* Register address 0 b7:0 */

		},
		{
			0x20, /* Register mask 0 */

		}
	},

	/* LOSIN_INTR_MSK */
	{
		"LOSIN_INTR_MSK",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0018, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* SOFT_RST */
	{
		"SOFT_RST",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x001C, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* SOFTCAL */
	{
		"SOFTCAL",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		5, /* setting starts at b5 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x001C, /* Register address 0 b7:0 */

		},
		{
			0x20, /* Register mask 0 */

		}
	},

	/* FINC */
	{
		"FINC",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x001D, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* FDEC */
	{
		"FDEC",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x001D, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* PDN */
	{
		"PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x001E, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* HARD_RST */
	{
		"HARD_RST",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x001E, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* SYNC */
	{
		"SYNC",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x001E, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* IN_SEL_REGCTRL */
	{
		"IN_SEL_REGCTRL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0021, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* IN_SEL */
	{
		"IN_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0021, /* Register address 0 b7:0 */

		},
		{
			0x06, /* Register mask 0 */

		}
	},

	/* OE */
	{
		"OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0022, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* SPI_3WIRE */
	{
		"SPI_3WIRE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x002B, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* AUTO_NDIV_UPDATE */
	{
		"AUTO_NDIV_UPDATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		5, /* setting starts at b5 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x002B, /* Register address 0 b7:0 */

		},
		{
			0x20, /* Register mask 0 */

		}
	},

	/* LOS_EN */
	{
		"LOS_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x002C, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* LOSXAXB_DIS */
	{
		"LOSXAXB_DIS",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x002C, /* Register address 0 b7:0 */

		},
		{
			0x10, /* Register mask 0 */

		}
	},

	/* LOS0_VAL_TIME */
	{
		"LOS0_VAL_TIME",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x002D, /* Register address 0 b7:0 */

		},
		{
			0x03, /* Register mask 0 */

		}
	},

	/* LOS1_VAL_TIME */
	{
		"LOS1_VAL_TIME",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x002D, /* Register address 0 b7:0 */

		},
		{
			0x0C, /* Register mask 0 */

		}
	},

	/* LOS2_VAL_TIME */
	{
		"LOS2_VAL_TIME",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x002D, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* LOS3_VAL_TIME */
	{
		"LOS3_VAL_TIME",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x002D, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* LOS0_TRG_THR */
	{
		"LOS0_TRG_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x002E, /* Register address 0 b7:0 */
			0x002F, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* LOS1_TRG_THR */
	{
		"LOS1_TRG_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0030, /* Register address 0 b7:0 */
			0x0031, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* LOS2_TRG_THR */
	{
		"LOS2_TRG_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0032, /* Register address 0 b7:0 */
			0x0033, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* LOS3_TRG_THR */
	{
		"LOS3_TRG_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0034, /* Register address 0 b7:0 */
			0x0035, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* LOS0_CLR_THR */
	{
		"LOS0_CLR_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0036, /* Register address 0 b7:0 */
			0x0037, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* LOS1_CLR_THR */
	{
		"LOS1_CLR_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0038, /* Register address 0 b7:0 */
			0x0039, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* LOS2_CLR_THR */
	{
		"LOS2_CLR_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x003A, /* Register address 0 b7:0 */
			0x003B, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* LOS3_CLR_THR */
	{
		"LOS3_CLR_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x003C, /* Register address 0 b7:0 */
			0x003D, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* LOS0_DIV_SEL */
	{
		"LOS0_DIV_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0041, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* LOS1_DIV_SEL */
	{
		"LOS1_DIV_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0042, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* LOS2_DIV_SEL */
	{
		"LOS2_DIV_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0043, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* LOS3_DIV_SEL */
	{
		"LOS3_DIV_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0044, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* LOL_SET_THR */
	{
		"LOL_SET_THR",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x009E, /* Register address 0 b7:0 */

		},
		{
			0xF0, /* Register mask 0 */

		}
	},

	/* ACTIVE_NVM_BANK */
	{
		"ACTIVE_NVM_BANK",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00E2, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* REG_0XF7_INTR */
	{
		"REG_0XF7_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F6, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* REG_0XF8_INTR */
	{
		"REG_0XF8_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F6, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* SYSINCAL_INTR */
	{
		"SYSINCAL_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F7, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* LOSXAXB_INTR */
	{
		"LOSXAXB_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F7, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* LOSREF_INTR */
	{
		"LOSREF_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F7, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* LOSVCO_INTR */
	{
		"LOSVCO_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F7, /* Register address 0 b7:0 */

		},
		{
			0x10, /* Register mask 0 */

		}
	},

	/* LOL_INTR */
	{
		"LOL_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F7, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* SMBUS_TIME_OUT_INTR */
	{
		"SMBUS_TIME_OUT_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		5, /* setting starts at b5 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F7, /* Register address 0 b7:0 */

		},
		{
			0x20, /* Register mask 0 */

		}
	},

	/* LOS_INTR */
	{
		"LOS_INTR",
		1, /* 1 = IS Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x00F8, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUTALL_DISABLE_LOW */
	{
		"OUTALL_DISABLE_LOW",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0102, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT0_PDN */
	{
		"OUT0_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0108, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT0_OE */
	{
		"OUT0_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0108, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT0_RDIV_FORCE2 */
	{
		"OUT0_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0108, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT0_FORMAT */
	{
		"OUT0_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0109, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT0_SYNC_EN */
	{
		"OUT0_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0109, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT0_DIS_STATE */
	{
		"OUT0_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0109, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT0_CMOS_DRV */
	{
		"OUT0_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0109, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT0_CM */
	{
		"OUT0_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010A, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT0_AMPL */
	{
		"OUT0_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010A, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT0_MUX_SEL */
	{
		"OUT0_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010B, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT0_VDD_SEL */
	{
		"OUT0_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010B, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT0_VDD_SEL_EN */
	{
		"OUT0_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010B, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT0_INV */
	{
		"OUT0_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010B, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT1_PDN */
	{
		"OUT1_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010D, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT1_OE */
	{
		"OUT1_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010D, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT1_RDIV_FORCE2 */
	{
		"OUT1_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010D, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT1_FORMAT */
	{
		"OUT1_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010E, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT1_SYNC_EN */
	{
		"OUT1_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010E, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT1_DIS_STATE */
	{
		"OUT1_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010E, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT1_CMOS_DRV */
	{
		"OUT1_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010E, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT1_CM */
	{
		"OUT1_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010F, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT1_AMPL */
	{
		"OUT1_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x010F, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT1_MUX_SEL */
	{
		"OUT1_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0110, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT1_VDD_SEL */
	{
		"OUT1_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0110, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT1_VDD_SEL_EN */
	{
		"OUT1_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0110, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT1_INV */
	{
		"OUT1_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0110, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT2_PDN */
	{
		"OUT2_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0112, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT2_OE */
	{
		"OUT2_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0112, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT2_RDIV_FORCE2 */
	{
		"OUT2_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0112, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT2_FORMAT */
	{
		"OUT2_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0113, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT2_SYNC_EN */
	{
		"OUT2_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0113, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT2_DIS_STATE */
	{
		"OUT2_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0113, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT2_CMOS_DRV */
	{
		"OUT2_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0113, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT2_CM */
	{
		"OUT2_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0114, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT2_AMPL */
	{
		"OUT2_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0114, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT2_MUX_SEL */
	{
		"OUT2_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0115, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT2_VDD_SEL */
	{
		"OUT2_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0115, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT2_VDD_SEL_EN */
	{
		"OUT2_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0115, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT2_INV */
	{
		"OUT2_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0115, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT3_PDN */
	{
		"OUT3_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0117, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT3_OE */
	{
		"OUT3_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0117, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT3_RDIV_FORCE2 */
	{
		"OUT3_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0117, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT3_FORMAT */
	{
		"OUT3_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0118, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT3_SYNC_EN */
	{
		"OUT3_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0118, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT3_DIS_STATE */
	{
		"OUT3_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0118, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT3_CMOS_DRV */
	{
		"OUT3_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0118, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT3_CM */
	{
		"OUT3_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0119, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT3_AMPL */
	{
		"OUT3_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0119, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT3_MUX_SEL */
	{
		"OUT3_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011A, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT3_VDD_SEL */
	{
		"OUT3_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011A, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT3_VDD_SEL_EN */
	{
		"OUT3_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011A, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT3_INV */
	{
		"OUT3_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011A, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT4_PDN */
	{
		"OUT4_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011C, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT4_OE */
	{
		"OUT4_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011C, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT4_RDIV_FORCE2 */
	{
		"OUT4_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011C, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT4_FORMAT */
	{
		"OUT4_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011D, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT4_SYNC_EN */
	{
		"OUT4_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011D, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT4_DIS_STATE */
	{
		"OUT4_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011D, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT4_CMOS_DRV */
	{
		"OUT4_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011D, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT4_CM */
	{
		"OUT4_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011E, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT4_AMPL */
	{
		"OUT4_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011E, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT4_MUX_SEL */
	{
		"OUT4_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011F, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT4_VDD_SEL */
	{
		"OUT4_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011F, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT4_VDD_SEL_EN */
	{
		"OUT4_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011F, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT4_INV */
	{
		"OUT4_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x011F, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT5_PDN */
	{
		"OUT5_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0121, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT5_OE */
	{
		"OUT5_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0121, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT5_RDIV_FORCE2 */
	{
		"OUT5_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0121, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT5_FORMAT */
	{
		"OUT5_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0122, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT5_SYNC_EN */
	{
		"OUT5_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0122, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT5_DIS_STATE */
	{
		"OUT5_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0122, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT5_CMOS_DRV */
	{
		"OUT5_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0122, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT5_CM */
	{
		"OUT5_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0123, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT5_AMPL */
	{
		"OUT5_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0123, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT5_MUX_SEL */
	{
		"OUT5_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0124, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT5_VDD_SEL */
	{
		"OUT5_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0124, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT5_VDD_SEL_EN */
	{
		"OUT5_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0124, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT5_INV */
	{
		"OUT5_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0124, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT6_PDN */
	{
		"OUT6_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0126, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT6_OE */
	{
		"OUT6_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0126, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT6_RDIV_FORCE2 */
	{
		"OUT6_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0126, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT6_FORMAT */
	{
		"OUT6_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0127, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT6_SYNC_EN */
	{
		"OUT6_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0127, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT6_DIS_STATE */
	{
		"OUT6_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0127, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT6_CMOS_DRV */
	{
		"OUT6_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0127, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT6_CM */
	{
		"OUT6_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0128, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT6_AMPL */
	{
		"OUT6_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0128, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT6_MUX_SEL */
	{
		"OUT6_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0129, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT6_VDD_SEL */
	{
		"OUT6_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0129, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT6_VDD_SEL_EN */
	{
		"OUT6_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0129, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT6_INV */
	{
		"OUT6_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0129, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT7_PDN */
	{
		"OUT7_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012B, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT7_OE */
	{
		"OUT7_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012B, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT7_RDIV_FORCE2 */
	{
		"OUT7_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012B, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT7_FORMAT */
	{
		"OUT7_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012C, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT7_SYNC_EN */
	{
		"OUT7_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012C, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT7_DIS_STATE */
	{
		"OUT7_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012C, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT7_CMOS_DRV */
	{
		"OUT7_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012C, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT7_CM */
	{
		"OUT7_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012D, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT7_AMPL */
	{
		"OUT7_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012D, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT7_MUX_SEL */
	{
		"OUT7_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012E, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT7_VDD_SEL */
	{
		"OUT7_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012E, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT7_VDD_SEL_EN */
	{
		"OUT7_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012E, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT7_INV */
	{
		"OUT7_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x012E, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT8_PDN */
	{
		"OUT8_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0130, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT8_OE */
	{
		"OUT8_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0130, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT8_RDIV_FORCE2 */
	{
		"OUT8_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0130, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT8_FORMAT */
	{
		"OUT8_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0131, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT8_SYNC_EN */
	{
		"OUT8_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0131, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT8_DIS_STATE */
	{
		"OUT8_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0131, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT8_CMOS_DRV */
	{
		"OUT8_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0131, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT8_CM */
	{
		"OUT8_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0132, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT8_AMPL */
	{
		"OUT8_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0132, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT8_MUX_SEL */
	{
		"OUT8_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0133, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT8_VDD_SEL */
	{
		"OUT8_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0133, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT8_VDD_SEL_EN */
	{
		"OUT8_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0133, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT8_INV */
	{
		"OUT8_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0133, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT9_PDN */
	{
		"OUT9_PDN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013A, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* OUT9_OE */
	{
		"OUT9_OE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013A, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* OUT9_RDIV_FORCE2 */
	{
		"OUT9_RDIV_FORCE2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013A, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* OUT9_FORMAT */
	{
		"OUT9_FORMAT",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013B, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT9_SYNC_EN */
	{
		"OUT9_SYNC_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013B, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT9_DIS_STATE */
	{
		"OUT9_DIS_STATE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013B, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT9_CMOS_DRV */
	{
		"OUT9_CMOS_DRV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013B, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUT9_CM */
	{
		"OUT9_CM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013C, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* OUT9_AMPL */
	{
		"OUT9_AMPL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013C, /* Register address 0 b7:0 */

		},
		{
			0x70, /* Register mask 0 */

		}
	},

	/* OUT9_MUX_SEL */
	{
		"OUT9_MUX_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013D, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* OUT9_VDD_SEL */
	{
		"OUT9_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013D, /* Register address 0 b7:0 */

		},
		{
			0x30, /* Register mask 0 */

		}
	},

	/* OUT9_VDD_SEL_EN */
	{
		"OUT9_VDD_SEL_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013D, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* OUT9_INV */
	{
		"OUT9_INV",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		6, /* setting starts at b6 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x013D, /* Register address 0 b7:0 */

		},
		{
			0xC0, /* Register mask 0 */

		}
	},

	/* OUTX_ALWAYS_ON */
	{
		"OUTX_ALWAYS_ON",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		12, /* 12 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x013F, /* Register address 0 b7:0 */
			0x0140, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0x0F, /* Register mask 1 */

		}
	},

	/* OUT_DIS_LOL_MSK */
	{
		"OUT_DIS_LOL_MSK",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		5, /* setting starts at b5 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0141, /* Register address 0 b7:0 */

		},
		{
			0x20, /* Register mask 0 */

		}
	},

	/* OUT_DIS_MSK_LOS_PFD */
	{
		"OUT_DIS_MSK_LOS_PFD",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		7, /* setting starts at b7 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0141, /* Register address 0 b7:0 */

		},
		{
			0x80, /* Register mask 0 */

		}
	},

	/* OUT_PDN_ALL */
	{
		"OUT_PDN_ALL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0145, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* PXAXB */
	{
		"PXAXB",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		2, /* 2 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0206, /* Register address 0 b7:0 */

		},
		{
			0x03, /* Register mask 0 */

		}
	},

	/* P0 */
	{
		"P0",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		48, /* 48 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0208, /* Register address 0 b7:0 */
			0x0209, /* Register address 1 b7:0 */
			0x020A, /* Register address 2 b7:0 */
			0x020B, /* Register address 3 b7:0 */
			0x020C, /* Register address 4 b7:0 */
			0x020D, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0xFF, /* Register mask 5 */

		}
	},

	/* P0_SET */
	{
		"P0_SET",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x020E, /* Register address 0 b7:0 */
			0x020F, /* Register address 1 b7:0 */
			0x0210, /* Register address 2 b7:0 */
			0x0211, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* P1 */
	{
		"P1",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		48, /* 48 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0212, /* Register address 0 b7:0 */
			0x0213, /* Register address 1 b7:0 */
			0x0214, /* Register address 2 b7:0 */
			0x0215, /* Register address 3 b7:0 */
			0x0216, /* Register address 4 b7:0 */
			0x0217, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0xFF, /* Register mask 5 */

		}
	},

	/* P1_SET */
	{
		"P1_SET",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x0218, /* Register address 0 b7:0 */
			0x0219, /* Register address 1 b7:0 */
			0x021A, /* Register address 2 b7:0 */
			0x021B, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* P2 */
	{
		"P2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		48, /* 48 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x021C, /* Register address 0 b7:0 */
			0x021D, /* Register address 1 b7:0 */
			0x021E, /* Register address 2 b7:0 */
			0x021F, /* Register address 3 b7:0 */
			0x0220, /* Register address 4 b7:0 */
			0x0221, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0xFF, /* Register mask 5 */

		}
	},

	/* P2_SET */
	{
		"P2_SET",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x0222, /* Register address 0 b7:0 */
			0x0223, /* Register address 1 b7:0 */
			0x0224, /* Register address 2 b7:0 */
			0x0225, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* P3 */
	{
		"P3",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		48, /* 48 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0226, /* Register address 0 b7:0 */
			0x0227, /* Register address 1 b7:0 */
			0x0228, /* Register address 2 b7:0 */
			0x0229, /* Register address 3 b7:0 */
			0x022A, /* Register address 4 b7:0 */
			0x022B, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0xFF, /* Register mask 5 */

		}
	},

	/* P3_SET */
	{
		"P3_SET",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x022C, /* Register address 0 b7:0 */
			0x022D, /* Register address 1 b7:0 */
			0x022E, /* Register address 2 b7:0 */
			0x022F, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* P0_UPDATE */
	{
		"P0_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0230, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* P1_UPDATE */
	{
		"P1_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0230, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* P2_UPDATE */
	{
		"P2_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		2, /* setting starts at b2 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0230, /* Register address 0 b7:0 */

		},
		{
			0x04, /* Register mask 0 */

		}
	},

	/* P3_UPDATE */
	{
		"P3_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		3, /* setting starts at b3 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0230, /* Register address 0 b7:0 */

		},
		{
			0x08, /* Register mask 0 */

		}
	},

	/* M_NUM */
	{
		"M_NUM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0235, /* Register address 0 b7:0 */
			0x0236, /* Register address 1 b7:0 */
			0x0237, /* Register address 2 b7:0 */
			0x0238, /* Register address 3 b7:0 */
			0x0239, /* Register address 4 b7:0 */
			0x023A, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* M_DEN */
	{
		"M_DEN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x023B, /* Register address 0 b7:0 */
			0x023C, /* Register address 1 b7:0 */
			0x023D, /* Register address 2 b7:0 */
			0x023E, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* M_UPDATE */
	{
		"M_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_NONE, /* Not stored in NVM */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x023F, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* R0_REG */
	{
		"R0_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x024A, /* Register address 0 b7:0 */
			0x024B, /* Register address 1 b7:0 */
			0x024C, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R1_REG */
	{
		"R1_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x024D, /* Register address 0 b7:0 */
			0x024E, /* Register address 1 b7:0 */
			0x024F, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R2_REG */
	{
		"R2_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x0250, /* Register address 0 b7:0 */
			0x0251, /* Register address 1 b7:0 */
			0x0252, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R3_REG */
	{
		"R3_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x0253, /* Register address 0 b7:0 */
			0x0254, /* Register address 1 b7:0 */
			0x0255, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R4_REG */
	{
		"R4_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x0256, /* Register address 0 b7:0 */
			0x0257, /* Register address 1 b7:0 */
			0x0258, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R5_REG */
	{
		"R5_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x0259, /* Register address 0 b7:0 */
			0x025A, /* Register address 1 b7:0 */
			0x025B, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R6_REG */
	{
		"R6_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x025C, /* Register address 0 b7:0 */
			0x025D, /* Register address 1 b7:0 */
			0x025E, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R7_REG */
	{
		"R7_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x025F, /* Register address 0 b7:0 */
			0x0260, /* Register address 1 b7:0 */
			0x0261, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R8_REG */
	{
		"R8_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x0262, /* Register address 0 b7:0 */
			0x0263, /* Register address 1 b7:0 */
			0x0264, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* R9_REG */
	{
		"R9_REG",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		24, /* 24 bits in this setting */
		0, /* setting starts at b0 in first register */
		3, /* contained in 3 registers(s) */
		{
			0x0268, /* Register address 0 b7:0 */
			0x0269, /* Register address 1 b7:0 */
			0x026A, /* Register address 2 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */

		}
	},

	/* DESIGN_ID0 */
	{
		"DESIGN_ID0",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x026B, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* DESIGN_ID1 */
	{
		"DESIGN_ID1",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x026C, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* DESIGN_ID2 */
	{
		"DESIGN_ID2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x026D, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* DESIGN_ID3 */
	{
		"DESIGN_ID3",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x026E, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* DESIGN_ID4 */
	{
		"DESIGN_ID4",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x026F, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* DESIGN_ID5 */
	{
		"DESIGN_ID5",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0270, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* DESIGN_ID6 */
	{
		"DESIGN_ID6",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0271, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* DESIGN_ID7 */
	{
		"DESIGN_ID7",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0272, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* OPN_ID0 */
	{
		"OPN_ID0",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0278, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* OPN_ID1 */
	{
		"OPN_ID1",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0279, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* OPN_ID2 */
	{
		"OPN_ID2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x027A, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* OPN_ID3 */
	{
		"OPN_ID3",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x027B, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* OPN_ID4 */
	{
		"OPN_ID4",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x027C, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* OPN_REVISION */
	{
		"OPN_REVISION",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x027D, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* BASELINE_ID */
	{
		"BASELINE_ID",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_SLAB, /* SiLabs NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x027E, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* N0_NUM */
	{
		"N0_NUM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0302, /* Register address 0 b7:0 */
			0x0303, /* Register address 1 b7:0 */
			0x0304, /* Register address 2 b7:0 */
			0x0305, /* Register address 3 b7:0 */
			0x0306, /* Register address 4 b7:0 */
			0x0307, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N0_DEN */
	{
		"N0_DEN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x0308, /* Register address 0 b7:0 */
			0x0309, /* Register address 1 b7:0 */
			0x030A, /* Register address 2 b7:0 */
			0x030B, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* N0_UPDATE */
	{
		"N0_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x030C, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* N1_NUM */
	{
		"N1_NUM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x030D, /* Register address 0 b7:0 */
			0x030E, /* Register address 1 b7:0 */
			0x030F, /* Register address 2 b7:0 */
			0x0310, /* Register address 3 b7:0 */
			0x0311, /* Register address 4 b7:0 */
			0x0312, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N1_DEN */
	{
		"N1_DEN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x0313, /* Register address 0 b7:0 */
			0x0314, /* Register address 1 b7:0 */
			0x0315, /* Register address 2 b7:0 */
			0x0316, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* N1_UPDATE */
	{
		"N1_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0317, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* N2_NUM */
	{
		"N2_NUM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0318, /* Register address 0 b7:0 */
			0x0319, /* Register address 1 b7:0 */
			0x031A, /* Register address 2 b7:0 */
			0x031B, /* Register address 3 b7:0 */
			0x031C, /* Register address 4 b7:0 */
			0x031D, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N2_DEN */
	{
		"N2_DEN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x031E, /* Register address 0 b7:0 */
			0x031F, /* Register address 1 b7:0 */
			0x0320, /* Register address 2 b7:0 */
			0x0321, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* N2_UPDATE */
	{
		"N2_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0322, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* N3_NUM */
	{
		"N3_NUM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0323, /* Register address 0 b7:0 */
			0x0324, /* Register address 1 b7:0 */
			0x0325, /* Register address 2 b7:0 */
			0x0326, /* Register address 3 b7:0 */
			0x0327, /* Register address 4 b7:0 */
			0x0328, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N3_DEN */
	{
		"N3_DEN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x0329, /* Register address 0 b7:0 */
			0x032A, /* Register address 1 b7:0 */
			0x032B, /* Register address 2 b7:0 */
			0x032C, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* N3_UPDATE */
	{
		"N3_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x032D, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* N4_NUM */
	{
		"N4_NUM",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x032E, /* Register address 0 b7:0 */
			0x032F, /* Register address 1 b7:0 */
			0x0330, /* Register address 2 b7:0 */
			0x0331, /* Register address 3 b7:0 */
			0x0332, /* Register address 4 b7:0 */
			0x0333, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N4_DEN */
	{
		"N4_DEN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		32, /* 32 bits in this setting */
		0, /* setting starts at b0 in first register */
		4, /* contained in 4 registers(s) */
		{
			0x0334, /* Register address 0 b7:0 */
			0x0335, /* Register address 1 b7:0 */
			0x0336, /* Register address 2 b7:0 */
			0x0337, /* Register address 3 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */

		}
	},

	/* N4_UPDATE */
	{
		"N4_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0338, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* N_UPDATE */
	{
		"N_UPDATE",
		0, /* 0 = NOT Read Only */
		1, /* 1 = IS Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0338, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* N_FSTEP_MSK */
	{
		"N_FSTEP_MSK",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0339, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* N0_FSTEPW */
	{
		"N0_FSTEPW",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x033B, /* Register address 0 b7:0 */
			0x033C, /* Register address 1 b7:0 */
			0x033D, /* Register address 2 b7:0 */
			0x033E, /* Register address 3 b7:0 */
			0x033F, /* Register address 4 b7:0 */
			0x0340, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N1_FSTEPW */
	{
		"N1_FSTEPW",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0341, /* Register address 0 b7:0 */
			0x0342, /* Register address 1 b7:0 */
			0x0343, /* Register address 2 b7:0 */
			0x0344, /* Register address 3 b7:0 */
			0x0345, /* Register address 4 b7:0 */
			0x0346, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N2_FSTEPW */
	{
		"N2_FSTEPW",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0347, /* Register address 0 b7:0 */
			0x0348, /* Register address 1 b7:0 */
			0x0349, /* Register address 2 b7:0 */
			0x034A, /* Register address 3 b7:0 */
			0x034B, /* Register address 4 b7:0 */
			0x034C, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N3_FSTEPW */
	{
		"N3_FSTEPW",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x034D, /* Register address 0 b7:0 */
			0x034E, /* Register address 1 b7:0 */
			0x034F, /* Register address 2 b7:0 */
			0x0350, /* Register address 3 b7:0 */
			0x0351, /* Register address 4 b7:0 */
			0x0352, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N4_FSTEPW */
	{
		"N4_FSTEPW",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		44, /* 44 bits in this setting */
		0, /* setting starts at b0 in first register */
		6, /* contained in 6 registers(s) */
		{
			0x0353, /* Register address 0 b7:0 */
			0x0354, /* Register address 1 b7:0 */
			0x0355, /* Register address 2 b7:0 */
			0x0356, /* Register address 3 b7:0 */
			0x0357, /* Register address 4 b7:0 */
			0x0358, /* Register address 5 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */
			0xFF, /* Register mask 2 */
			0xFF, /* Register mask 3 */
			0xFF, /* Register mask 4 */
			0x0F, /* Register mask 5 */

		}
	},

	/* N0_DELAY */
	{
		"N0_DELAY",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0359, /* Register address 0 b7:0 */
			0x035A, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* N1_DELAY */
	{
		"N1_DELAY",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x035B, /* Register address 0 b7:0 */
			0x035C, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* N2_DELAY */
	{
		"N2_DELAY",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x035D, /* Register address 0 b7:0 */
			0x035E, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* N3_DELAY */
	{
		"N3_DELAY",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x035F, /* Register address 0 b7:0 */
			0x0360, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* N4_DELAY */
	{
		"N4_DELAY",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0361, /* Register address 0 b7:0 */
			0x0362, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSA0 */
	{
		"FIXREGSA0",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0802, /* Register address 0 b7:0 */
			0x0803, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD0 */
	{
		"FIXREGSD0",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0804, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA1 */
	{
		"FIXREGSA1",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0805, /* Register address 0 b7:0 */
			0x0806, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD1 */
	{
		"FIXREGSD1",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0807, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA2 */
	{
		"FIXREGSA2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0808, /* Register address 0 b7:0 */
			0x0809, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD2 */
	{
		"FIXREGSD2",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x080A, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA3 */
	{
		"FIXREGSA3",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x080B, /* Register address 0 b7:0 */
			0x080C, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD3 */
	{
		"FIXREGSD3",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x080D, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA4 */
	{
		"FIXREGSA4",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x080E, /* Register address 0 b7:0 */
			0x080F, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD4 */
	{
		"FIXREGSD4",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0810, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA5 */
	{
		"FIXREGSA5",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0811, /* Register address 0 b7:0 */
			0x0812, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD5 */
	{
		"FIXREGSD5",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0813, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA6 */
	{
		"FIXREGSA6",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0814, /* Register address 0 b7:0 */
			0x0815, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD6 */
	{
		"FIXREGSD6",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0816, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA7 */
	{
		"FIXREGSA7",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0817, /* Register address 0 b7:0 */
			0x0818, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD7 */
	{
		"FIXREGSD7",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0819, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA8 */
	{
		"FIXREGSA8",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x081A, /* Register address 0 b7:0 */
			0x081B, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD8 */
	{
		"FIXREGSD8",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x081C, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA9 */
	{
		"FIXREGSA9",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x081D, /* Register address 0 b7:0 */
			0x081E, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD9 */
	{
		"FIXREGSD9",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x081F, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA10 */
	{
		"FIXREGSA10",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0820, /* Register address 0 b7:0 */
			0x0821, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD10 */
	{
		"FIXREGSD10",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0822, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA11 */
	{
		"FIXREGSA11",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0823, /* Register address 0 b7:0 */
			0x0824, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD11 */
	{
		"FIXREGSD11",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0825, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA12 */
	{
		"FIXREGSA12",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0826, /* Register address 0 b7:0 */
			0x0827, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD12 */
	{
		"FIXREGSD12",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0828, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA13 */
	{
		"FIXREGSA13",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0829, /* Register address 0 b7:0 */
			0x082A, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD13 */
	{
		"FIXREGSD13",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x082B, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA14 */
	{
		"FIXREGSA14",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x082C, /* Register address 0 b7:0 */
			0x082D, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD14 */
	{
		"FIXREGSD14",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x082E, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA15 */
	{
		"FIXREGSA15",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x082F, /* Register address 0 b7:0 */
			0x0830, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD15 */
	{
		"FIXREGSD15",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0831, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA16 */
	{
		"FIXREGSA16",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0832, /* Register address 0 b7:0 */
			0x0833, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD16 */
	{
		"FIXREGSD16",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0834, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA17 */
	{
		"FIXREGSA17",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0835, /* Register address 0 b7:0 */
			0x0836, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD17 */
	{
		"FIXREGSD17",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0837, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA18 */
	{
		"FIXREGSA18",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0838, /* Register address 0 b7:0 */
			0x0839, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD18 */
	{
		"FIXREGSD18",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x083A, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA19 */
	{
		"FIXREGSA19",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x083B, /* Register address 0 b7:0 */
			0x083C, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD19 */
	{
		"FIXREGSD19",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x083D, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA20 */
	{
		"FIXREGSA20",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x083E, /* Register address 0 b7:0 */
			0x083F, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD20 */
	{
		"FIXREGSD20",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0840, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA21 */
	{
		"FIXREGSA21",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0841, /* Register address 0 b7:0 */
			0x0842, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD21 */
	{
		"FIXREGSD21",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0843, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA22 */
	{
		"FIXREGSA22",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0844, /* Register address 0 b7:0 */
			0x0845, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD22 */
	{
		"FIXREGSD22",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0846, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA23 */
	{
		"FIXREGSA23",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0847, /* Register address 0 b7:0 */
			0x0848, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD23 */
	{
		"FIXREGSD23",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0849, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA24 */
	{
		"FIXREGSA24",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x084A, /* Register address 0 b7:0 */
			0x084B, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD24 */
	{
		"FIXREGSD24",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x084C, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA25 */
	{
		"FIXREGSA25",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x084D, /* Register address 0 b7:0 */
			0x084E, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD25 */
	{
		"FIXREGSD25",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x084F, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA26 */
	{
		"FIXREGSA26",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0850, /* Register address 0 b7:0 */
			0x0851, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD26 */
	{
		"FIXREGSD26",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0852, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA27 */
	{
		"FIXREGSA27",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0853, /* Register address 0 b7:0 */
			0x0854, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD27 */
	{
		"FIXREGSD27",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0855, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA28 */
	{
		"FIXREGSA28",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0856, /* Register address 0 b7:0 */
			0x0857, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD28 */
	{
		"FIXREGSD28",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0858, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA29 */
	{
		"FIXREGSA29",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0859, /* Register address 0 b7:0 */
			0x085A, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD29 */
	{
		"FIXREGSD29",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x085B, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA30 */
	{
		"FIXREGSA30",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x085C, /* Register address 0 b7:0 */
			0x085D, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD30 */
	{
		"FIXREGSD30",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x085E, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* FIXREGSA31 */
	{
		"FIXREGSA31",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		16, /* 16 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x085F, /* Register address 0 b7:0 */
			0x0860, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0xFF, /* Register mask 1 */

		}
	},

	/* FIXREGSD31 */
	{
		"FIXREGSD31",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		8, /* 8 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0861, /* Register address 0 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */

		}
	},

	/* XAXB_EXTCLK_EN */
	{
		"XAXB_EXTCLK_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x090E, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* XAXB_PDNB */
	{
		"XAXB_PDNB",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		1, /* setting starts at b1 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x090E, /* Register address 0 b7:0 */

		},
		{
			0x02, /* Register mask 0 */

		}
	},

	/* ZDM_EN */
	{
		"ZDM_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		3, /* 3 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x091C, /* Register address 0 b7:0 */

		},
		{
			0x07, /* Register mask 0 */

		}
	},

	/* IO_VDD_SEL */
	{
		"IO_VDD_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0943, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* IN_EN */
	{
		"IN_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0949, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* IN_PULSED_CMOS_EN */
	{
		"IN_PULSED_CMOS_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0949, /* Register address 0 b7:0 */

		},
		{
			0xF0, /* Register mask 0 */

		}
	},

	/* INX_TO_PFD_EN */
	{
		"INX_TO_PFD_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		4, /* setting starts at b4 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x094A, /* Register address 0 b7:0 */

		},
		{
			0xF0, /* Register mask 0 */

		}
	},

	/* REFCLK_HYS_SEL */
	{
		"REFCLK_HYS_SEL",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		12, /* 12 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x094E, /* Register address 0 b7:0 */
			0x094F, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0x0F, /* Register mask 1 */

		}
	},

	/* M_INTEGER */
	{
		"M_INTEGER",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		1, /* 1 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x095E, /* Register address 0 b7:0 */

		},
		{
			0x01, /* Register mask 0 */

		}
	},

	/* N_ADD_0P5 */
	{
		"N_ADD_0P5",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0A02, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* N_CLK_TO_OUTX_EN */
	{
		"N_CLK_TO_OUTX_EN",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0A03, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* N_PIBYP */
	{
		"N_PIBYP",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0A04, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* N_PDNB */
	{
		"N_PDNB",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0A05, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* PDIV_ENB */
	{
		"PDIV_ENB",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		4, /* 4 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0B44, /* Register address 0 b7:0 */

		},
		{
			0x0F, /* Register mask 0 */

		}
	},

	/* N_CLK_DIS */
	{
		"N_CLK_DIS",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		5, /* 5 bits in this setting */
		0, /* setting starts at b0 in first register */
		1, /* contained in 1 registers(s) */
		{
			0x0B4A, /* Register address 0 b7:0 */

		},
		{
			0x1F, /* Register mask 0 */

		}
	},

	/* VCO_RESET_CALCODE */
	{
		"VCO_RESET_CALCODE",
		0, /* 0 = NOT Read Only */
		0, /* 0 = NOT Self Clearing */
		SLAB_NVMT_CUST, /* Customer NVM Bank */
		12, /* 12 bits in this setting */
		0, /* setting starts at b0 in first register */
		2, /* contained in 2 registers(s) */
		{
			0x0B57, /* Register address 0 b7:0 */
			0x0B58, /* Register address 1 b7:0 */

		},
		{
			0xFF, /* Register mask 0 */
			0x0F, /* Register mask 1 */

		}
	},

};

/* Setting indexes into si5341_revd_settings array */
#define            SI5341_REVD_DIE_REV 0
#define               SI5341_REVD_PAGE 1
#define            SI5341_REVD_PN_BASE 2
#define              SI5341_REVD_GRADE 3
#define         SI5341_REVD_DEVICE_REV 4
#define       SI5341_REVD_TOOL_VERSION 5
#define         SI5341_REVD_TEMP_GRADE 6
#define             SI5341_REVD_PKG_ID 7
#define           SI5341_REVD_I2C_ADDR 8
#define           SI5341_REVD_SYSINCAL 9
#define            SI5341_REVD_LOSXAXB 10
#define             SI5341_REVD_LOSREF 11
#define      SI5341_REVD_SMBUS_TIMEOUT 12
#define                SI5341_REVD_LOL 13
#define              SI5341_REVD_LOSIN 14
#define       SI5341_REVD_SYSINCAL_FLG 15
#define        SI5341_REVD_LOSXAXB_FLG 16
#define         SI5341_REVD_LOSREF_FLG 17
#define            SI5341_REVD_LOL_FLG 18
#define  SI5341_REVD_SMBUS_TIMEOUT_FLG 19
#define          SI5341_REVD_LOSIN_FLG 20
#define  SI5341_REVD_SYSINCAL_INTR_MSK 21
#define   SI5341_REVD_LOSXAXB_INTR_MSK 22
#define    SI5341_REVD_LOSREF_INTR_MSK 23
#define       SI5341_REVD_LOL_INTR_MSK 24
#define SI5341_REVD_SMB_TMOUT_INTR_MSK 25
#define     SI5341_REVD_LOSIN_INTR_MSK 26
#define           SI5341_REVD_SOFT_RST 27
#define            SI5341_REVD_SOFTCAL 28
#define               SI5341_REVD_FINC 29
#define               SI5341_REVD_FDEC 30
#define                SI5341_REVD_PDN 31
#define           SI5341_REVD_HARD_RST 32
#define               SI5341_REVD_SYNC 33
#define     SI5341_REVD_IN_SEL_REGCTRL 34
#define             SI5341_REVD_IN_SEL 35
#define                 SI5341_REVD_OE 36
#define          SI5341_REVD_SPI_3WIRE 37
#define   SI5341_REVD_AUTO_NDIV_UPDATE 38
#define             SI5341_REVD_LOS_EN 39
#define        SI5341_REVD_LOSXAXB_DIS 40
#define      SI5341_REVD_LOS0_VAL_TIME 41
#define      SI5341_REVD_LOS1_VAL_TIME 42
#define      SI5341_REVD_LOS2_VAL_TIME 43
#define      SI5341_REVD_LOS3_VAL_TIME 44
#define       SI5341_REVD_LOS0_TRG_THR 45
#define       SI5341_REVD_LOS1_TRG_THR 46
#define       SI5341_REVD_LOS2_TRG_THR 47
#define       SI5341_REVD_LOS3_TRG_THR 48
#define       SI5341_REVD_LOS0_CLR_THR 49
#define       SI5341_REVD_LOS1_CLR_THR 50
#define       SI5341_REVD_LOS2_CLR_THR 51
#define       SI5341_REVD_LOS3_CLR_THR 52
#define       SI5341_REVD_LOS0_DIV_SEL 53
#define       SI5341_REVD_LOS1_DIV_SEL 54
#define       SI5341_REVD_LOS2_DIV_SEL 55
#define       SI5341_REVD_LOS3_DIV_SEL 56
#define        SI5341_REVD_LOL_SET_THR 57
#define    SI5341_REVD_ACTIVE_NVM_BANK 58
#define      SI5341_REVD_REG_0XF7_INTR 59
#define      SI5341_REVD_REG_0XF8_INTR 60
#define      SI5341_REVD_SYSINCAL_INTR 61
#define       SI5341_REVD_LOSXAXB_INTR 62
#define        SI5341_REVD_LOSREF_INTR 63
#define        SI5341_REVD_LOSVCO_INTR 64
#define           SI5341_REVD_LOL_INTR 65
#define SI5341_REVD_SMBUS_TIME_OUT_INTR 66
#define           SI5341_REVD_LOS_INTR 67
#define SI5341_REVD_OUTALL_DISABLE_LOW 68
#define           SI5341_REVD_OUT0_PDN 69
#define            SI5341_REVD_OUT0_OE 70
#define   SI5341_REVD_OUT0_RDIV_FORCE2 71
#define        SI5341_REVD_OUT0_FORMAT 72
#define       SI5341_REVD_OUT0_SYNC_EN 73
#define     SI5341_REVD_OUT0_DIS_STATE 74
#define      SI5341_REVD_OUT0_CMOS_DRV 75
#define            SI5341_REVD_OUT0_CM 76
#define          SI5341_REVD_OUT0_AMPL 77
#define       SI5341_REVD_OUT0_MUX_SEL 78
#define       SI5341_REVD_OUT0_VDD_SEL 79
#define    SI5341_REVD_OUT0_VDD_SEL_EN 80
#define           SI5341_REVD_OUT0_INV 81
#define           SI5341_REVD_OUT1_PDN 82
#define            SI5341_REVD_OUT1_OE 83
#define   SI5341_REVD_OUT1_RDIV_FORCE2 84
#define        SI5341_REVD_OUT1_FORMAT 85
#define       SI5341_REVD_OUT1_SYNC_EN 86
#define     SI5341_REVD_OUT1_DIS_STATE 87
#define      SI5341_REVD_OUT1_CMOS_DRV 88
#define            SI5341_REVD_OUT1_CM 89
#define          SI5341_REVD_OUT1_AMPL 90
#define       SI5341_REVD_OUT1_MUX_SEL 91
#define       SI5341_REVD_OUT1_VDD_SEL 92
#define    SI5341_REVD_OUT1_VDD_SEL_EN 93
#define           SI5341_REVD_OUT1_INV 94
#define           SI5341_REVD_OUT2_PDN 95
#define            SI5341_REVD_OUT2_OE 96
#define   SI5341_REVD_OUT2_RDIV_FORCE2 97
#define        SI5341_REVD_OUT2_FORMAT 98
#define       SI5341_REVD_OUT2_SYNC_EN 99
#define     SI5341_REVD_OUT2_DIS_STATE 100
#define      SI5341_REVD_OUT2_CMOS_DRV 101
#define            SI5341_REVD_OUT2_CM 102
#define          SI5341_REVD_OUT2_AMPL 103
#define       SI5341_REVD_OUT2_MUX_SEL 104
#define       SI5341_REVD_OUT2_VDD_SEL 105
#define    SI5341_REVD_OUT2_VDD_SEL_EN 106
#define           SI5341_REVD_OUT2_INV 107
#define           SI5341_REVD_OUT3_PDN 108
#define            SI5341_REVD_OUT3_OE 109
#define   SI5341_REVD_OUT3_RDIV_FORCE2 110
#define        SI5341_REVD_OUT3_FORMAT 111
#define       SI5341_REVD_OUT3_SYNC_EN 112
#define     SI5341_REVD_OUT3_DIS_STATE 113
#define      SI5341_REVD_OUT3_CMOS_DRV 114
#define            SI5341_REVD_OUT3_CM 115
#define          SI5341_REVD_OUT3_AMPL 116
#define       SI5341_REVD_OUT3_MUX_SEL 117
#define       SI5341_REVD_OUT3_VDD_SEL 118
#define    SI5341_REVD_OUT3_VDD_SEL_EN 119
#define           SI5341_REVD_OUT3_INV 120
#define           SI5341_REVD_OUT4_PDN 121
#define            SI5341_REVD_OUT4_OE 122
#define   SI5341_REVD_OUT4_RDIV_FORCE2 123
#define        SI5341_REVD_OUT4_FORMAT 124
#define       SI5341_REVD_OUT4_SYNC_EN 125
#define     SI5341_REVD_OUT4_DIS_STATE 126
#define      SI5341_REVD_OUT4_CMOS_DRV 127
#define            SI5341_REVD_OUT4_CM 128
#define          SI5341_REVD_OUT4_AMPL 129
#define       SI5341_REVD_OUT4_MUX_SEL 130
#define       SI5341_REVD_OUT4_VDD_SEL 131
#define    SI5341_REVD_OUT4_VDD_SEL_EN 132
#define           SI5341_REVD_OUT4_INV 133
#define           SI5341_REVD_OUT5_PDN 134
#define            SI5341_REVD_OUT5_OE 135
#define   SI5341_REVD_OUT5_RDIV_FORCE2 136
#define        SI5341_REVD_OUT5_FORMAT 137
#define       SI5341_REVD_OUT5_SYNC_EN 138
#define     SI5341_REVD_OUT5_DIS_STATE 139
#define      SI5341_REVD_OUT5_CMOS_DRV 140
#define            SI5341_REVD_OUT5_CM 141
#define          SI5341_REVD_OUT5_AMPL 142
#define       SI5341_REVD_OUT5_MUX_SEL 143
#define       SI5341_REVD_OUT5_VDD_SEL 144
#define    SI5341_REVD_OUT5_VDD_SEL_EN 145
#define           SI5341_REVD_OUT5_INV 146
#define           SI5341_REVD_OUT6_PDN 147
#define            SI5341_REVD_OUT6_OE 148
#define   SI5341_REVD_OUT6_RDIV_FORCE2 149
#define        SI5341_REVD_OUT6_FORMAT 150
#define       SI5341_REVD_OUT6_SYNC_EN 151
#define     SI5341_REVD_OUT6_DIS_STATE 152
#define      SI5341_REVD_OUT6_CMOS_DRV 153
#define            SI5341_REVD_OUT6_CM 154
#define          SI5341_REVD_OUT6_AMPL 155
#define       SI5341_REVD_OUT6_MUX_SEL 156
#define       SI5341_REVD_OUT6_VDD_SEL 157
#define    SI5341_REVD_OUT6_VDD_SEL_EN 158
#define           SI5341_REVD_OUT6_INV 159
#define           SI5341_REVD_OUT7_PDN 160
#define            SI5341_REVD_OUT7_OE 161
#define   SI5341_REVD_OUT7_RDIV_FORCE2 162
#define        SI5341_REVD_OUT7_FORMAT 163
#define       SI5341_REVD_OUT7_SYNC_EN 164
#define     SI5341_REVD_OUT7_DIS_STATE 165
#define      SI5341_REVD_OUT7_CMOS_DRV 166
#define            SI5341_REVD_OUT7_CM 167
#define          SI5341_REVD_OUT7_AMPL 168
#define       SI5341_REVD_OUT7_MUX_SEL 169
#define       SI5341_REVD_OUT7_VDD_SEL 170
#define    SI5341_REVD_OUT7_VDD_SEL_EN 171
#define           SI5341_REVD_OUT7_INV 172
#define           SI5341_REVD_OUT8_PDN 173
#define            SI5341_REVD_OUT8_OE 174
#define   SI5341_REVD_OUT8_RDIV_FORCE2 175
#define        SI5341_REVD_OUT8_FORMAT 176
#define       SI5341_REVD_OUT8_SYNC_EN 177
#define     SI5341_REVD_OUT8_DIS_STATE 178
#define      SI5341_REVD_OUT8_CMOS_DRV 179
#define            SI5341_REVD_OUT8_CM 180
#define          SI5341_REVD_OUT8_AMPL 181
#define       SI5341_REVD_OUT8_MUX_SEL 182
#define       SI5341_REVD_OUT8_VDD_SEL 183
#define    SI5341_REVD_OUT8_VDD_SEL_EN 184
#define           SI5341_REVD_OUT8_INV 185
#define           SI5341_REVD_OUT9_PDN 186
#define            SI5341_REVD_OUT9_OE 187
#define   SI5341_REVD_OUT9_RDIV_FORCE2 188
#define        SI5341_REVD_OUT9_FORMAT 189
#define       SI5341_REVD_OUT9_SYNC_EN 190
#define     SI5341_REVD_OUT9_DIS_STATE 191
#define      SI5341_REVD_OUT9_CMOS_DRV 192
#define            SI5341_REVD_OUT9_CM 193
#define          SI5341_REVD_OUT9_AMPL 194
#define       SI5341_REVD_OUT9_MUX_SEL 195
#define       SI5341_REVD_OUT9_VDD_SEL 196
#define    SI5341_REVD_OUT9_VDD_SEL_EN 197
#define           SI5341_REVD_OUT9_INV 198
#define     SI5341_REVD_OUTX_ALWAYS_ON 199
#define    SI5341_REVD_OUT_DIS_LOL_MSK 200
#define SI5341_REVD_OUT_DIS_MSK_LOS_PFD 201
#define        SI5341_REVD_OUT_PDN_ALL 202
#define              SI5341_REVD_PXAXB 203
#define                 SI5341_REVD_P0 204
#define             SI5341_REVD_P0_SET 205
#define                 SI5341_REVD_P1 206
#define             SI5341_REVD_P1_SET 207
#define                 SI5341_REVD_P2 208
#define             SI5341_REVD_P2_SET 209
#define                 SI5341_REVD_P3 210
#define             SI5341_REVD_P3_SET 211
#define          SI5341_REVD_P0_UPDATE 212
#define          SI5341_REVD_P1_UPDATE 213
#define          SI5341_REVD_P2_UPDATE 214
#define          SI5341_REVD_P3_UPDATE 215
#define              SI5341_REVD_M_NUM 216
#define              SI5341_REVD_M_DEN 217
#define           SI5341_REVD_M_UPDATE 218
#define             SI5341_REVD_R0_REG 219
#define             SI5341_REVD_R1_REG 220
#define             SI5341_REVD_R2_REG 221
#define             SI5341_REVD_R3_REG 222
#define             SI5341_REVD_R4_REG 223
#define             SI5341_REVD_R5_REG 224
#define             SI5341_REVD_R6_REG 225
#define             SI5341_REVD_R7_REG 226
#define             SI5341_REVD_R8_REG 227
#define             SI5341_REVD_R9_REG 228
#define         SI5341_REVD_DESIGN_ID0 229
#define         SI5341_REVD_DESIGN_ID1 230
#define         SI5341_REVD_DESIGN_ID2 231
#define         SI5341_REVD_DESIGN_ID3 232
#define         SI5341_REVD_DESIGN_ID4 233
#define         SI5341_REVD_DESIGN_ID5 234
#define         SI5341_REVD_DESIGN_ID6 235
#define         SI5341_REVD_DESIGN_ID7 236
#define            SI5341_REVD_OPN_ID0 237
#define            SI5341_REVD_OPN_ID1 238
#define            SI5341_REVD_OPN_ID2 239
#define            SI5341_REVD_OPN_ID3 240
#define            SI5341_REVD_OPN_ID4 241
#define       SI5341_REVD_OPN_REVISION 242
#define        SI5341_REVD_BASELINE_ID 243
#define             SI5341_REVD_N0_NUM 244
#define             SI5341_REVD_N0_DEN 245
#define          SI5341_REVD_N0_UPDATE 246
#define             SI5341_REVD_N1_NUM 247
#define             SI5341_REVD_N1_DEN 248
#define          SI5341_REVD_N1_UPDATE 249
#define             SI5341_REVD_N2_NUM 250
#define             SI5341_REVD_N2_DEN 251
#define          SI5341_REVD_N2_UPDATE 252
#define             SI5341_REVD_N3_NUM 253
#define             SI5341_REVD_N3_DEN 254
#define          SI5341_REVD_N3_UPDATE 255
#define             SI5341_REVD_N4_NUM 256
#define             SI5341_REVD_N4_DEN 257
#define          SI5341_REVD_N4_UPDATE 258
#define           SI5341_REVD_N_UPDATE 259
#define        SI5341_REVD_N_FSTEP_MSK 260
#define          SI5341_REVD_N0_FSTEPW 261
#define          SI5341_REVD_N1_FSTEPW 262
#define          SI5341_REVD_N2_FSTEPW 263
#define          SI5341_REVD_N3_FSTEPW 264
#define          SI5341_REVD_N4_FSTEPW 265
#define           SI5341_REVD_N0_DELAY 266
#define           SI5341_REVD_N1_DELAY 267
#define           SI5341_REVD_N2_DELAY 268
#define           SI5341_REVD_N3_DELAY 269
#define           SI5341_REVD_N4_DELAY 270
#define          SI5341_REVD_FIXREGSA0 271
#define          SI5341_REVD_FIXREGSD0 272
#define          SI5341_REVD_FIXREGSA1 273
#define          SI5341_REVD_FIXREGSD1 274
#define          SI5341_REVD_FIXREGSA2 275
#define          SI5341_REVD_FIXREGSD2 276
#define          SI5341_REVD_FIXREGSA3 277
#define          SI5341_REVD_FIXREGSD3 278
#define          SI5341_REVD_FIXREGSA4 279
#define          SI5341_REVD_FIXREGSD4 280
#define          SI5341_REVD_FIXREGSA5 281
#define          SI5341_REVD_FIXREGSD5 282
#define          SI5341_REVD_FIXREGSA6 283
#define          SI5341_REVD_FIXREGSD6 284
#define          SI5341_REVD_FIXREGSA7 285
#define          SI5341_REVD_FIXREGSD7 286
#define          SI5341_REVD_FIXREGSA8 287
#define          SI5341_REVD_FIXREGSD8 288
#define          SI5341_REVD_FIXREGSA9 289
#define          SI5341_REVD_FIXREGSD9 290
#define         SI5341_REVD_FIXREGSA10 291
#define         SI5341_REVD_FIXREGSD10 292
#define         SI5341_REVD_FIXREGSA11 293
#define         SI5341_REVD_FIXREGSD11 294
#define         SI5341_REVD_FIXREGSA12 295
#define         SI5341_REVD_FIXREGSD12 296
#define         SI5341_REVD_FIXREGSA13 297
#define         SI5341_REVD_FIXREGSD13 298
#define         SI5341_REVD_FIXREGSA14 299
#define         SI5341_REVD_FIXREGSD14 300
#define         SI5341_REVD_FIXREGSA15 301
#define         SI5341_REVD_FIXREGSD15 302
#define         SI5341_REVD_FIXREGSA16 303
#define         SI5341_REVD_FIXREGSD16 304
#define         SI5341_REVD_FIXREGSA17 305
#define         SI5341_REVD_FIXREGSD17 306
#define         SI5341_REVD_FIXREGSA18 307
#define         SI5341_REVD_FIXREGSD18 308
#define         SI5341_REVD_FIXREGSA19 309
#define         SI5341_REVD_FIXREGSD19 310
#define         SI5341_REVD_FIXREGSA20 311
#define         SI5341_REVD_FIXREGSD20 312
#define         SI5341_REVD_FIXREGSA21 313
#define         SI5341_REVD_FIXREGSD21 314
#define         SI5341_REVD_FIXREGSA22 315
#define         SI5341_REVD_FIXREGSD22 316
#define         SI5341_REVD_FIXREGSA23 317
#define         SI5341_REVD_FIXREGSD23 318
#define         SI5341_REVD_FIXREGSA24 319
#define         SI5341_REVD_FIXREGSD24 320
#define         SI5341_REVD_FIXREGSA25 321
#define         SI5341_REVD_FIXREGSD25 322
#define         SI5341_REVD_FIXREGSA26 323
#define         SI5341_REVD_FIXREGSD26 324
#define         SI5341_REVD_FIXREGSA27 325
#define         SI5341_REVD_FIXREGSD27 326
#define         SI5341_REVD_FIXREGSA28 327
#define         SI5341_REVD_FIXREGSD28 328
#define         SI5341_REVD_FIXREGSA29 329
#define         SI5341_REVD_FIXREGSD29 330
#define         SI5341_REVD_FIXREGSA30 331
#define         SI5341_REVD_FIXREGSD30 332
#define         SI5341_REVD_FIXREGSA31 333
#define         SI5341_REVD_FIXREGSD31 334
#define     SI5341_REVD_XAXB_EXTCLK_EN 335
#define          SI5341_REVD_XAXB_PDNB 336
#define             SI5341_REVD_ZDM_EN 337
#define         SI5341_REVD_IO_VDD_SEL 338
#define              SI5341_REVD_IN_EN 339
#define  SI5341_REVD_IN_PULSED_CMOS_EN 340
#define      SI5341_REVD_INX_TO_PFD_EN 341
#define     SI5341_REVD_REFCLK_HYS_SEL 342
#define          SI5341_REVD_M_INTEGER 343
#define          SI5341_REVD_N_ADD_0P5 344
#define   SI5341_REVD_N_CLK_TO_OUTX_EN 345
#define            SI5341_REVD_N_PIBYP 346
#define             SI5341_REVD_N_PDNB 347
#define           SI5341_REVD_PDIV_ENB 348
#define          SI5341_REVD_N_CLK_DIS 349
#define  SI5341_REVD_VCO_RESET_CALCODE 350
/*
 * Regmap Report Corresponding to Above
 *
 * Setting Name         Location      Start Address  Start Bit  Num Bits  NVM    Type
 * -------------------  ------------  -------------  ---------  --------  -----  ----
 * DIE_REV              0x0000[3:0]   0x0000         0          4         None   R/O 
 * PAGE                 0x0001[7:0]   0x0001         0          8         None   R/W 
 * PN_BASE              0x0002[15:0]  0x0002         0          16        SiLab  R/O 
 * GRADE                0x0004[7:0]   0x0004         0          8         User   R/O 
 * DEVICE_REV           0x0005[7:0]   0x0005         0          8         SiLab  R/O 
 * TOOL_VERSION         0x0006[23:0]  0x0006         0          24        User   R/O 
 * TEMP_GRADE           0x0009[7:0]   0x0009         0          8         SiLab  R/O 
 * PKG_ID               0x000A[7:0]   0x000A         0          8         SiLab  R/O 
 * I2C_ADDR             0x000B[6:0]   0x000B         0          7         SiLab  R/W 
 * SMBUS_TIMEOUT        0x000C[5]     0x000C         5          1         None   R/O 
 * LOL                  0x000C[3]     0x000C         3          1         None   R/O 
 * LOSREF               0x000C[2]     0x000C         2          1         None   R/O 
 * LOSXAXB              0x000C[1]     0x000C         1          1         None   R/O 
 * SYSINCAL             0x000C[0]     0x000C         0          1         None   R/O 
 * LOSIN                0x000D[3:0]   0x000D         0          4         None   R/O 
 * SMBUS_TIMEOUT_FLG    0x0011[5]     0x0011         5          1         None   R/W 
 * LOL_FLG              0x0011[3]     0x0011         3          1         None   R/W 
 * LOSREF_FLG           0x0011[2]     0x0011         2          1         None   R/W 
 * LOSXAXB_FLG          0x0011[1]     0x0011         1          1         None   R/W 
 * SYSINCAL_FLG         0x0011[0]     0x0011         0          1         None   R/W 
 * LOSIN_FLG            0x0012[3:0]   0x0012         0          4         None   R/W 
 * SMB_TMOUT_INTR_MSK   0x0017[5]     0x0017         5          1         User   R/W 
 * LOL_INTR_MSK         0x0017[3]     0x0017         3          1         User   R/W 
 * LOSREF_INTR_MSK      0x0017[2]     0x0017         2          1         User   R/W 
 * LOSXAXB_INTR_MSK     0x0017[1]     0x0017         1          1         User   R/W 
 * SYSINCAL_INTR_MSK    0x0017[0]     0x0017         0          1         User   R/W 
 * LOSIN_INTR_MSK       0x0018[3:0]   0x0018         0          4         User   R/W 
 * SOFTCAL              0x001C[5]     0x001C         5          1         None   S/C 
 * SOFT_RST             0x001C[0]     0x001C         0          1         None   S/C 
 * FDEC                 0x001D[1]     0x001D         1          1         None   S/C 
 * FINC                 0x001D[0]     0x001D         0          1         None   S/C 
 * SYNC                 0x001E[2]     0x001E         2          1         None   S/C 
 * HARD_RST             0x001E[1]     0x001E         1          1         None   R/W 
 * PDN                  0x001E[0]     0x001E         0          1         None   R/W 
 * IN_SEL               0x0021[2:1]   0x0021         1          2         User   R/W 
 * IN_SEL_REGCTRL       0x0021[0]     0x0021         0          1         User   R/W 
 * OE                   0x0022[1]     0x0022         1          1         User   R/W 
 * AUTO_NDIV_UPDATE     0x002B[5]     0x002B         5          1         User   R/W 
 * SPI_3WIRE            0x002B[3]     0x002B         3          1         User   R/W 
 * LOSXAXB_DIS          0x002C[4]     0x002C         4          1         User   R/W 
 * LOS_EN               0x002C[3:0]   0x002C         0          4         User   R/W 
 * LOS3_VAL_TIME        0x002D[7:6]   0x002D         6          2         User   R/W 
 * LOS2_VAL_TIME        0x002D[5:4]   0x002D         4          2         User   R/W 
 * LOS1_VAL_TIME        0x002D[3:2]   0x002D         2          2         User   R/W 
 * LOS0_VAL_TIME        0x002D[1:0]   0x002D         0          2         User   R/W 
 * LOS0_TRG_THR         0x002E[15:0]  0x002E         0          16        User   R/W 
 * LOS1_TRG_THR         0x0030[15:0]  0x0030         0          16        User   R/W 
 * LOS2_TRG_THR         0x0032[15:0]  0x0032         0          16        User   R/W 
 * LOS3_TRG_THR         0x0034[15:0]  0x0034         0          16        User   R/W 
 * LOS0_CLR_THR         0x0036[15:0]  0x0036         0          16        User   R/W 
 * LOS1_CLR_THR         0x0038[15:0]  0x0038         0          16        User   R/W 
 * LOS2_CLR_THR         0x003A[15:0]  0x003A         0          16        User   R/W 
 * LOS3_CLR_THR         0x003C[15:0]  0x003C         0          16        User   R/W 
 * LOS0_DIV_SEL         0x0041[4:0]   0x0041         0          5         User   R/W 
 * LOS1_DIV_SEL         0x0042[4:0]   0x0042         0          5         User   R/W 
 * LOS2_DIV_SEL         0x0043[4:0]   0x0043         0          5         User   R/W 
 * LOS3_DIV_SEL         0x0044[4:0]   0x0044         0          5         User   R/W 
 * LOL_SET_THR          0x009E[7:4]   0x009E         4          4         User   R/W 
 * ACTIVE_NVM_BANK      0x00E2[7:0]   0x00E2         0          8         None   R/O 
 * REG_0XF8_INTR        0x00F6[1]     0x00F6         1          1         None   R/O 
 * REG_0XF7_INTR        0x00F6[0]     0x00F6         0          1         None   R/O 
 * SMBUS_TIME_OUT_INTR  0x00F7[5]     0x00F7         5          1         None   R/O 
 * LOSVCO_INTR          0x00F7[4]     0x00F7         4          1         None   R/O 
 * LOL_INTR             0x00F7[3]     0x00F7         3          1         None   R/O 
 * LOSREF_INTR          0x00F7[2]     0x00F7         2          1         None   R/O 
 * LOSXAXB_INTR         0x00F7[1]     0x00F7         1          1         None   R/O 
 * SYSINCAL_INTR        0x00F7[0]     0x00F7         0          1         None   R/O 
 * LOS_INTR             0x00F8[3:0]   0x00F8         0          4         None   R/O 
 * OUTALL_DISABLE_LOW   0x0102[0]     0x0102         0          1         User   R/W 
 * OUT0_RDIV_FORCE2     0x0108[2]     0x0108         2          1         User   R/W 
 * OUT0_OE              0x0108[1]     0x0108         1          1         User   R/W 
 * OUT0_PDN             0x0108[0]     0x0108         0          1         User   R/W 
 * OUT0_CMOS_DRV        0x0109[7:6]   0x0109         6          2         User   R/W 
 * OUT0_DIS_STATE       0x0109[5:4]   0x0109         4          2         User   R/W 
 * OUT0_SYNC_EN         0x0109[3]     0x0109         3          1         User   R/W 
 * OUT0_FORMAT          0x0109[2:0]   0x0109         0          3         User   R/W 
 * OUT0_AMPL            0x010A[6:4]   0x010A         4          3         User   R/W 
 * OUT0_CM              0x010A[3:0]   0x010A         0          4         User   R/W 
 * OUT0_INV             0x010B[7:6]   0x010B         6          2         User   R/W 
 * OUT0_VDD_SEL         0x010B[5:4]   0x010B         4          2         User   R/W 
 * OUT0_VDD_SEL_EN      0x010B[3]     0x010B         3          1         User   R/W 
 * OUT0_MUX_SEL         0x010B[2:0]   0x010B         0          3         User   R/W 
 * OUT1_RDIV_FORCE2     0x010D[2]     0x010D         2          1         User   R/W 
 * OUT1_OE              0x010D[1]     0x010D         1          1         User   R/W 
 * OUT1_PDN             0x010D[0]     0x010D         0          1         User   R/W 
 * OUT1_CMOS_DRV        0x010E[7:6]   0x010E         6          2         User   R/W 
 * OUT1_DIS_STATE       0x010E[5:4]   0x010E         4          2         User   R/W 
 * OUT1_SYNC_EN         0x010E[3]     0x010E         3          1         User   R/W 
 * OUT1_FORMAT          0x010E[2:0]   0x010E         0          3         User   R/W 
 * OUT1_AMPL            0x010F[6:4]   0x010F         4          3         User   R/W 
 * OUT1_CM              0x010F[3:0]   0x010F         0          4         User   R/W 
 * OUT1_INV             0x0110[7:6]   0x0110         6          2         User   R/W 
 * OUT1_VDD_SEL         0x0110[5:4]   0x0110         4          2         User   R/W 
 * OUT1_VDD_SEL_EN      0x0110[3]     0x0110         3          1         User   R/W 
 * OUT1_MUX_SEL         0x0110[2:0]   0x0110         0          3         User   R/W 
 * OUT2_RDIV_FORCE2     0x0112[2]     0x0112         2          1         User   R/W 
 * OUT2_OE              0x0112[1]     0x0112         1          1         User   R/W 
 * OUT2_PDN             0x0112[0]     0x0112         0          1         User   R/W 
 * OUT2_CMOS_DRV        0x0113[7:6]   0x0113         6          2         User   R/W 
 * OUT2_DIS_STATE       0x0113[5:4]   0x0113         4          2         User   R/W 
 * OUT2_SYNC_EN         0x0113[3]     0x0113         3          1         User   R/W 
 * OUT2_FORMAT          0x0113[2:0]   0x0113         0          3         User   R/W 
 * OUT2_AMPL            0x0114[6:4]   0x0114         4          3         User   R/W 
 * OUT2_CM              0x0114[3:0]   0x0114         0          4         User   R/W 
 * OUT2_INV             0x0115[7:6]   0x0115         6          2         User   R/W 
 * OUT2_VDD_SEL         0x0115[5:4]   0x0115         4          2         User   R/W 
 * OUT2_VDD_SEL_EN      0x0115[3]     0x0115         3          1         User   R/W 
 * OUT2_MUX_SEL         0x0115[2:0]   0x0115         0          3         User   R/W 
 * OUT3_RDIV_FORCE2     0x0117[2]     0x0117         2          1         User   R/W 
 * OUT3_OE              0x0117[1]     0x0117         1          1         User   R/W 
 * OUT3_PDN             0x0117[0]     0x0117         0          1         User   R/W 
 * OUT3_CMOS_DRV        0x0118[7:6]   0x0118         6          2         User   R/W 
 * OUT3_DIS_STATE       0x0118[5:4]   0x0118         4          2         User   R/W 
 * OUT3_SYNC_EN         0x0118[3]     0x0118         3          1         User   R/W 
 * OUT3_FORMAT          0x0118[2:0]   0x0118         0          3         User   R/W 
 * OUT3_AMPL            0x0119[6:4]   0x0119         4          3         User   R/W 
 * OUT3_CM              0x0119[3:0]   0x0119         0          4         User   R/W 
 * OUT3_INV             0x011A[7:6]   0x011A         6          2         User   R/W 
 * OUT3_VDD_SEL         0x011A[5:4]   0x011A         4          2         User   R/W 
 * OUT3_VDD_SEL_EN      0x011A[3]     0x011A         3          1         User   R/W 
 * OUT3_MUX_SEL         0x011A[2:0]   0x011A         0          3         User   R/W 
 * OUT4_RDIV_FORCE2     0x011C[2]     0x011C         2          1         User   R/W 
 * OUT4_OE              0x011C[1]     0x011C         1          1         User   R/W 
 * OUT4_PDN             0x011C[0]     0x011C         0          1         User   R/W 
 * OUT4_CMOS_DRV        0x011D[7:6]   0x011D         6          2         User   R/W 
 * OUT4_DIS_STATE       0x011D[5:4]   0x011D         4          2         User   R/W 
 * OUT4_SYNC_EN         0x011D[3]     0x011D         3          1         User   R/W 
 * OUT4_FORMAT          0x011D[2:0]   0x011D         0          3         User   R/W 
 * OUT4_AMPL            0x011E[6:4]   0x011E         4          3         User   R/W 
 * OUT4_CM              0x011E[3:0]   0x011E         0          4         User   R/W 
 * OUT4_INV             0x011F[7:6]   0x011F         6          2         User   R/W 
 * OUT4_VDD_SEL         0x011F[5:4]   0x011F         4          2         User   R/W 
 * OUT4_VDD_SEL_EN      0x011F[3]     0x011F         3          1         User   R/W 
 * OUT4_MUX_SEL         0x011F[2:0]   0x011F         0          3         User   R/W 
 * OUT5_RDIV_FORCE2     0x0121[2]     0x0121         2          1         User   R/W 
 * OUT5_OE              0x0121[1]     0x0121         1          1         User   R/W 
 * OUT5_PDN             0x0121[0]     0x0121         0          1         User   R/W 
 * OUT5_CMOS_DRV        0x0122[7:6]   0x0122         6          2         User   R/W 
 * OUT5_DIS_STATE       0x0122[5:4]   0x0122         4          2         User   R/W 
 * OUT5_SYNC_EN         0x0122[3]     0x0122         3          1         User   R/W 
 * OUT5_FORMAT          0x0122[2:0]   0x0122         0          3         User   R/W 
 * OUT5_AMPL            0x0123[6:4]   0x0123         4          3         User   R/W 
 * OUT5_CM              0x0123[3:0]   0x0123         0          4         User   R/W 
 * OUT5_INV             0x0124[7:6]   0x0124         6          2         User   R/W 
 * OUT5_VDD_SEL         0x0124[5:4]   0x0124         4          2         User   R/W 
 * OUT5_VDD_SEL_EN      0x0124[3]     0x0124         3          1         User   R/W 
 * OUT5_MUX_SEL         0x0124[2:0]   0x0124         0          3         User   R/W 
 * OUT6_RDIV_FORCE2     0x0126[2]     0x0126         2          1         User   R/W 
 * OUT6_OE              0x0126[1]     0x0126         1          1         User   R/W 
 * OUT6_PDN             0x0126[0]     0x0126         0          1         User   R/W 
 * OUT6_CMOS_DRV        0x0127[7:6]   0x0127         6          2         User   R/W 
 * OUT6_DIS_STATE       0x0127[5:4]   0x0127         4          2         User   R/W 
 * OUT6_SYNC_EN         0x0127[3]     0x0127         3          1         User   R/W 
 * OUT6_FORMAT          0x0127[2:0]   0x0127         0          3         User   R/W 
 * OUT6_AMPL            0x0128[6:4]   0x0128         4          3         User   R/W 
 * OUT6_CM              0x0128[3:0]   0x0128         0          4         User   R/W 
 * OUT6_INV             0x0129[7:6]   0x0129         6          2         User   R/W 
 * OUT6_VDD_SEL         0x0129[5:4]   0x0129         4          2         User   R/W 
 * OUT6_VDD_SEL_EN      0x0129[3]     0x0129         3          1         User   R/W 
 * OUT6_MUX_SEL         0x0129[2:0]   0x0129         0          3         User   R/W 
 * OUT7_RDIV_FORCE2     0x012B[2]     0x012B         2          1         User   R/W 
 * OUT7_OE              0x012B[1]     0x012B         1          1         User   R/W 
 * OUT7_PDN             0x012B[0]     0x012B         0          1         User   R/W 
 * OUT7_CMOS_DRV        0x012C[7:6]   0x012C         6          2         User   R/W 
 * OUT7_DIS_STATE       0x012C[5:4]   0x012C         4          2         User   R/W 
 * OUT7_SYNC_EN         0x012C[3]     0x012C         3          1         User   R/W 
 * OUT7_FORMAT          0x012C[2:0]   0x012C         0          3         User   R/W 
 * OUT7_AMPL            0x012D[6:4]   0x012D         4          3         User   R/W 
 * OUT7_CM              0x012D[3:0]   0x012D         0          4         User   R/W 
 * OUT7_INV             0x012E[7:6]   0x012E         6          2         User   R/W 
 * OUT7_VDD_SEL         0x012E[5:4]   0x012E         4          2         User   R/W 
 * OUT7_VDD_SEL_EN      0x012E[3]     0x012E         3          1         User   R/W 
 * OUT7_MUX_SEL         0x012E[2:0]   0x012E         0          3         User   R/W 
 * OUT8_RDIV_FORCE2     0x0130[2]     0x0130         2          1         User   R/W 
 * OUT8_OE              0x0130[1]     0x0130         1          1         User   R/W 
 * OUT8_PDN             0x0130[0]     0x0130         0          1         User   R/W 
 * OUT8_CMOS_DRV        0x0131[7:6]   0x0131         6          2         User   R/W 
 * OUT8_DIS_STATE       0x0131[5:4]   0x0131         4          2         User   R/W 
 * OUT8_SYNC_EN         0x0131[3]     0x0131         3          1         User   R/W 
 * OUT8_FORMAT          0x0131[2:0]   0x0131         0          3         User   R/W 
 * OUT8_AMPL            0x0132[6:4]   0x0132         4          3         User   R/W 
 * OUT8_CM              0x0132[3:0]   0x0132         0          4         User   R/W 
 * OUT8_INV             0x0133[7:6]   0x0133         6          2         User   R/W 
 * OUT8_VDD_SEL         0x0133[5:4]   0x0133         4          2         User   R/W 
 * OUT8_VDD_SEL_EN      0x0133[3]     0x0133         3          1         User   R/W 
 * OUT8_MUX_SEL         0x0133[2:0]   0x0133         0          3         User   R/W 
 * OUT9_RDIV_FORCE2     0x013A[2]     0x013A         2          1         User   R/W 
 * OUT9_OE              0x013A[1]     0x013A         1          1         User   R/W 
 * OUT9_PDN             0x013A[0]     0x013A         0          1         User   R/W 
 * OUT9_CMOS_DRV        0x013B[7:6]   0x013B         6          2         User   R/W 
 * OUT9_DIS_STATE       0x013B[5:4]   0x013B         4          2         User   R/W 
 * OUT9_SYNC_EN         0x013B[3]     0x013B         3          1         User   R/W 
 * OUT9_FORMAT          0x013B[2:0]   0x013B         0          3         User   R/W 
 * OUT9_AMPL            0x013C[6:4]   0x013C         4          3         User   R/W 
 * OUT9_CM              0x013C[3:0]   0x013C         0          4         User   R/W 
 * OUT9_INV             0x013D[7:6]   0x013D         6          2         User   R/W 
 * OUT9_VDD_SEL         0x013D[5:4]   0x013D         4          2         User   R/W 
 * OUT9_VDD_SEL_EN      0x013D[3]     0x013D         3          1         User   R/W 
 * OUT9_MUX_SEL         0x013D[2:0]   0x013D         0          3         User   R/W 
 * OUTX_ALWAYS_ON       0x013F[11:0]  0x013F         0          12        User   R/W 
 * OUT_DIS_MSK_LOS_PFD  0x0141[7]     0x0141         7          1         User   R/W 
 * OUT_DIS_LOL_MSK      0x0141[5]     0x0141         5          1         User   R/W 
 * OUT_PDN_ALL          0x0145[0]     0x0145         0          1         None   R/W 
 * PXAXB                0x0206[1:0]   0x0206         0          2         User   R/W 
 * P0                   0x0208[47:0]  0x0208         0          48        User   R/W 
 * P0_SET               0x020E[31:0]  0x020E         0          32        User   R/W 
 * P1                   0x0212[47:0]  0x0212         0          48        User   R/W 
 * P1_SET               0x0218[31:0]  0x0218         0          32        User   R/W 
 * P2                   0x021C[47:0]  0x021C         0          48        User   R/W 
 * P2_SET               0x0222[31:0]  0x0222         0          32        User   R/W 
 * P3                   0x0226[47:0]  0x0226         0          48        User   R/W 
 * P3_SET               0x022C[31:0]  0x022C         0          32        User   R/W 
 * P3_UPDATE            0x0230[3]     0x0230         3          1         None   S/C 
 * P2_UPDATE            0x0230[2]     0x0230         2          1         None   S/C 
 * P1_UPDATE            0x0230[1]     0x0230         1          1         None   S/C 
 * P0_UPDATE            0x0230[0]     0x0230         0          1         None   S/C 
 * M_NUM                0x0235[43:0]  0x0235         0          44        User   R/W 
 * M_DEN                0x023B[31:0]  0x023B         0          32        User   R/W 
 * M_UPDATE             0x023F[0]     0x023F         0          1         None   S/C 
 * R0_REG               0x024A[23:0]  0x024A         0          24        User   R/W 
 * R1_REG               0x024D[23:0]  0x024D         0          24        User   R/W 
 * R2_REG               0x0250[23:0]  0x0250         0          24        User   R/W 
 * R3_REG               0x0253[23:0]  0x0253         0          24        User   R/W 
 * R4_REG               0x0256[23:0]  0x0256         0          24        User   R/W 
 * R5_REG               0x0259[23:0]  0x0259         0          24        User   R/W 
 * R6_REG               0x025C[23:0]  0x025C         0          24        User   R/W 
 * R7_REG               0x025F[23:0]  0x025F         0          24        User   R/W 
 * R8_REG               0x0262[23:0]  0x0262         0          24        User   R/W 
 * R9_REG               0x0268[23:0]  0x0268         0          24        User   R/W 
 * DESIGN_ID0           0x026B[7:0]   0x026B         0          8         User   R/W 
 * DESIGN_ID1           0x026C[7:0]   0x026C         0          8         User   R/W 
 * DESIGN_ID2           0x026D[7:0]   0x026D         0          8         User   R/W 
 * DESIGN_ID3           0x026E[7:0]   0x026E         0          8         User   R/W 
 * DESIGN_ID4           0x026F[7:0]   0x026F         0          8         User   R/W 
 * DESIGN_ID5           0x0270[7:0]   0x0270         0          8         User   R/W 
 * DESIGN_ID6           0x0271[7:0]   0x0271         0          8         User   R/W 
 * DESIGN_ID7           0x0272[7:0]   0x0272         0          8         User   R/W 
 * OPN_ID0              0x0278[7:0]   0x0278         0          8         SiLab  R/W 
 * OPN_ID1              0x0279[7:0]   0x0279         0          8         SiLab  R/W 
 * OPN_ID2              0x027A[7:0]   0x027A         0          8         SiLab  R/W 
 * OPN_ID3              0x027B[7:0]   0x027B         0          8         SiLab  R/W 
 * OPN_ID4              0x027C[7:0]   0x027C         0          8         SiLab  R/W 
 * OPN_REVISION         0x027D[7:0]   0x027D         0          8         SiLab  R/W 
 * BASELINE_ID          0x027E[7:0]   0x027E         0          8         SiLab  R/W 
 * N0_NUM               0x0302[43:0]  0x0302         0          44        User   R/W 
 * N0_DEN               0x0308[31:0]  0x0308         0          32        User   R/W 
 * N0_UPDATE            0x030C[0]     0x030C         0          1         User   S/C 
 * N1_NUM               0x030D[43:0]  0x030D         0          44        User   R/W 
 * N1_DEN               0x0313[31:0]  0x0313         0          32        User   R/W 
 * N1_UPDATE            0x0317[0]     0x0317         0          1         User   S/C 
 * N2_NUM               0x0318[43:0]  0x0318         0          44        User   R/W 
 * N2_DEN               0x031E[31:0]  0x031E         0          32        User   R/W 
 * N2_UPDATE            0x0322[0]     0x0322         0          1         User   S/C 
 * N3_NUM               0x0323[43:0]  0x0323         0          44        User   R/W 
 * N3_DEN               0x0329[31:0]  0x0329         0          32        User   R/W 
 * N3_UPDATE            0x032D[0]     0x032D         0          1         User   S/C 
 * N4_NUM               0x032E[43:0]  0x032E         0          44        User   R/W 
 * N4_DEN               0x0334[31:0]  0x0334         0          32        User   R/W 
 * N_UPDATE             0x0338[1]     0x0338         1          1         User   S/C 
 * N4_UPDATE            0x0338[0]     0x0338         0          1         User   S/C 
 * N_FSTEP_MSK          0x0339[4:0]   0x0339         0          5         User   R/W 
 * N0_FSTEPW            0x033B[43:0]  0x033B         0          44        User   R/W 
 * N1_FSTEPW            0x0341[43:0]  0x0341         0          44        User   R/W 
 * N2_FSTEPW            0x0347[43:0]  0x0347         0          44        User   R/W 
 * N3_FSTEPW            0x034D[43:0]  0x034D         0          44        User   R/W 
 * N4_FSTEPW            0x0353[43:0]  0x0353         0          44        User   R/W 
 * N0_DELAY             0x0359[15:0]  0x0359         0          16        User   R/W 
 * N1_DELAY             0x035B[15:0]  0x035B         0          16        User   R/W 
 * N2_DELAY             0x035D[15:0]  0x035D         0          16        User   R/W 
 * N3_DELAY             0x035F[15:0]  0x035F         0          16        User   R/W 
 * N4_DELAY             0x0361[15:0]  0x0361         0          16        User   R/W 
 * FIXREGSA0            0x0802[15:0]  0x0802         0          16        User   R/W 
 * FIXREGSD0            0x0804[7:0]   0x0804         0          8         User   R/W 
 * FIXREGSA1            0x0805[15:0]  0x0805         0          16        User   R/W 
 * FIXREGSD1            0x0807[7:0]   0x0807         0          8         User   R/W 
 * FIXREGSA2            0x0808[15:0]  0x0808         0          16        User   R/W 
 * FIXREGSD2            0x080A[7:0]   0x080A         0          8         User   R/W 
 * FIXREGSA3            0x080B[15:0]  0x080B         0          16        User   R/W 
 * FIXREGSD3            0x080D[7:0]   0x080D         0          8         User   R/W 
 * FIXREGSA4            0x080E[15:0]  0x080E         0          16        User   R/W 
 * FIXREGSD4            0x0810[7:0]   0x0810         0          8         User   R/W 
 * FIXREGSA5            0x0811[15:0]  0x0811         0          16        User   R/W 
 * FIXREGSD5            0x0813[7:0]   0x0813         0          8         User   R/W 
 * FIXREGSA6            0x0814[15:0]  0x0814         0          16        User   R/W 
 * FIXREGSD6            0x0816[7:0]   0x0816         0          8         User   R/W 
 * FIXREGSA7            0x0817[15:0]  0x0817         0          16        User   R/W 
 * FIXREGSD7            0x0819[7:0]   0x0819         0          8         User   R/W 
 * FIXREGSA8            0x081A[15:0]  0x081A         0          16        User   R/W 
 * FIXREGSD8            0x081C[7:0]   0x081C         0          8         User   R/W 
 * FIXREGSA9            0x081D[15:0]  0x081D         0          16        User   R/W 
 * FIXREGSD9            0x081F[7:0]   0x081F         0          8         User   R/W 
 * FIXREGSA10           0x0820[15:0]  0x0820         0          16        User   R/W 
 * FIXREGSD10           0x0822[7:0]   0x0822         0          8         User   R/W 
 * FIXREGSA11           0x0823[15:0]  0x0823         0          16        User   R/W 
 * FIXREGSD11           0x0825[7:0]   0x0825         0          8         User   R/W 
 * FIXREGSA12           0x0826[15:0]  0x0826         0          16        User   R/W 
 * FIXREGSD12           0x0828[7:0]   0x0828         0          8         User   R/W 
 * FIXREGSA13           0x0829[15:0]  0x0829         0          16        User   R/W 
 * FIXREGSD13           0x082B[7:0]   0x082B         0          8         User   R/W 
 * FIXREGSA14           0x082C[15:0]  0x082C         0          16        User   R/W 
 * FIXREGSD14           0x082E[7:0]   0x082E         0          8         User   R/W 
 * FIXREGSA15           0x082F[15:0]  0x082F         0          16        User   R/W 
 * FIXREGSD15           0x0831[7:0]   0x0831         0          8         User   R/W 
 * FIXREGSA16           0x0832[15:0]  0x0832         0          16        User   R/W 
 * FIXREGSD16           0x0834[7:0]   0x0834         0          8         User   R/W 
 * FIXREGSA17           0x0835[15:0]  0x0835         0          16        User   R/W 
 * FIXREGSD17           0x0837[7:0]   0x0837         0          8         User   R/W 
 * FIXREGSA18           0x0838[15:0]  0x0838         0          16        User   R/W 
 * FIXREGSD18           0x083A[7:0]   0x083A         0          8         User   R/W 
 * FIXREGSA19           0x083B[15:0]  0x083B         0          16        User   R/W 
 * FIXREGSD19           0x083D[7:0]   0x083D         0          8         User   R/W 
 * FIXREGSA20           0x083E[15:0]  0x083E         0          16        User   R/W 
 * FIXREGSD20           0x0840[7:0]   0x0840         0          8         User   R/W 
 * FIXREGSA21           0x0841[15:0]  0x0841         0          16        User   R/W 
 * FIXREGSD21           0x0843[7:0]   0x0843         0          8         User   R/W 
 * FIXREGSA22           0x0844[15:0]  0x0844         0          16        User   R/W 
 * FIXREGSD22           0x0846[7:0]   0x0846         0          8         User   R/W 
 * FIXREGSA23           0x0847[15:0]  0x0847         0          16        User   R/W 
 * FIXREGSD23           0x0849[7:0]   0x0849         0          8         User   R/W 
 * FIXREGSA24           0x084A[15:0]  0x084A         0          16        User   R/W 
 * FIXREGSD24           0x084C[7:0]   0x084C         0          8         User   R/W 
 * FIXREGSA25           0x084D[15:0]  0x084D         0          16        User   R/W 
 * FIXREGSD25           0x084F[7:0]   0x084F         0          8         User   R/W 
 * FIXREGSA26           0x0850[15:0]  0x0850         0          16        User   R/W 
 * FIXREGSD26           0x0852[7:0]   0x0852         0          8         User   R/W 
 * FIXREGSA27           0x0853[15:0]  0x0853         0          16        User   R/W 
 * FIXREGSD27           0x0855[7:0]   0x0855         0          8         User   R/W 
 * FIXREGSA28           0x0856[15:0]  0x0856         0          16        User   R/W 
 * FIXREGSD28           0x0858[7:0]   0x0858         0          8         User   R/W 
 * FIXREGSA29           0x0859[15:0]  0x0859         0          16        User   R/W 
 * FIXREGSD29           0x085B[7:0]   0x085B         0          8         User   R/W 
 * FIXREGSA30           0x085C[15:0]  0x085C         0          16        User   R/W 
 * FIXREGSD30           0x085E[7:0]   0x085E         0          8         User   R/W 
 * FIXREGSA31           0x085F[15:0]  0x085F         0          16        User   R/W 
 * FIXREGSD31           0x0861[7:0]   0x0861         0          8         User   R/W 
 * XAXB_PDNB            0x090E[1]     0x090E         1          1         User   R/W 
 * XAXB_EXTCLK_EN       0x090E[0]     0x090E         0          1         User   R/W 
 * ZDM_EN               0x091C[2:0]   0x091C         0          3         User   R/W 
 * IO_VDD_SEL           0x0943[0]     0x0943         0          1         User   R/W 
 * IN_PULSED_CMOS_EN    0x0949[7:4]   0x0949         4          4         User   R/W 
 * IN_EN                0x0949[3:0]   0x0949         0          4         User   R/W 
 * INX_TO_PFD_EN        0x094A[7:4]   0x094A         4          4         User   R/W 
 * REFCLK_HYS_SEL       0x094E[11:0]  0x094E         0          12        User   R/W 
 * M_INTEGER            0x095E[0]     0x095E         0          1         User   R/W 
 * N_ADD_0P5            0x0A02[4:0]   0x0A02         0          5         User   R/W 
 * N_CLK_TO_OUTX_EN     0x0A03[4:0]   0x0A03         0          5         User   R/W 
 * N_PIBYP              0x0A04[4:0]   0x0A04         0          5         User   R/W 
 * N_PDNB               0x0A05[4:0]   0x0A05         0          5         User   R/W 
 * PDIV_ENB             0x0B44[3:0]   0x0B44         0          4         User   R/W 
 * N_CLK_DIS            0x0B4A[4:0]   0x0B4A         0          5         User   R/W 
 * VCO_RESET_CALCODE    0x0B57[11:0]  0x0B57         0          12        User   R/W 
 * 
 *
 */

#endif
