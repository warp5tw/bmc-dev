Si5341 programming tool - mlnx_si5341prog
-----------------------------------------

This tool may take as input the file created by ClockBuilder Pro v2.12.1
(e.g., input/config.txt), parse the two-columns file (address and data)
and write the device registers. One can also export the current settings
to an output file, e.g., output/setting.txt.
It also allows the configuration of specific settings, either via register
addresses or setting name.

Usage: mlnx_si5341prog OPTIONS
   E.g. mlnx_si5341prog --device 9:0x74 -f --setconf config.txt --verify

  Device OPTIONS:
   -d, --device <bus:addr>  	Open device address 'addr' in i2c bus 'bus'.
   -f, --force              	Force configuration even when a driver is also
				running.
  Configuration OPTIONS:
   -c, --setconf <file>     	Program from Si5341 configuration 'file'.
				The file must be created using v2.12.1 of
			        ClockBuilder Pro.
   -k, --checkconf <file>       Check the current Si5341 configuration
                                against the configuration file 'file'.
   -a, --saveconf               Save the current configuration and reprogram
                                the NVM. NVM can be written two times only.
   -v, --verify             	Enable write byte verification.
   -r, --setreg <addr,val>  	Set SI5341 register 'addr' to 'val'.
   -g, --getreg <addr>      	Get SI5341 register 'addr' value.
   -t, --stg <name,val1,val2,...> Configure settings 'name' with
			        val1, val2,...; Note that val1 is the
				LSB and valN (N > 1) is the MSB.
   -s, --show <name>        	Print settings 'addr'.
   -e, --export <file>      	Export SI5341 configuration to 'file'.
  Optional OPTIONS:
   -h, --help                   Print this help


Si52142 programming tool - mlnx_si52142prog
-------------------------------------------

This tool may take several input parameters to configure the device. It
is a very basic tool to write specific bit fields and assert bits within
device registers. Besides, one can dump the current configuration or reset
the device to the default config.

Usage: mlnx_si52142prog OPTIONS
   E.g. mlnx_si52142prog -f -d 9:0x6b --reset --dump

  Device OPTIONS:
   -d, --device <bus:addr> 	Open device address 'addr' in i2c bus 'bus'
   -f, --force             	Force configuration even when a driver
				is also running
  Configuration OPTIONS:
   -e, --reset             	Restore default settings. Cannot be used
				with other configuration options
   -r, --revision <4bits>  	Set SI52142 Program Revision Code
   -v, --vendor <4bits>    	Set SI52142 Vendor Identification Code
   -x, --ref <bit>         	Output Enable for REF
                                       0: Output disabled
                                       1: Output enabled
   -y, --diff0 <bit>       	Output Enable for DIFF0
                                       0: Output disabled
                                       1: Output enabled
   -z, --diff1 <bit>       	Output Enable for DIFF1
                                       0: Output disabled
                                       1: Output enabled
   -b, --bc <8bits>        	Set Byte Count register
   -c, --control <3bits>   	Set DIFF Differential Outputs Amplitude
				Adjustment
                                       0:300mV  1:400mV  2:500mv  3:600mV
                                       4:700mV  5:800mV  6:900mv  7:1000mV
   -s, --select <bit>      	Set Amplitude Control for DIFF
				Differential Outputs
                                       0: Differential outputs with default
                                          amplitude.
                                       1: Differential outputs amplitude is
                                          set by --control
  Optional OPTIONS:
        -h, --help              Print this help
        -p, --dump              Print SI52142 configuration

The package structure is as follow:
-----------------------------------

Clk-tools
|
|__ include
|  |__i2c
|     |__i2c.h        : smbus library header.
|  |__clock
|     |__si5341.h     : Si5341 Rev D Regmap header files. This file is
|		        created by ClockBuilder Pro v2.12.1
|
|__i2c
|  |__I2c.c           : smbus library source file.
|
|__clock
|  |__si5341.c        : clock device source file.
|  |__si52142.c       : clock device source file.
|
|__input
|  |__config.txt      : Si5341 input configuration file. This file is
|			created by ClockBuilder Pro v2.12.1.
|  |__example.txt     : example of SI5341 input configuration file.
|
|__output
   |__settings.txt    : Si5341 output settings file.
