#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <linux/i2c-dev.h>

#include "i2c.h"

int i2c_smbus_init(int bus, int addr, bool force)
{
    char filename[20] = { 0 };
    unsigned long funcs;
    int file;

    snprintf(filename, sizeof(filename), "/dev/i2c-%d", bus);

    // Open adapter device file
    file = open(filename, O_RDWR);
    if (file < 0)
    {
        fprintf(stderr, "Error: Could not open file %s\n", filename);
        return file;
    }

    // Check adapter functionality
    if (ioctl(file, I2C_FUNCS, &funcs) < 0)
    {
        fprintf(stderr,
            "Error: Could not get the adapter functionality matrix: %s\n",
                    strerror(errno));
         close(file);
         return 0;
    }

    // Check for required functionalities. For now, we suppose that byte
    // write and byte read operations are sufficient to configure/program
    // most of the devices.
    CHECK_I2C_FUNC(funcs, I2C_FUNC_SMBUS_READ_BYTE);
    CHECK_I2C_FUNC(funcs, I2C_FUNC_SMBUS_WRITE_BYTE);
    CHECK_I2C_FUNC(funcs, I2C_FUNC_SMBUS_READ_BYTE_DATA);
    CHECK_I2C_FUNC(funcs, I2C_FUNC_SMBUS_WRITE_BYTE_DATA);
    CHECK_I2C_FUNC(funcs, I2C_FUNC_SMBUS_READ_BLOCK_DATA);
    CHECK_I2C_FUNC(funcs, I2C_FUNC_SMBUS_WRITE_BLOCK_DATA);

    // The I2C address; with force, let the user read from/write to the
    // registers even when a driver is also running
    if (ioctl(file, force ? I2C_SLAVE_FORCE : I2C_SLAVE, addr) < 0)
    {
        // ERROR HANDLING; you can check errno to see what went wrong
        fprintf(stderr, "Error: Cannot communicate with slave: %s\n",
                    strerror(errno));
        close(file);
        return 0;
    }

    return file;
}

int i2c_smbus_access(int     file,
                     char    read_write,
                     uint8_t command,
                     int     size,
                     union i2c_smbus_data *data)
{
    struct i2c_smbus_ioctl_data args;
    int err;

    args.read_write = read_write;
    args.command = command;
    args.size = size;
    args.data = data;

    err = ioctl(file, I2C_SMBUS, &args);
    if (err == -1)
        err = -errno;
    return err;
}

int i2c_smbus_read_byte(int file)
{
    union i2c_smbus_data data;
    int err;

    err = i2c_smbus_access(file, I2C_SMBUS_READ, 0,
                                    I2C_SMBUS_BYTE, &data);
    if (err < 0)
        return err;

    return 0x0FF & data.byte;
}

int i2c_smbus_write_byte(int file, uint8_t value)
{
    return i2c_smbus_access(file, I2C_SMBUS_WRITE, value,
                I2C_SMBUS_BYTE, NULL);
}

int i2c_smbus_read_byte_data(int file, uint8_t command)
{
    union i2c_smbus_data data;
    int err;

    err = i2c_smbus_access(file, I2C_SMBUS_READ, command,
                   I2C_SMBUS_BYTE_DATA, &data);
    if (err < 0)
        return err;

    return 0x0FF & data.byte;
}

int i2c_smbus_write_byte_data(int     file,
                              uint8_t command,
                              uint8_t value)
{
    union i2c_smbus_data data;

    data.byte = value;

    return i2c_smbus_access(file, I2C_SMBUS_WRITE,
                            command, I2C_SMBUS_BYTE_DATA, &data);
}

// Returns the number of read bytes or negative error code.
int i2c_smbus_read_block_data(int file, uint8_t command, uint8_t *values)
{
    union i2c_smbus_data data;
    int i, err;

    err = i2c_smbus_access(file, I2C_SMBUS_READ, command,
                   I2C_SMBUS_BLOCK_DATA, &data);
    if (err < 0)
        return err;

    for (i = 1; i <= data.block[0]; i++)
        values[i-1] = data.block[i];
    return data.block[0];
}

// The write block operation writes up to I2C_SMBUS_BLOCK_MAX bytes.
int i2c_smbus_write_block_data(int     file,
                               uint8_t command,
                               uint8_t length,
                               const uint8_t *values)
{
    union i2c_smbus_data data;
    int i;
    if (length > I2C_SMBUS_BLOCK_MAX)
        length = I2C_SMBUS_BLOCK_MAX;
    for (i = 1; i <= length; i++)
        data.block[i] = values[i-1];
    data.block[0] = length;
    return i2c_smbus_access(file, I2C_SMBUS_WRITE, command,
                I2C_SMBUS_BLOCK_DATA, &data);
}
