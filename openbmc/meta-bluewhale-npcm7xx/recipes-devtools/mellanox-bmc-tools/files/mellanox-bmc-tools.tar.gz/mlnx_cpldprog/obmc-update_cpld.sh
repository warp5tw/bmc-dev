#!/bin/sh

########################################################################
# Copyright (c) 2017 Mellanox Technologies.
# Copyright (c) 2017 Oleksandr Shamray <oleksandrs@mellanox.com>
#
# Licensed under the GNU General Public License Version 2
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
#
# Script to update CPLD firmware
#
# Usage:
#    a) Local: /run/initramfs/update_cpld <cpld-firmware-file.svf>
#    b) Remote: sshpass -p "<root-password>" ssh root@<ip> '/run/initramfs/update_cpld <cpld-firmware-file.svf>'
#
# Assumptions: 
#    <cpld-firmware-file.svf> is a SVF firmware file (one for all CPLD's)
#

CPLD_FIRMWARE_BKP=0
CPLD_FIRMWARE_BKP_PATH=/usr/share

# gpio32 and gpio33 - JTAG MUX control pins.
# To enable CPLD JTAG programming via CPU this pins should be:
# gpio32 - low  (output dir)
# gpio33 - high (output dir)

# From Aspeed GPIO driver sysfs, get base number for GPIO access
GPIO_BASE=$(cat /sys/devices/platform/ahb/ahb:apb/1e780000.gpio/gpio/*/base)

# Use base number to calculate GPIO numbers for pins 32,33
GPIO_NUM_32=$(($GPIO_BASE + 32))
GPIO_NUM_33=$(($GPIO_BASE + 33))

GPIO_PATH=/sys/class/gpio
GPIO_PIN0=gpio${GPIO_NUM_32}
GPIO_PIN1=gpio${GPIO_NUM_33}

if [ ! -e /dev/aspeed-jtag ]; then
    echo "/dev/aspeed-jtag interface not found"
    exit
fi

if [ ! -f $1 ]; then
    echo "SVF firmware file not found"
    exit
fi

echo "Configure JTAG mux control pins"
if [ ! -d $GPIO_PATH/$GPIO_PIN0 ]; then
    echo ${GPIO_NUM_32} > /sys/class/gpio/export
fi
if [ ! -d $GPIO_PATH/$GPIO_PIN1 ]; then
    echo ${GPIO_NUM_33} > /sys/class/gpio/export
fi

echo out > $GPIO_PATH/$GPIO_PIN0/direction
echo out > $GPIO_PATH/$GPIO_PIN1/direction
echo 0 > $GPIO_PATH/$GPIO_PIN0/value
echo 1 > $GPIO_PATH/$GPIO_PIN1/value
/usr/sbin/.mlnx_cpldprog -infile $1 -prog /dev/aspeed-jtag
rv=$?

if [ CPLD_FIRMWARE_BKP = 1 ]; then
    #create backup file
    SVF_FILE=$(basename $1)
    tar cvzf $CPLD_FIRMWARE_BKP_PATH/$SVF_FILE.tar.gz $1 &2>null
fi

echo "Disable JTAG mux control pins"
echo in > $GPIO_PATH/$GPIO_PIN0/direction
echo in > $GPIO_PATH/$GPIO_PIN1/direction

if [ $rv -lt 0 ]; then
    echo "Attempt to update CPLD failed"
else
    echo "CPLD successfully updated."
fi

sleep 1
