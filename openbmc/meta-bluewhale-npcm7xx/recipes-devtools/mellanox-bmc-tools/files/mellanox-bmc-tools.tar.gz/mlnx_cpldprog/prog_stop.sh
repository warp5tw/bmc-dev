#! /bin/sh
GPIO_PATH=/sys/class/gpio/

# From Aspeed GPIO driver sysfs, get base number for GPIO access
GPIO_BASE=$(cat /sys/devices/platform/ahb/ahb:apb/1e780000.gpio/gpio/*/base)

# Use base number to calculate GPIO numbers for pins 32,33
GPIO_NUM_32=$(($GPIO_BASE + 32))
GPIO_NUM_33=$(($GPIO_BASE + 33))

echo "Set IN GPIOE0, GPIOE1"
if [ ! -d $GPIO_PATH/gpio${GPIO_NUM_32} ]; then
        echo ${GPIO_NUM_32} > /sys/class/gpio/export
fi
if [ ! -d $GPIO_PATH/gpio${GPIO_NUM_33} ]; then
        echo ${GPIO_NUM_33} > /sys/class/gpio/export
fi
echo in > /sys/class/gpio/gpio${GPIO_NUM_32}/direction
echo in > /sys/class/gpio/gpio${GPIO_NUM_33}/direction
